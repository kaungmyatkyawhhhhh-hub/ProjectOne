---
source_file: "Playbook notes - Onboarding, retention and live ops.md"
type: "concept"
community: "Weekly updates and trainer collection"
location: "L134"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Weekly_updates_and_trainer_collection
---

# LiveOps Update Cadence

## Connections
- [[Admin Abuse Events  Admin War]] - `conceptually_related_to` [EXTRACTED]
- [[Grow a Garden_1]] - `references` [EXTRACTED]
- [[Weekly Saturday Update Template]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Weekly_updates_and_trainer_collection