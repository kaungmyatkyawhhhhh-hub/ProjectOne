---
type: community
cohesion: 0.18
members: 11
---

# Titles, search and copycat rules

**Cohesion:** 0.18 - loosely connected
**Members:** 11 nodes

## Members
- [[15 June 2026 RFY Change (28-day window)]] - concept - Playbook notes - Discovery and marketing.md
- [[Description First-sentence Guidance]] - concept - Playbook notes - Icons and titles.md
- [[Discovery Copycat Grouping by Images]] - concept - Playbook notes - Icons and titles.md
- [[Experience Icon Spec (512x512, reads at 150px)]] - concept - Playbook notes - Icons and titles.md
- [[Game Title Conventions]] - concept - Playbook notes - Icons and titles.md
- [[Icon Design Craft]] - concept - Playbook notes - Icons and titles.md
- [[Near-copy Deprioritization]] - concept - Playbook notes - Discovery and marketing.md
- [[No Icon AB Testing]] - concept - Playbook notes - Icons and titles.md
- [[Roblox Experience Icons, Titles and Descriptions]] - document - Playbook notes - Icons and titles.md
- [[Roblox Search]] - concept - Playbook notes - Discovery and marketing.md
- [[Thumbnail Personalization_1]] - concept - Playbook notes - Analytics and experiments.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Titles_search_and_copycat_rules
SORT file.name ASC
```

## Connections to other communities
- 3 edges to [[_COMMUNITY_Discovery and ads]]
- 1 edge to [[_COMMUNITY_Lighting and cameras]]
- 1 edge to [[_COMMUNITY_Analytics events]]

## Top bridge nodes
- [[Roblox Experience Icons, Titles and Descriptions]] - degree 5, connects to 1 community
- [[Thumbnail Personalization_1]] - degree 3, connects to 1 community
- [[15 June 2026 RFY Change (28-day window)]] - degree 2, connects to 1 community
- [[Near-copy Deprioritization]] - degree 2, connects to 1 community
- [[Roblox Search]] - degree 2, connects to 1 community