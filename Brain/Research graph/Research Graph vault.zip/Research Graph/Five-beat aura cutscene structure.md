---
source_file: "2026-11-05 Research - Sols RNG 100M+ aura cutscenes (40 watched) + Immortality and Regrowth videos.md"
type: "rationale"
community: "Cutscenes and incremental HUDs"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Cutscenes_and_incremental_HUDs
---

# Five-beat aura cutscene structure

## Connections
- [[Screen-space cutscene template (per-item colour + symbol)]] - `implements` [EXTRACTED]
- [[Sol's RNG]] - `conceptually_related_to` [EXTRACTED]
- [[Sol's RNG aura cutscenes + Immortality and Regrowth]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Cutscenes_and_incremental_HUDs