---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L120"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# Aura recipe

## Connections
- [[LightEmission (additive blending)]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles