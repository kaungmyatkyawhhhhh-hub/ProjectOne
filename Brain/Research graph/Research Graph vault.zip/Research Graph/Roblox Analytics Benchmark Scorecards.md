---
source_file: "Playbook notes - Onboarding, retention and live ops.md"
type: "concept"
community: "Logos, loading screen and GYM ARC art"
location: "L11"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Logos_loading_screen_and_GYM_ARC_art
---

# Roblox Analytics Benchmark Scorecards

## Connections
- [[BLOXG Genre Retention Benchmarks]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Logos_loading_screen_and_GYM_ARC_art