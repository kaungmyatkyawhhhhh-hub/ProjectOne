---
source_file: "Playbook notes - Core loop design.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L17"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# MDA Framework

## Connections
- [[Core Loop Design for Roblox Simulators and Casual Games]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths