---
source_file: "Playbook notes - Logos.md"
type: "concept"
community: "Names, logos and IP safety"
location: "L43"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# Google Fonts OFL / Apache 2.0 Licences

## Connections
- [[Roblox Enum.Font Built-in Fonts]] - `conceptually_related_to` [EXTRACTED]
- [[Trademark  IP Basics for Logos]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Names_logos_and_IP_safety