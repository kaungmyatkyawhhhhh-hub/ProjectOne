---
source_file: "Playbook notes - Incremental games.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L6"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Exponential Cost vs Polynomial Production Seesaw

## Connections
- [[Geometric Rebirth Cost Formula]] - `semantically_similar_to` [INFERRED]
- [[Greedy Purchase Simulation]] - `rationale_for` [EXTRACTED]
- [[Incremental  Idle Game Design and Math]] - `references` [EXTRACTED]
- [[Kongregate Idle Game Math (Pecorella)]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths