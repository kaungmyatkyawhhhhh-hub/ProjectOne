---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "Seasonal calendar"
location: "L13"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Seasonal_calendar
---

# Kids & Select audience gating (May 2026)

## Connections
- [[Playbook notes Whole-game research (Oct 2026)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Seasonal_calendar