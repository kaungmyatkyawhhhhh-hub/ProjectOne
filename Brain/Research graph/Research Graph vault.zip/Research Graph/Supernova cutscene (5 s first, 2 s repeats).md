---
source_file: "2026-11-01 Research - Do cutscenes help, what makes a good one.md"
type: "concept"
community: "Cutscenes and incremental HUDs"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Cutscenes_and_incremental_HUDs
---

# Supernova cutscene (5 s first, 2 s repeats)

## Connections
- [[Do cutscenes help, what makes a good one]] - `references` [EXTRACTED]
- [[Galaxy Incremental (was Supernova Incremental)]] - `conceptually_related_to` [EXTRACTED]
- [[Gargantua aura]] - `conceptually_related_to` [EXTRACTED]
- [[Good cutscene checklist (earned, short, skippable, opens a question)]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Cutscenes_and_incremental_HUDs