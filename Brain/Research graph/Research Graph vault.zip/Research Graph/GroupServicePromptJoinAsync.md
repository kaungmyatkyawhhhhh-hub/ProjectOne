---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "concept"
community: "Logos, loading screen and GYM ARC art"
location: "L382"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Logos_loading_screen_and_GYM_ARC_art
---

# GroupService:PromptJoinAsync

## Connections
- [[Roblox Community (Group) Emblem and Banner]] - `conceptually_related_to` [INFERRED]
- [[Soft Ask Before Native Prompt]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Logos_loading_screen_and_GYM_ARC_art