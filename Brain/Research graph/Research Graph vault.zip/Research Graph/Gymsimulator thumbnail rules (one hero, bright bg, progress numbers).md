---
source_file: "2026-11-03 Research - Gym, simulator and evolution thumbnails (owner screenshots).md"
type: "rationale"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# Gym/simulator thumbnail rules (one hero, bright bg, progress numbers)

## Connections
- [[Gym Star Simulator]] - `references` [EXTRACTED]
- [[Gym, simulator and evolution thumbnails]] - `references` [EXTRACTED]
- [[High-CTR thumbnail design rules]] - `semantically_similar_to` [INFERRED]
- [[Power Lifters]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks