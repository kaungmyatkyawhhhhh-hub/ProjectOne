---
source_file: "Playbook notes - Monetization.md"
type: "concept"
community: "Optimization and retention mechanics"
location: "L258"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# GYM ARC Starter 49 R$ / Premium Pack 199 R$

## Connections
- [[Discount Honesty Rules (no fake sales or resetting timers)]] - `references` [EXTRACTED]
- [[Starter Packs]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Optimization_and_retention_mechanics