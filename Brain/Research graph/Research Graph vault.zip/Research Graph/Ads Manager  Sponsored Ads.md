---
source_file: "Playbook notes - Discovery and marketing.md"
type: "concept"
community: "Discovery and ads"
location: "L198"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Discovery_and_ads
---

# Ads Manager / Sponsored Ads

## Connections
- [[Ads Break-even Math]] - `conceptually_related_to` [INFERRED]
- [[Ads Manager Reporting and Campaign Judging]] - `semantically_similar_to` [INFERRED]
- [[ExploreExpand Testing]] - `conceptually_related_to` [EXTRACTED]
- [[Roblox Discovery and Marketing]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Discovery_and_ads