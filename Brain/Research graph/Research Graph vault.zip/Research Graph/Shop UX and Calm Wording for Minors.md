---
source_file: "Playbook notes - Monetization.md"
type: "rationale"
community: "Optimization and retention mechanics"
location: "L172"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# Shop UX and Calm Wording for Minors

## Connections
- [[University of Sydney Study on Deceptive Purchase Design]] - `rationale_for` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Optimization_and_retention_mechanics