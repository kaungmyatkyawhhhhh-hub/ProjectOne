---
source_file: "Playbook notes - Onboarding, retention and live ops.md"
type: "concept"
community: "Names, logos and IP safety"
location: "L162"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# Co-play Sessions 1.9x Longer

## Connections
- [[Friend Referral System]] - `rationale_for` [EXTRACTED]
- [[Roblox Party]] - `rationale_for` [EXTRACTED]
- [[Top-Game Retention Mechanics (11)]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Names_logos_and_IP_safety