---
source_file: "Playbook notes - Passes and products catalogue.md"
type: "concept"
community: "Passes and products"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Passes_and_products
---

# Promoted Pass Price Window (49-801 R$)

## Connections
- [[GymRunning Simulator Starter Catalogue (6-8 passes)]] - `rationale_for` [EXTRACTED]
- [[Playbook notes - Passes and products catalogue]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Passes_and_products