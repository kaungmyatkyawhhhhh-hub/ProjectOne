---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L48"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/VFX_and_particles
---

# Lighting.Technology superseded by LightingStyle + PrioritizeLightingQuality

## Connections
- [[LightingStyle + PrioritizeLightingQuality]] - `semantically_similar_to` [INFERRED]
- [[Post-processing effects (Bloom, ColorCorrection, ColorGrading)]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/INFERRED #community/VFX_and_particles