---
source_file: "Playbook notes - Names and descriptions.md"
type: "rationale"
community: "Names, logos and IP safety"
location: "L66"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# Kid-Friendly Description Structure

## Connections
- [[Grow a Garden_3]] - `references` [EXTRACTED]
- [[NameDescription Localization (Information tab)]] - `conceptually_related_to` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Names_logos_and_IP_safety