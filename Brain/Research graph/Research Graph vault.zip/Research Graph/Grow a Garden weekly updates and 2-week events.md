---
source_file: "Playbook notes - Updates and live ops.md"
type: "concept"
community: "Updates, events and release slot"
location: "L30"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# Grow a Garden weekly updates and 2-week events

## Connections
- [[GYM ARC Saturday 1500 UTC release rule]] - `references` [EXTRACTED]
- [[Two-tier update cadence (weekly beat + 2-4 week content drops)]] - `rationale_for` [INFERRED]
- [[Vary event types to avoid repetitive-event fatigue]] - `rationale_for` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Updates_events_and_release_slot