---
source_file: "Playbook notes - Updates and live ops.md"
type: "rationale"
community: "Updates, events and release slot"
location: "L44"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# Deploy early, hide content behind config flag

## Connections
- [[Launch checklist for a solo kids' simulator (D-7 to launch)]] - `conceptually_related_to` [EXTRACTED]
- [[Rollback via previous place version + backward-compatible DataStore schema]] - `conceptually_related_to` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Updates_events_and_release_slot