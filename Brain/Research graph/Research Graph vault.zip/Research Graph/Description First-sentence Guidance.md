---
source_file: "Playbook notes - Icons and titles.md"
type: "concept"
community: "Titles, search and copycat rules"
location: "L82"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Titles_search_and_copycat_rules
---

# Description First-sentence Guidance

## Connections
- [[Roblox Experience Icons, Titles and Descriptions]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Titles_search_and_copycat_rules