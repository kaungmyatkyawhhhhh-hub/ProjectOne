---
source_file: "Playbook notes - Onboarding, retention and live ops.md"
type: "concept"
community: "Weekly updates and trainer collection"
location: "L141"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Weekly_updates_and_trainer_collection
---

# Admin Abuse Events / Admin War

## Connections
- [[Admin Abuse  Power Hour Warm-up]] - `semantically_similar_to` [INFERRED]
- [[Grow a Garden_1]] - `references` [EXTRACTED]
- [[LiveOps Update Cadence]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Weekly_updates_and_trainer_collection