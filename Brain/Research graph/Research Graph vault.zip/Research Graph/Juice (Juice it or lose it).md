---
source_file: "Playbook notes - UI, game feel, art and sound.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Juice (Juice it or lose it)

## Connections
- [[Playbook notes - UI, game feel, art and sound]] - `references` [EXTRACTED]
- [[Rarity Stinger Escalation Ladder]] - `semantically_similar_to` [INFERRED]
- [[ReducedMotionEnabled]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel