---
type: community
cohesion: 1.00
members: 1
---

# QA basics

**Cohesion:** 1.00 - tightly connected
**Members:** 1 nodes

## Members
- [[QA (Error Report, Device Simulator, real-phone testing)]] - concept - Playbook notes - Whole-game research (Oct 2026).md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/QA_basics
SORT file.name ASC
```
