---
source_file: "Playbook notes - Passes and products catalogue.md"
type: "rationale"
community: "Passes and products"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Passes_and_products
---

# Live Prices via GetProductInfo

## Connections
- [[Grant Developer Products Only in ProcessReceipt]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Passes and products catalogue]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Passes_and_products