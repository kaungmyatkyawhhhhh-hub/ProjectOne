---
source_file: "Playbook notes - Core loop design.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L19"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Roblox Paid Random Items Policy

## Connections
- [[Core Loop Design for Roblox Simulators and Casual Games]] - `references` [EXTRACTED]
- [[The 12 Rules from Big-Game Mistakes]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths