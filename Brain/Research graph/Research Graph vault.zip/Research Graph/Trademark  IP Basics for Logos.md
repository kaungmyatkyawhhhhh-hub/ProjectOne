---
source_file: "Playbook notes - Logos.md"
type: "rationale"
community: "Names, logos and IP safety"
location: "L133"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# Trademark / IP Basics for Logos

## Connections
- [[AI-Generated Logos and US Copyright Office Report]] - `references` [EXTRACTED]
- [[Google Fonts OFL  Apache 2.0 Licences]] - `references` [EXTRACTED]
- [[Name-Checking Checklist]] - `semantically_similar_to` [INFERRED]

#graphify/rationale #graphify/EXTRACTED #community/Names_logos_and_IP_safety