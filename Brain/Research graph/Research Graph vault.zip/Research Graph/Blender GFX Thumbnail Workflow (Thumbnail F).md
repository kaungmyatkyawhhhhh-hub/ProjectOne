---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "concept"
community: "Names, logos and IP safety"
location: "L758"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# Blender GFX Thumbnail Workflow (Thumbnail F)

## Connections
- [[GYM ARC Thumbnail Brief v3]] - `implements` [EXTRACTED]
- [[Never Ship AI Images Rule]] - `rationale_for` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Names_logos_and_IP_safety