---
source_file: "Playbook notes - Game quality and QA.md"
type: "concept"
community: "Quality and polish"
location: "L76"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Quality_and_polish
---

# Studio Testing APIs (StudioTestService, VirtualInput)

## Connections
- [[AI Coding Pain Points on Roblox]] - `references` [EXTRACTED]
- [[Solo QA Process]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Quality_and_polish