---
source_file: "Playbook notes - Policy, safety and community.md"
type: "document"
community: "Policy, safety and kids rules"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Policy_safety_and_kids_rules
---

# Playbook notes - Policy, safety and community

## Connections
- [[Ads Manager Engagement Objective]] - `references` [EXTRACTED]
- [[Chat Age Checks and Age Bands]] - `references` [EXTRACTED]
- [[Content Maturity Labels (MinimalMildModerateRestricted)]] - `references` [EXTRACTED]
- [[Experience Notifications]] - `references` [EXTRACTED]
- [[Free-Form User Creation Restriction (16+)]] - `references` [EXTRACTED]
- [[Independent In-Game Advertising Rules]] - `references` [EXTRACTED]
- [[Maturity & Compliance Questionnaire]] - `references` [EXTRACTED]
- [[Off-Platform Links Ban in Experiences]] - `references` [EXTRACTED]
- [[PolicyService RegionalAge Gating]] - `references` [EXTRACTED]
- [[Rights Manager IP Claims]] - `references` [EXTRACTED]
- [[Roblox Kids and Select Eligibility]] - `references` [EXTRACTED]
- [[Simulated Gambling Ban and Odds Disclosure]] - `references` [EXTRACTED]
- [[Social Hangout Age Restriction]] - `references` [EXTRACTED]
- [[Social Links Slots (16+ only)]] - `references` [EXTRACTED]
- [[TextService FilterStringAsync Filtering]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Policy_safety_and_kids_rules