---
source_file: "Playbook notes - Incremental games.md"
type: "rationale"
community: "Core loop, incrementals and trends maths"
location: "L150"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# GYM ARC Alter Prestige Gaps

## Connections
- [[Incremental  Idle Game Design and Math]] - `references` [EXTRACTED]
- [[Prestige Formulas (Realm Grinder, AdCap, Cookie Clicker, Egg Inc.)]] - `conceptually_related_to` [INFERRED]

#graphify/rationale #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths