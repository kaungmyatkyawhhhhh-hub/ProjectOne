---
source_file: "Playbook notes - Sound and music.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# UI Sound Vocabulary (one family, music key)

## Connections
- [[Character Sounds Immersion Study (2024)]] - `rationale_for` [INFERRED]
- [[Playbook notes - Sound and music]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel