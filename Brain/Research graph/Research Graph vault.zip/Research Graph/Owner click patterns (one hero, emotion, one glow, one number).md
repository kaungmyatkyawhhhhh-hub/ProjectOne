---
source_file: "2026-11-05 Research - What the owner clicks on Roblox (10 min watch).md"
type: "concept"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# Owner click patterns (one hero, emotion, one glow, one number)

## Connections
- [[+1 Depth Incremental]] - `references` [EXTRACTED]
- [[+1 Venom Evolution]] - `references` [EXTRACTED]
- [[High-CTR thumbnail design rules]] - `semantically_similar_to` [INFERRED]
- [[Power Lifters]] - `references` [EXTRACTED]
- [[Project Iron]] - `references` [EXTRACTED]
- [[Roblox icon, thumbnail and logo recipe]] - `conceptually_related_to` [INFERRED]
- [[Roblox-avatar simulator thumbnail style]] - `semantically_similar_to` [INFERRED]
- [[Tryez Lifting Simulator]] - `references` [EXTRACTED]
- [[What the owner clicks on Roblox]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks