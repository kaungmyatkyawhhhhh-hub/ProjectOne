---
source_file: "Playbook notes - Discovery and marketing.md"
type: "concept"
community: "Titles, search and copycat rules"
location: "L33"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Titles_search_and_copycat_rules
---

# 15 June 2026 RFY Change (28-day window)

## Connections
- [[Recommended For You Algorithm]] - `conceptually_related_to` [EXTRACTED]
- [[Thumbnail Personalization_1]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Titles_search_and_copycat_rules