---
source_file: "Playbook notes - UI, game feel, art and sound.md"
type: "code"
community: "UI, sound and game feel"
tags:
  - graphify/code
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# ScreenInsets CoreUISafeInsets

## Connections
- [[Adaptive Design Guidelines]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - UI, game feel, art and sound]] - `references` [EXTRACTED]
- [[ScreenGui DisplayOrder Layering]] - `conceptually_related_to` [EXTRACTED]

#graphify/code #graphify/EXTRACTED #community/UI_sound_and_game_feel