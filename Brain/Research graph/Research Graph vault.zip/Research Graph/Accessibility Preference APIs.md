---
source_file: "Playbook notes - UI, game feel, art and sound.md"
type: "code"
community: "UI, sound and game feel"
tags:
  - graphify/code
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Accessibility Preference APIs

## Connections
- [[Playbook notes - UI, game feel, art and sound]] - `references` [EXTRACTED]
- [[ReducedMotionEnabled]] - `conceptually_related_to` [EXTRACTED]

#graphify/code #graphify/EXTRACTED #community/UI_sound_and_game_feel