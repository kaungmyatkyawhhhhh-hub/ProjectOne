---
source_file: "Playbook notes - Lighting, cameras and cutscenes.md"
type: "concept"
community: "Lighting and cameras"
location: "L34"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Lighting_and_cameras
---

# Local Light Cost (Spot < Surface < Point)

## Connections
- [[Lighting, Cameras and Cutscenes for Roblox Simulators]] - `references` [EXTRACTED]
- [[Phone-first Lighting Baseline]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Lighting_and_cameras