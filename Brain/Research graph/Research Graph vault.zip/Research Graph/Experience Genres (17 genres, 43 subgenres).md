---
source_file: "Playbook notes - Names and descriptions.md"
type: "concept"
community: "Names, logos and IP safety"
location: "L91"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/Names_logos_and_IP_safety
---

# Experience Genres (17 genres, 43 subgenres)

## Connections
- [[Hybrid Name Formula (Brand Word + Genre Keyword)]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/INFERRED #community/Names_logos_and_IP_safety