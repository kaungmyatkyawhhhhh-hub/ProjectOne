---
source_file: "Playbook notes - Core loop design.md"
type: "rationale"
community: "Core loop, incrementals and trends maths"
location: "L250"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Indicative Kill-or-Iterate Thresholds

## Connections
- [[Core Loop Design for Roblox Simulators and Casual Games]] - `references` [EXTRACTED]
- [[GameAnalytics 2026 Roblox Benchmarks]] - `conceptually_related_to` [INFERRED]
- [[Supercell Kill Culture]] - `conceptually_related_to` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths