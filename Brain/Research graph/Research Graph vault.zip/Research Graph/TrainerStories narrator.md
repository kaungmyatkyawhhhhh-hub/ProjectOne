---
source_file: "2026-10-31 Atlas myth and trainer stories.md"
type: "concept"
community: "Atlas story"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Atlas_story
---

# TrainerStories narrator

## Connections
- [[Atlas myth and trainer stories]] - `references` [EXTRACTED]
- [[AudioTextToSpeech (Roblox text to speech)]] - `implements` [EXTRACTED]
- [[GYM ARC]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Atlas_story