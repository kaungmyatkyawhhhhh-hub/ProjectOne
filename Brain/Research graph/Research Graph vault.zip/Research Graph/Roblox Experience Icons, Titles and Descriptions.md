---
source_file: "Playbook notes - Icons and titles.md"
type: "document"
community: "Titles, search and copycat rules"
location: "L1"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Titles_search_and_copycat_rules
---

# Roblox Experience Icons, Titles and Descriptions

## Connections
- [[AI-generated Icon and Safe Imagery Rules]] - `references` [EXTRACTED]
- [[Description First-sentence Guidance]] - `references` [EXTRACTED]
- [[Experience Icon Spec (512x512, reads at 150px)]] - `references` [EXTRACTED]
- [[Game Title Conventions]] - `references` [EXTRACTED]
- [[Icon Design Craft]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Titles_search_and_copycat_rules