---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "Kids onboarding UX"
location: "L25"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/Kids_onboarding_UX
---

# Roblox onboarding guidance (timed hints, moment of joy)

## Connections
- [[Kids UX (skip instructions, instant gratification)]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/INFERRED #community/Kids_onboarding_UX