---
source_file: "Playbook notes - Performance, data and security.md"
type: "rationale"
community: "Performance, data and security"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Performance_data_and_security
---

# Avoid Partial Transparency (overdraw)

## Connections
- [[Baseline Device Budget (1k draw calls  1M triangles)]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Performance, data and security]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Performance_data_and_security