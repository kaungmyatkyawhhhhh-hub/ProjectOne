---
source_file: "2026-11-04 Reincarnated Tycoon - next game check.md"
type: "concept"
community: "Trending games and next game ideas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Trending_games_and_next_game_ideas
---

# Miner's Haven

## Connections
- [[Reincarnated Tycoon - next game check]] - `references` [EXTRACTED]
- [[Reincarnated Tycoon]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Trending_games_and_next_game_ideas