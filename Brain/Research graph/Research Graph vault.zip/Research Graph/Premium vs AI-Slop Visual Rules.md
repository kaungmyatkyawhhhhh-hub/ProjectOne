---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "rationale"
community: "Weekly updates and trainer collection"
location: "L240"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Weekly_updates_and_trainer_collection
---

# Premium vs AI-Slop Visual Rules

## Connections
- [[Trainer Inventory UX Spec]] - `rationale_for` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Weekly_updates_and_trainer_collection