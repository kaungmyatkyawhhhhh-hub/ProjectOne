---
source_file: "Playbook notes - Thumbnails.md"
type: "concept"
community: "Thumbnail art study and testing"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Thumbnail_art_study_and_testing
---

# Simulator Thumbnail Composition (hero + payoff)

## Connections
- [[AI-Looking Thumbnail Signals]] - `rationale_for` [EXTRACTED]
- [[Playbook notes - Thumbnails]] - `references` [EXTRACTED]
- [[Simulator Formula Style (C)]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Thumbnail_art_study_and_testing