---
type: community
cohesion: 0.25
members: 8
---

# Money: DevEx and pricing

**Cohesion:** 0.25 - loosely connected
**Members:** 8 nodes

## Members
- [[DevEx Rate $0.0038 per Robux]] - concept - Playbook notes - Logos.md
- [[Developer Exchange (DevEx)]] - concept - Playbook notes - Monetization.md
- [[Escrow Hold Conflict (30 days vs ~5 days)]] - concept - Playbook notes - Monetization.md
- [[Logo Commission Pricing (Robux)]] - concept - Playbook notes - Logos.md
- [[Managed Pricing]] - concept - Playbook notes - Monetization.md
- [[Passes and Developer Products (70% share)]] - concept - Playbook notes - Monetization.md
- [[Regional Pricing]] - concept - Playbook notes - Monetization.md
- [[Roblox Subscriptions]] - concept - Playbook notes - Monetization.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Money_DevEx_and_pricing
SORT file.name ASC
```
