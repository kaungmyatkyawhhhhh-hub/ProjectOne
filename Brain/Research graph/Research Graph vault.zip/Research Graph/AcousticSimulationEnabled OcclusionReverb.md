---
source_file: "Playbook notes - Sound and music.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# AcousticSimulationEnabled Occlusion/Reverb

## Connections
- [[Audio API (AudioPlayer, Wire, AudioEmitter, AudioDeviceOutput)]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Sound and music]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel