---
source_file: "Playbook notes - Optimization deep dive.md"
type: "concept"
community: "Memory debugging"
location: "L375"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Memory_debugging
---

# Mobile Out-of-Memory Exits

## Connections
- [[Luau Heap Snapshots]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Memory_debugging