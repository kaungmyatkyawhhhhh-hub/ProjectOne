---
source_file: "Playbook notes - Lighting, cameras and cutscenes.md"
type: "document"
community: "Lighting and cameras"
location: "L1"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Lighting_and_cameras
---

# Lighting, Cameras and Cutscenes for Roblox Simulators

## Connections
- [[Atmosphere and Post-processing Effects]] - `references` [EXTRACTED]
- [[Cutscene Building Methods]] - `references` [EXTRACTED]
- [[LightingStyle (Realistic  Soft)]] - `references` [EXTRACTED]
- [[Local Light Cost (Spot  Surface  Point)]] - `references` [EXTRACTED]
- [[PrioritizeLightingQuality]] - `references` [EXTRACTED]
- [[Scriptable Camera]] - `references` [EXTRACTED]
- [[ThumbnailIcon Photo-booth Capture]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Lighting_and_cameras