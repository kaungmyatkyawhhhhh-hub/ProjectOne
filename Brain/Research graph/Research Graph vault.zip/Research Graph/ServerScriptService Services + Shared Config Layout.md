---
source_file: "Playbook notes - Performance, data and security.md"
type: "concept"
community: "Performance, data and security"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Performance_data_and_security
---

# ServerScriptService Services + Shared Config Layout

## Connections
- [[Playbook notes - Performance, data and security]] - `references` [EXTRACTED]
- [[ProfileStore Session-Locked Saving]] - `references` [EXTRACTED]
- [[Token-Bucket Rate Limiting]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Performance_data_and_security