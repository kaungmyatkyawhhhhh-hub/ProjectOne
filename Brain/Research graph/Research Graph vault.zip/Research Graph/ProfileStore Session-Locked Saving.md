---
source_file: "Playbook notes - Performance, data and security.md"
type: "concept"
community: "Performance, data and security"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Performance_data_and_security
---

# ProfileStore Session-Locked Saving

## Connections
- [[Data Store Limits and Budgets (July 2026 unification)]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Performance, data and security]] - `references` [EXTRACTED]
- [[ServerScriptService Services + Shared Config Layout]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Performance_data_and_security