---
source_file: "Playbook notes - Policy, safety and community.md"
type: "concept"
community: "Policy, safety and kids rules"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Policy_safety_and_kids_rules
---

# Ads Manager Engagement Objective

## Connections
- [[Playbook notes - Policy, safety and community]] - `references` [EXTRACTED]
- [[Roblox Kids and Select Eligibility]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Policy_safety_and_kids_rules