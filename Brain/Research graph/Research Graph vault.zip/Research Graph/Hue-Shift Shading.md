---
source_file: "Playbook notes - Logos.md"
type: "concept"
community: "Logos, loading screen and GYM ARC art"
location: "L20"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Logos_loading_screen_and_GYM_ARC_art
---

# Hue-Shift Shading

## Connections
- [[Roblox Game Logo Layer Recipe]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Logos_loading_screen_and_GYM_ARC_art