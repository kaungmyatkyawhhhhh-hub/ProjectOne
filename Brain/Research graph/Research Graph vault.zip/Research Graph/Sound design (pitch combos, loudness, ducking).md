---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "Sound design basics"
location: "L59"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Sound_design_basics
---

# Sound design (pitch combos, loudness, ducking)

#graphify/concept #graphify/EXTRACTED #community/Sound_design_basics