---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L15"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# LightEmission (additive blending)

## Connections
- [[Aura recipe]] - `implements` [EXTRACTED]
- [[ParticleEmitter]] - `references` [EXTRACTED]
- [[Post-processing effects (Bloom, ColorCorrection, ColorGrading)]] - `rationale_for` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles