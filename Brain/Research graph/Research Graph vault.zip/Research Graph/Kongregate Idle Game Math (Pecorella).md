---
source_file: "Playbook notes - Core loop design.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L115"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Kongregate Idle Game Math (Pecorella)

## Connections
- [[Core Loop Design for Roblox Simulators and Casual Games]] - `references` [EXTRACTED]
- [[Exponential Cost vs Polynomial Production Seesaw]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths