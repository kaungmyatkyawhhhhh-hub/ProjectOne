---
source_file: "Playbook notes - Passes and products catalogue.md"
type: "rationale"
community: "Passes and products"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Passes_and_products
---

# Benefit-First Pass Naming

## Connections
- [[Pet Simulator 99 Pass Catalogue]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Passes and products catalogue]] - `references` [EXTRACTED]
- [[Simulated Gambling Ban and Odds Disclosure]] - `conceptually_related_to` [INFERRED]

#graphify/rationale #graphify/EXTRACTED #community/Passes_and_products