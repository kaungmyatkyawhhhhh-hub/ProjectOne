---
source_file: "2026-11-05 Research - What the owner clicks on Roblox (10 min watch).md"
type: "document"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# What the owner clicks on Roblox

## Connections
- [[GEM giant thumbnail concept]] - `references` [EXTRACTED]
- [[High CTR Roblox thumbnails]] - `cites` [EXTRACTED]
- [[Owner click patterns (one hero, emotion, one glow, one number)]] - `references` [EXTRACTED]
- [[PLAYBOOK - Roblox icon, thumbnail and logo recipe]] - `cites` [EXTRACTED]
- [[Project Iron]] - `references` [EXTRACTED]
- [[Tryez Lifting Simulator]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks