---
source_file: "2026-11-01 Research - Do cutscenes help, what makes a good one.md"
type: "concept"
community: "Cutscenes and incremental HUDs"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Cutscenes_and_incremental_HUDs
---

# Drop-off happens in the first 90 seconds

## Connections
- [[Do cutscenes help, what makes a good one]] - `references` [EXTRACTED]
- [[Good cutscene checklist (earned, short, skippable, opens a question)]] - `rationale_for` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Cutscenes_and_incremental_HUDs