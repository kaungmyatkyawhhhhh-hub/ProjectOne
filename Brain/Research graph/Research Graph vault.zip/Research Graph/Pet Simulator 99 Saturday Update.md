---
source_file: "Playbook notes - Updates and live ops.md"
type: "concept"
community: "Updates, events and release slot"
location: "L25"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# Pet Simulator 99 Saturday Update

## Connections
- [[GYM ARC Saturday 1500 UTC release rule]] - `references` [EXTRACTED]
- [[Title tags (UPD, EVENT) in game names]] - `references` [EXTRACTED]
- [[Weekly beat (free login gift, fixed daytime)]] - `rationale_for` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Updates_events_and_release_slot