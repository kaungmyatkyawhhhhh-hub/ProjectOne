---
source_file: "Playbook notes - Genres and trends.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L12"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Pet Simulator 99 (BIG Games)

## Connections
- [[Pet Simulator 99 Update 5 Nerfs]] - `conceptually_related_to` [INFERRED]
- [[Roblox Genre Design and Trends]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths