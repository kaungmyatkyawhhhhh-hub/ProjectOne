---
source_file: "Playbook notes - Names and descriptions.md"
type: "concept"
community: "Names, logos and IP safety"
location: "L12"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# Steal a Brainrot

## Connections
- [[Copycat Game Names  Clones]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Names_logos_and_IP_safety