---
source_file: "Playbook notes - Policy, safety and community.md"
type: "concept"
community: "Policy, safety and kids rules"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Policy_safety_and_kids_rules
---

# Roblox Kids and Select Eligibility

## Connections
- [[Ads Manager Engagement Objective]] - `conceptually_related_to` [EXTRACTED]
- [[Maturity & Compliance Questionnaire]] - `rationale_for` [EXTRACTED]
- [[Playbook notes - Policy, safety and community]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Policy_safety_and_kids_rules