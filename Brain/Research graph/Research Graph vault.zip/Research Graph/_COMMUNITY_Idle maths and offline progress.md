---
type: community
cohesion: 0.67
members: 3
---

# Idle maths and offline progress

**Cohesion:** 0.67 - moderately connected
**Members:** 3 nodes

## Members
- [[Economy sinks and sources (LogEconomyEvent)]] - concept - Playbook notes - Whole-game research (Oct 2026).md
- [[Idle progression maths and prestige (Pecorella)]] - concept - Playbook notes - Whole-game research (Oct 2026).md
- [[Offline progress (Pecorella, GDC 2015)]] - concept - Playbook notes - Whole-game research (Oct 2026).md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Idle_maths_and_offline_progress
SORT file.name ASC
```
