---
source_file: "Playbook notes - Analytics and experiments.md"
type: "concept"
community: "Analytics benchmarks and diagnosis"
location: "L26"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Analytics_benchmarks_and_diagnosis
---

# Similar-game Benchmarks

## Connections
- [[Creator Hub Analytics Dashboards]] - `references` [EXTRACTED]
- [[GameAnalytics 2026 Roblox Benchmarks]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Analytics_benchmarks_and_diagnosis