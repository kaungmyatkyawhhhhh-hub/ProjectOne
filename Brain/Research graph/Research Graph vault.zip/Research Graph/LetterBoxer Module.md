---
source_file: "Playbook notes - Lighting, cameras and cutscenes.md"
type: "concept"
community: "Lighting and cameras"
location: "L98"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Lighting_and_cameras
---

# LetterBoxer Module

## Connections
- [[Cutscene Building Methods]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Lighting_and_cameras