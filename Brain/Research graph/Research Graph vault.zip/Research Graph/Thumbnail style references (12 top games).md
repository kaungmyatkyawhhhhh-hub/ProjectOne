---
source_file: "2026-11-05 Research - Thumbnail style references (12 top games).md"
type: "document"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# Thumbnail style references (12 top games)

## Connections
- [[Concept ours, style borrowed rule]] - `references` [EXTRACTED]
- [[Gym League]] - `references` [EXTRACTED]
- [[Muscle Legends]] - `references` [EXTRACTED]
- [[PLAYBOOK - Roblox icon, thumbnail and logo recipe]] - `cites` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks