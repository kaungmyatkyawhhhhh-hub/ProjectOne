---
source_file: "Playbook notes - Admin panels and live tools.md"
type: "concept"
community: "Dead game method and live tools"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Dead_game_method_and_live_tools
---

# Config kill switch pattern

## Connections
- [[Admin panels and live tools]] - `references` [EXTRACTED]
- [[Experience Configs (ConfigService)]] - `implements` [EXTRACTED]
- [[Update day workflow]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Dead_game_method_and_live_tools