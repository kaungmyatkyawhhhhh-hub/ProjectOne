---
type: community
cohesion: 0.18
members: 13
---

# Discovery and ads

**Cohesion:** 0.18 - loosely connected
**Members:** 13 nodes

## Members
- [[Ads Break-even Math]] - rationale - Playbook notes - Genres and trends.md
- [[Ads Manager  Sponsored Ads]] - concept - Playbook notes - Discovery and marketing.md
- [[Ads Manager Reporting and Campaign Judging]] - concept - Playbook notes - Analytics in practice.md
- [[Behaviour-based Quality Judgement]] - concept - Playbook notes - Game quality and QA.md
- [[Charts (Top Playing Now etc.)]] - concept - Playbook notes - Discovery and marketing.md
- [[Creator Rewards and Share Links]] - concept - Playbook notes - Discovery and marketing.md
- [[Experience Notifications_1]] - concept - Playbook notes - Discovery and marketing.md
- [[ExploreExpand Testing]] - concept - Playbook notes - Discovery and marketing.md
- [[Friend Invite Reward System]] - concept - Playbook notes - Discovery and marketing.md
- [[RFY Discovery Signals (28-day, June 2026)]] - concept - Playbook notes - Analytics and experiments.md
- [[Recommended For You Algorithm]] - concept - Playbook notes - Discovery and marketing.md
- [[Rewarded Video Ads]] - concept - Playbook notes - Discovery and marketing.md
- [[Roblox Discovery and Marketing]] - document - Playbook notes - Discovery and marketing.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Discovery_and_ads
SORT file.name ASC
```

## Connections to other communities
- 3 edges to [[_COMMUNITY_Titles, search and copycat rules]]
- 1 edge to [[_COMMUNITY_Analytics events]]
- 1 edge to [[_COMMUNITY_Analytics benchmarks and diagnosis]]
- 1 edge to [[_COMMUNITY_Quality and polish]]
- 1 edge to [[_COMMUNITY_Solo QA]]

## Top bridge nodes
- [[Roblox Discovery and Marketing]] - degree 9, connects to 2 communities
- [[Recommended For You Algorithm]] - degree 7, connects to 1 community
- [[RFY Discovery Signals (28-day, June 2026)]] - degree 2, connects to 1 community
- [[Ads Manager Reporting and Campaign Judging]] - degree 2, connects to 1 community
- [[Behaviour-based Quality Judgement]] - degree 2, connects to 1 community