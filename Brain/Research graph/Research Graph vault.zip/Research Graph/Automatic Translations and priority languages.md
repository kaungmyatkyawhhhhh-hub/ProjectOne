---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "Translations"
location: "L42"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Translations
---

# Automatic Translations and priority languages

#graphify/concept #graphify/EXTRACTED #community/Translations