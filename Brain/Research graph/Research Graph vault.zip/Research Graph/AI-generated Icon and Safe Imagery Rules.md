---
source_file: "Playbook notes - Icons and titles.md"
type: "concept"
community: "Lighting and cameras"
location: "L98"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Lighting_and_cameras
---

# AI-generated Icon and Safe Imagery Rules

## Connections
- [[Roblox Experience Icons, Titles and Descriptions]] - `references` [EXTRACTED]
- [[ThumbnailIcon Photo-booth Capture]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Lighting_and_cameras