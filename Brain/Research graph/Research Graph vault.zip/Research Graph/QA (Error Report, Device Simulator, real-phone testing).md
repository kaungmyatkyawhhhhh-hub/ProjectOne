---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "QA basics"
location: "L71"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/QA_basics
---

# QA (Error Report, Device Simulator, real-phone testing)

#graphify/concept #graphify/EXTRACTED #community/QA_basics