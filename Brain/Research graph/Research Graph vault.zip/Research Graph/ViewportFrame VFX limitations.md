---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L53"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# ViewportFrame VFX limitations

## Connections
- [[UIGradient shine (GUI Shine Module)]] - `rationale_for` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles