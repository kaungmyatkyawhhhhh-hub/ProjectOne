---
source_file: "2026-11-01 Research - Modeling like a professional (stylized low poly).md"
type: "concept"
community: "Trending games and next game ideas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Trending_games_and_next_game_ideas
---

# Supernova kit style guide (round + brass, faceted crystals)

## Connections
- [[Galaxy Incremental (was Supernova Incremental)]] - `conceptually_related_to` [EXTRACTED]
- [[Modeling like a professional (stylized low poly)]] - `references` [EXTRACTED]
- [[Stylized low-poly modeling principles]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Trending_games_and_next_game_ideas