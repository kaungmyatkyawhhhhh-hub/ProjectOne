---
source_file: "Playbook notes - UI, game feel, art and sound.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Automatic Translation (18 languages)

## Connections
- [[9-Slice UI Design]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - UI, game feel, art and sound]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel