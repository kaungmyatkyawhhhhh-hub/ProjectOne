---
source_file: "Playbook notes - UI deep dive.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Four Button States

## Connections
- [[Chunky Kids' Simulator Button Recipe]] - `conceptually_related_to` [INFERRED]
- [[Playbook notes - UI deep dive]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel