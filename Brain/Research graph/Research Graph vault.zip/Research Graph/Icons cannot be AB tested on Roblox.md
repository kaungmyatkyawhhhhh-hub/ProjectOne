---
source_file: "2026-10-30 Icon and thumbnail testing.md"
type: "rationale"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# Icons cannot be A/B tested on Roblox

## Connections
- [[Icon and thumbnail testing]] - `references` [EXTRACTED]
- [[Qualified Play Through Rate (qPTR)]] - `conceptually_related_to` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks