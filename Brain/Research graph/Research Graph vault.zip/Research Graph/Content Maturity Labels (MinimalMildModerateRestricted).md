---
source_file: "Playbook notes - Policy, safety and community.md"
type: "concept"
community: "Policy, safety and kids rules"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Policy_safety_and_kids_rules
---

# Content Maturity Labels (Minimal/Mild/Moderate/Restricted)

## Connections
- [[Free-Form User Creation Restriction (16+)]] - `conceptually_related_to` [EXTRACTED]
- [[Maturity & Compliance Questionnaire]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Policy, safety and community]] - `references` [EXTRACTED]
- [[Simulated Gambling Ban and Odds Disclosure]] - `conceptually_related_to` [EXTRACTED]
- [[Social Hangout Age Restriction]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Policy_safety_and_kids_rules