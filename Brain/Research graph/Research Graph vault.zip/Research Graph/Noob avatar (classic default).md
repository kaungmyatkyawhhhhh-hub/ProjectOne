---
source_file: "2026-11-03 Research - Bacon hair in thumbnails.md"
type: "concept"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# Noob avatar (classic default)

## Connections
- [[Bacon Hair (Pal Hair default avatar)]] - `conceptually_related_to` [EXTRACTED]
- [[Bacon hair in thumbnails]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks