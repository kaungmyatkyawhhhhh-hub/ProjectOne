---
source_file: "Playbook notes - Genres and trends.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L51"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Splitting Point Studios

## Connections
- [[Grow a Garden (trend case)]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths