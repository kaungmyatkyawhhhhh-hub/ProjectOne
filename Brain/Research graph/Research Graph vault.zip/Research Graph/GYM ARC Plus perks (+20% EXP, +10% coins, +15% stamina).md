---
source_file: "2026-10-31 Roblox Plus.md"
type: "concept"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# GYM ARC Plus perks (+20% EXP, +10% coins, +15% stamina)

## Connections
- [[GYM ARC]] - `conceptually_related_to` [EXTRACTED]
- [[Player.HasRobloxSubscription]] - `conceptually_related_to` [INFERRED]
- [[Roblox Plus for developers]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks