---
source_file: "Playbook notes - Icons and titles.md"
type: "concept"
community: "Titles, search and copycat rules"
location: "L23"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Titles_search_and_copycat_rules
---

# Discovery Copycat Grouping by Images

## Connections
- [[Game Title Conventions]] - `conceptually_related_to` [EXTRACTED]
- [[Near-copy Deprioritization]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Titles_search_and_copycat_rules