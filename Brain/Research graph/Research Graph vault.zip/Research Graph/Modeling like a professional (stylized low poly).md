---
source_file: "2026-11-01 Research - Modeling like a professional (stylized low poly).md"
type: "document"
community: "Trending games and next game ideas"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Trending_games_and_next_game_ideas
---

# Modeling like a professional (stylized low poly)

## Connections
- [[Blender Python model pipeline (vertex colours, .fbx)]] - `references` [EXTRACTED]
- [[Stylized low-poly modeling principles]] - `references` [EXTRACTED]
- [[Supernova kit style guide (round + brass, faceted crystals)]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Trending_games_and_next_game_ideas