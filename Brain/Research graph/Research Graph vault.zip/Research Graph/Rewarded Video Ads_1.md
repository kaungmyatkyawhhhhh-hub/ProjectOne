---
source_file: "Playbook notes - Monetization.md"
type: "concept"
community: "Receipts and rewarded ads"
location: "L50"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Receipts_and_rewarded_ads
---

# Rewarded Video Ads

## Connections
- [[MarketplaceService.ProcessReceipt Pattern]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Receipts_and_rewarded_ads