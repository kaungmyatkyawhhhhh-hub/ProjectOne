---
source_file: "Playbook notes - Core loop design.md"
type: "document"
community: "Core loop, incrementals and trends maths"
location: "L1"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Core Loop Design for Roblox Simulators and Casual Games

## Connections
- [[Core Loop (Katkoff dual session loops)]] - `references` [EXTRACTED]
- [[Currency Sources and Sinks]] - `references` [EXTRACTED]
- [[Grow a Garden_2]] - `references` [EXTRACTED]
- [[Indicative Kill-or-Iterate Thresholds]] - `references` [EXTRACTED]
- [[Kongregate Idle Game Math (Pecorella)]] - `references` [EXTRACTED]
- [[MDA Framework]] - `references` [EXTRACTED]
- [[Roblox Paid Random Items Policy]] - `references` [EXTRACTED]
- [[Self-Determination Theory (autonomy, competence, relatedness)]] - `references` [EXTRACTED]
- [[Steal a Brainrot]] - `references` [EXTRACTED]
- [[Supercell Kill Culture]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths