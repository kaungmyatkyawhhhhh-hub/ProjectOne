---
source_file: "Playbook notes - Genres and trends.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L76"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Dead Rails

## Connections
- [[Roblox Genre Design and Trends]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths