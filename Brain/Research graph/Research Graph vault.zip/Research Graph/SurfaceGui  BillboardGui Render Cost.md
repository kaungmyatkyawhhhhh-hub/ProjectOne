---
source_file: "Playbook notes - Optimization deep dive.md"
type: "concept"
community: "Optimization and retention mechanics"
location: "L212"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# SurfaceGui / BillboardGui Render Cost

## Connections
- [[MicroProfiler Tag Table]] - `references` [EXTRACTED]
- [[Prioritized Optimization Checklist]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Optimization_and_retention_mechanics