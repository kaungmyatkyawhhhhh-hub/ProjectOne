---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "concept"
community: "Names, logos and IP safety"
location: "L564"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/Names_logos_and_IP_safety
---

# ViewportFrame Portrait Recipe (Coach Dex)

## Connections
- [[Coach Dex]] - `implements` [EXTRACTED]
- [[HumanoidDescription NPC Building]] - `conceptually_related_to` [INFERRED]
- [[Never Ship AI Images Rule]] - `rationale_for` [INFERRED]

#graphify/concept #graphify/INFERRED #community/Names_logos_and_IP_safety