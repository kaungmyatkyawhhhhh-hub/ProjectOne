---
source_file: "Playbook notes - UI deep dive.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Rarity Colour Ladder

## Connections
- [[512x512 Circular-Cropped Pass Icons]] - `conceptually_related_to` [INFERRED]
- [[Colour and Hierarchy Rules]] - `conceptually_related_to` [INFERRED]
- [[Playbook notes - UI deep dive]] - `references` [EXTRACTED]
- [[Reward Screen Anatomy]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel