---
source_file: "Playbook notes - Game quality and QA.md"
type: "concept"
community: "Solo QA"
location: "L86"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Solo_QA
---

# Experience Betas (QA)

## Connections
- [[Experience Betas]] - `semantically_similar_to` [INFERRED]
- [[Solo QA Process]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Solo_QA