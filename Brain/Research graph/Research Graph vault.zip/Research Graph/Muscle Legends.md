---
source_file: "2026-11-05 Research - Thumbnail style references (12 top games).md"
type: "concept"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# Muscle Legends

## Connections
- [[Concept ours, style borrowed rule]] - `references` [EXTRACTED]
- [[Thumbnail style references (12 top games)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks