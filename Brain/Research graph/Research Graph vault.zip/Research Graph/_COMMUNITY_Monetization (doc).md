---
type: community
cohesion: 1.00
members: 1
---

# Monetization (doc)

**Cohesion:** 1.00 - tightly connected
**Members:** 1 nodes

## Members
- [[Playbook notes - Monetization]] - document - Playbook notes - Monetization.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Monetization_doc
SORT file.name ASC
```
