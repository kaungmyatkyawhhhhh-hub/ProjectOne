---
source_file: "Playbook notes - Genres and trends.md"
type: "rationale"
community: "Discovery and ads"
location: "L188"
tags:
  - graphify/rationale
  - graphify/INFERRED
  - community/Discovery_and_ads
---

# Ads Break-even Math

## Connections
- [[Ads Manager  Sponsored Ads]] - `conceptually_related_to` [INFERRED]

#graphify/rationale #graphify/INFERRED #community/Discovery_and_ads