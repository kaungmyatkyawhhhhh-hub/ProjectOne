---
source_file: "Playbook notes - Onboarding, retention and live ops.md"
type: "rationale"
community: "Names, logos and IP safety"
location: "L81"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# Suggested Simulator Funnel Steps

## Connections
- [[AnalyticsService Onboarding Funnel Events]] - `implements` [EXTRACTED]
- [[Creator Rewards 10-Minute Threshold]] - `rationale_for` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Names_logos_and_IP_safety