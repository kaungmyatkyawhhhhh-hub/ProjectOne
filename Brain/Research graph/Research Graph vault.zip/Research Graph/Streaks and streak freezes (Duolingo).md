---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "Streaks"
location: "L28"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Streaks
---

# Streaks and streak freezes (Duolingo)

#graphify/concept #graphify/EXTRACTED #community/Streaks