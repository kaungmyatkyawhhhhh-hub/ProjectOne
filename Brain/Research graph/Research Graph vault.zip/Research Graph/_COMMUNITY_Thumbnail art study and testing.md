---
type: community
cohesion: 0.14
members: 26
---

# Thumbnail art study and testing

**Cohesion:** 0.14 - loosely connected
**Members:** 26 nodes

## Members
- [[AI-Looking Thumbnail Signals]] - concept - Playbook notes - Thumbnails.md
- [[Clickbait and Honesty Rules]] - rationale - Playbook notes - Thumbnails.md
- [[Custom Thumbnail Required for Home (Oct 2026)]] - concept - Playbook notes - Thumbnails.md
- [[Face as the Hook]] - concept - Playbook notes - Top games art study (Oct 2026).md
- [[Fixed Thumbnail Template]] - rationale - Playbook notes - Top games art study (Oct 2026).md
- [[Four Top-Game Art Styles]] - concept - Playbook notes - Top games art study (Oct 2026).md
- [[GYM ARC_1]] - concept - Playbook notes - Top games art study (Oct 2026).md
- [[GYM ARC Art Direction]] - concept - Playbook notes - Top games art study (Oct 2026).md
- [[GYM ARC ChatGPT ThumbnailIcon Prompts]] - concept - Playbook notes - Top games art study (Oct 2026).md
- [[Gameplay Video Previews]] - concept - Playbook notes - Thumbnails.md
- [[Gym League Gold Muscle God Look]] - concept - Playbook notes - Top games art study (Oct 2026).md
- [[Height Growth Hook]] - rationale - Playbook notes - Top games art study (Oct 2026).md
- [[IconThumbnail Upload Checklist]] - concept - Playbook notes - Top games art study (Oct 2026).md
- [[Include Existing Winner in New Tests]] - rationale - Playbook notes - Thumbnails.md
- [[One Idea in Half a Second]] - rationale - Playbook notes - Top games art study (Oct 2026).md
- [[PTR  qPTR Ranking Signals]] - concept - Playbook notes - Thumbnails.md
- [[Playbook notes - Thumbnails]] - document - Playbook notes - Thumbnails.md
- [[Playbook notes - Top games art study (Oct 2026)]] - document - Playbook notes - Top games art study (Oct 2026).md
- [[Premium Art Style (B)]] - concept - Playbook notes - Top games art study (Oct 2026).md
- [[Rights Manager IP Claims]] - concept - Playbook notes - Policy, safety and community.md
- [[Simulator Formula Style (C)]] - concept - Playbook notes - Top games art study (Oct 2026).md
- [[Simulator Thumbnail Composition (hero + payoff)]] - concept - Playbook notes - Thumbnails.md
- [[Slop vs Premium Art Criteria]] - concept - Playbook notes - Top games art study (Oct 2026).md
- [[Standout Games Home Shelf]] - concept - Playbook notes - Thumbnails.md
- [[Thumbnail Personalization (multi-armed bandit)]] - concept - Playbook notes - Thumbnails.md
- [[Thumbnail Specs (169 1920x1080, 3 MB)]] - concept - Playbook notes - Thumbnails.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Thumbnail_art_study_and_testing
SORT file.name ASC
```

## Connections to other communities
- 1 edge to [[_COMMUNITY_Policy, safety and kids rules]]

## Top bridge nodes
- [[Rights Manager IP Claims]] - degree 2, connects to 1 community