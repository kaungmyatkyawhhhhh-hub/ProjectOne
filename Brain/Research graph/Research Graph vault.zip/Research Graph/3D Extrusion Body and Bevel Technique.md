---
source_file: "Playbook notes - Logos.md"
type: "concept"
community: "Logos, loading screen and GYM ARC art"
location: "L13"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Logos_loading_screen_and_GYM_ARC_art
---

# 3D Extrusion Body and Bevel Technique

## Connections
- [[DevForum Basics of Game Logo Design Tutorial]] - `cites` [EXTRACTED]
- [[Roblox Game Logo Layer Recipe]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Logos_loading_screen_and_GYM_ARC_art