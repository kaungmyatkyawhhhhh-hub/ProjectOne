---
type: community
cohesion: 0.13
members: 20
---

# Weekly updates and trainer collection

**Cohesion:** 0.13 - loosely connected
**Members:** 20 nodes

## Members
- [[Admin Abuse  Power Hour Warm-up]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Admin Abuse Events  Admin War]] - concept - Playbook notes - Onboarding, retention and live ops.md
- [[Collection Book (Trainer Index)]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Endowed Progress Effect]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Experience Events, Update Announcements and Notifications]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Experience Notifications (Open Cloud)]] - concept - Playbook notes - Onboarding, retention and live ops.md
- [[GYM ARC Ranked Retention Plan]] - rationale - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Grow a Garden]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Grow a Garden_1]] - concept - Playbook notes - Onboarding, retention and live ops.md
- [[HALL OF FAME Launch (31 Oct 2026)]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[LiveOps Update Cadence]] - concept - Playbook notes - Onboarding, retention and live ops.md
- [[Paid Random Items Policy]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Paid Random Items Policy_1]] - concept - Playbook notes - Monetization.md
- [[Paid Random Items Policy_2]] - concept - Playbook notes - Onboarding, retention and live ops.md
- [[PolicyService (ArePaidRandomItemsRestricted)]] - concept - Playbook notes - Monetization.md
- [[Premium vs AI-Slop Visual Rules]] - rationale - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Recovery Growth (Offline Progress)]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Safe Kids' Simulator Retention Stack]] - rationale - Playbook notes - Onboarding, retention and live ops.md
- [[Trainer Inventory UX Spec]] - rationale - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Weekly Saturday Update Template]] - rationale - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Weekly_updates_and_trainer_collection
SORT file.name ASC
```

## Connections to other communities
- 2 edges to [[_COMMUNITY_Optimization and retention mechanics]]
- 1 edge to [[_COMMUNITY_Names, logos and IP safety]]

## Top bridge nodes
- [[Grow a Garden_1]] - degree 5, connects to 1 community
- [[Grow a Garden]] - degree 4, connects to 1 community
- [[GYM ARC Ranked Retention Plan]] - degree 4, connects to 1 community