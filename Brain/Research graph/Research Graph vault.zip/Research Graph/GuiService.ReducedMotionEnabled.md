---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L105"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# GuiService.ReducedMotionEnabled

## Connections
- [[Accessibility settings (ReducedMotion, PreferredTextSize, PreferredTransparency)]] - `references` [INFERRED]
- [[Camera shake, FOV punch and hit-stop]] - `references` [EXTRACTED]
- [[Level-up recipe]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles