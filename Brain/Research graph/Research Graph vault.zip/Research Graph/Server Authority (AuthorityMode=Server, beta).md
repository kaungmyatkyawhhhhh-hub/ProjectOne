---
source_file: "Playbook notes - Performance, data and security.md"
type: "concept"
community: "Performance, data and security"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Performance_data_and_security
---

# Server Authority (AuthorityMode=Server, beta)

## Connections
- [[Instance Streaming (Opportunistic stream-out)]] - `references` [EXTRACTED]
- [[Playbook notes - Performance, data and security]] - `references` [EXTRACTED]
- [[Server-Authoritative Remote Validation]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Performance_data_and_security