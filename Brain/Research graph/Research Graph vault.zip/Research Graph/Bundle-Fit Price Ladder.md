---
source_file: "Playbook notes - Passes and products catalogue.md"
type: "rationale"
community: "Passes and products"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Passes_and_products
---

# Bundle-Fit Price Ladder

## Connections
- [[Converting Shop Layout]] - `conceptually_related_to` [INFERRED]
- [[Playbook notes - Passes and products catalogue]] - `references` [EXTRACTED]
- [[Robux Bundle Sizes (4008001700450010000)]] - `rationale_for` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Passes_and_products