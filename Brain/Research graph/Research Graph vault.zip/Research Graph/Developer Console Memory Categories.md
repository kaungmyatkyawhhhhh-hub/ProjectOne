---
source_file: "Playbook notes - Optimization deep dive.md"
type: "concept"
community: "Memory debugging"
location: "L117"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Memory_debugging
---

# Developer Console Memory Categories

## Connections
- [[Luau Heap Snapshots]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Memory_debugging