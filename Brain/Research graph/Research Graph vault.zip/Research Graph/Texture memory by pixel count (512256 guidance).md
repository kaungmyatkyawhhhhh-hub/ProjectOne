---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L79"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# Texture memory by pixel count (512/256 guidance)

## Connections
- [[Grayscale textures tinted in-engine]] - `conceptually_related_to` [EXTRACTED]
- [[Particle flipbooks (Grid layouts, max 30 fps, auto-off on low memory)]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles