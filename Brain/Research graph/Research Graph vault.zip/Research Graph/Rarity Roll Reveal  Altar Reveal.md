---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "concept"
community: "Optimization and retention mechanics"
location: "L154"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# Rarity Roll Reveal / Altar Reveal

## Connections
- [[GYM ARC Aura Tier Recipe]] - `references` [EXTRACTED]
- [[Sol's RNG_1]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Optimization_and_retention_mechanics