---
source_file: "Playbook notes - Costly mistakes of big games.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L45"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# GYM ARC Hall of Fame

## Connections
- [[GYM ARC Rules Check]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths