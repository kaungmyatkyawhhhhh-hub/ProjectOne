---
type: community
cohesion: 0.07
members: 50
---

# Icons, thumbnails and owner clicks

**Cohesion:** 0.07 - loosely connected
**Members:** 50 nodes

## Members
- [[Bacon Hair (Pal Hair default avatar)]] - concept - 2026-11-03 Research - Bacon hair in thumbnails.md
- [[Bacon growth-row thumbnail (4'0 - 5'8 - 7'0)]] - concept - 2026-11-03 Research - Bacon hair in thumbnails.md
- [[Bacon hair in thumbnails]] - document - 2026-11-03 Research - Bacon hair in thumbnails.md
- [[Baseball Zero logo]] - concept - 2026-11-05 Research - Roblox GFX logo style (owner refs).md
- [[Bright white face rule]] - concept - 2026-11-05 PLAYBOOK - Roblox icon, thumbnail and logo recipe.md
- [[ChatGPT final-art pipeline (real render + one style ref + logo)]] - concept - 2026-11-05 PLAYBOOK - Roblox icon, thumbnail and logo recipe.md
- [[Concept ours, style borrowed rule]] - concept - 2026-11-05 Research - Thumbnail style references (12 top games).md
- [[Fake checkerboard key-out]] - concept - 2026-11-05 Research - Roblox GFX logo style (owner refs).md
- [[Flexpose-off battle for GYM ARC]] - rationale - 2026-11-06 Research - Mogging games (next game idea).md
- [[GEM giant thumbnail concept]] - concept - 2026-11-05 Research - What the owner clicks on Roblox (10 min watch).md
- [[GYM ARC]] - concept - 2026-10-30 Icon and thumbnail testing.md
- [[GYM ARC Plus perks (+20% EXP, +10% coins, +15% stamina)]] - concept - 2026-10-31 Roblox Plus.md
- [[GYM ARC barbell-overhead Hall of Fame icon]] - concept - 2026-10-30 Icon and thumbnail testing.md
- [[GYM ARC logo (final v6v7)]] - concept - 2026-11-05 Research - Roblox GFX logo style (owner refs).md
- [[Gym League]] - concept - 2026-11-05 Research - Thumbnail style references (12 top games).md
- [[Gym Star Simulator]] - concept - 2026-11-03 Research - Gym, simulator and evolution thumbnails (owner screenshots).md
- [[Gym, simulator and evolution thumbnails]] - document - 2026-11-03 Research - Gym, simulator and evolution thumbnails (owner screenshots).md
- [[Gymsimulator thumbnail rules (one hero, bright bg, progress numbers)]] - rationale - 2026-11-03 Research - Gym, simulator and evolution thumbnails (owner screenshots).md
- [[High CTR Roblox thumbnails]] - document - 2026-11-03 Research - High CTR Roblox thumbnails.md
- [[High-CTR thumbnail design rules]] - rationale - 2026-11-03 Research - High CTR Roblox thumbnails.md
- [[Icon and thumbnail testing]] - document - 2026-10-30 Icon and thumbnail testing.md
- [[Icon contrast test (10-15% white, 40-50% black at 64 px)]] - concept - 2026-11-05 PLAYBOOK - Roblox icon, thumbnail and logo recipe.md
- [[Icons cannot be AB tested on Roblox]] - rationale - 2026-10-30 Icon and thumbnail testing.md
- [[Mog and Gym (Looksmax and Mog)]] - concept - 2026-11-06 Research - Mogging games (next game idea).md
- [[Mogging games (next game idea)]] - document - 2026-11-06 Research - Mogging games (next game idea).md
- [[Muscle Legends]] - concept - 2026-11-05 Research - Thumbnail style references (12 top games).md
- [[Noob avatar (classic default)]] - concept - 2026-11-03 Research - Bacon hair in thumbnails.md
- [[One-try ChatGPT prompt templates]] - rationale - 2026-11-05 PLAYBOOK - Roblox icon, thumbnail and logo recipe.md
- [[Owner click patterns (one hero, emotion, one glow, one number)]] - concept - 2026-11-05 Research - What the owner clicks on Roblox (10 min watch).md
- [[PLAYBOOK - Roblox icon, thumbnail and logo recipe]] - document - 2026-11-05 PLAYBOOK - Roblox icon, thumbnail and logo recipe.md
- [[Player.HasRobloxSubscription]] - concept - 2026-10-31 Roblox Plus.md
- [[Power Lifters]] - concept - 2026-11-03 Research - Gym, simulator and evolution thumbnails (owner screenshots).md
- [[Project Iron]] - concept - 2026-11-05 Research - What the owner clicks on Roblox (10 min watch).md
- [[Qualified Play Through Rate (qPTR)]] - concept - 2026-10-30 Icon and thumbnail testing.md
- [[Roblox GFX logo style_1]] - document - 2026-11-05 Research - Roblox GFX logo style (owner refs).md
- [[Roblox GFX logo style]] - concept - 2026-11-05 Research - Roblox GFX logo style (owner refs).md
- [[Roblox Plus for developers]] - document - 2026-10-31 Roblox Plus.md
- [[Roblox Plus subscriber payouts (250 Robuxmonth x3)]] - concept - 2026-10-31 Roblox Plus.md
- [[Roblox Plus subscription]] - concept - 2026-10-31 Roblox Plus.md
- [[Roblox icon, thumbnail and logo recipe]] - concept - 2026-11-05 PLAYBOOK - Roblox icon, thumbnail and logo recipe.md
- [[Search shows first 169 gallery image (since 16 Mar 2026)]] - concept - 2026-11-03 Research - High CTR Roblox thumbnails.md
- [[Thumbnail Personalization]] - rationale - 2026-10-30 Icon and thumbnail testing.md
- [[Thumbnail style references (12 top games)]] - document - 2026-11-05 Research - Thumbnail style references (12 top games).md
- [[TopBar refreshVisible watchdog fix]] - rationale - 2026-10-30 TopbarPlus not showing.md
- [[TopbarPlus (v3.4.0  v3.5.0)]] - concept - 2026-10-30 TopbarPlus not showing.md
- [[TopbarPlus not showing]] - document - 2026-10-30 TopbarPlus not showing.md
- [[Training Simulator]] - concept - 2026-11-03 Research - Gym, simulator and evolution thumbnails (owner screenshots).md
- [[Tryez Lifting Simulator]] - concept - 2026-11-05 Research - What the owner clicks on Roblox (10 min watch).md
- [[What the owner clicks on Roblox]] - document - 2026-11-05 Research - What the owner clicks on Roblox (10 min watch).md
- [[qPTR funnel (impression CTR x details CTR x 5-min play)]] - concept - 2026-11-03 Research - High CTR Roblox thumbnails.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Icons_thumbnails_and_owner_clicks
SORT file.name ASC
```

## Connections to other communities
- 7 edges to [[_COMMUNITY_Trending games and next game ideas]]
- 1 edge to [[_COMMUNITY_Atlas story]]
- 1 edge to [[_COMMUNITY_Cutscenes and incremental HUDs]]

## Top bridge nodes
- [[GYM ARC]] - degree 13, connects to 3 communities
- [[PLAYBOOK - Roblox icon, thumbnail and logo recipe]] - degree 9, connects to 1 community
- [[Owner click patterns (one hero, emotion, one glow, one number)]] - degree 9, connects to 1 community
- [[Bacon Hair (Pal Hair default avatar)]] - degree 5, connects to 1 community
- [[Gym, simulator and evolution thumbnails]] - degree 5, connects to 1 community