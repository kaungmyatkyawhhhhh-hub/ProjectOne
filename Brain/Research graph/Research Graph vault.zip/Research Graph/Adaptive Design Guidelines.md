---
source_file: "Playbook notes - UI, game feel, art and sound.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Adaptive Design Guidelines

## Connections
- [[Gamepad Selection Checklist]] - `conceptually_related_to` [INFERRED]
- [[Playbook notes - UI, game feel, art and sound]] - `references` [EXTRACTED]
- [[ScreenInsets CoreUISafeInsets]] - `conceptually_related_to` [EXTRACTED]
- [[UIListLayout Flex Layouts]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel