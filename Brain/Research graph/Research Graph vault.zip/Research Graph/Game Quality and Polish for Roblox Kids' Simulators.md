---
source_file: "Playbook notes - Game quality and QA.md"
type: "document"
community: "Quality and polish"
location: "L1"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Quality_and_polish
---

# Game Quality and Polish for Roblox Kids' Simulators

## Connections
- [[AI Coding Pain Points on Roblox]] - `references` [EXTRACTED]
- [[Art Style Guide and Asset Kit]] - `references` [EXTRACTED]
- [[Behaviour-based Quality Judgement]] - `references` [EXTRACTED]
- [[Game Feel  Juice]] - `references` [EXTRACTED]
- [[Polish Checklist]] - `references` [EXTRACTED]
- [[Solo QA Process]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Quality_and_polish