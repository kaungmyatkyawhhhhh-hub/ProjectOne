---
source_file: "Playbook notes - Onboarding, retention and live ops.md"
type: "concept"
community: "Names, logos and IP safety"
location: "L57"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# AnalyticsService Onboarding Funnel Events

## Connections
- [[Roblox Onboarding Techniques (visual, contextual, timed hints)]] - `conceptually_related_to` [EXTRACTED]
- [[Suggested Simulator Funnel Steps]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Names_logos_and_IP_safety