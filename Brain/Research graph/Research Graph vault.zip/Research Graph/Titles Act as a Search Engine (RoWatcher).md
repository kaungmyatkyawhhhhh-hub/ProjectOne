---
source_file: "Playbook notes - Names and descriptions.md"
type: "concept"
community: "Names, logos and IP safety"
location: "L15"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# Titles Act as a Search Engine (RoWatcher)

## Connections
- [[Hybrid Name Formula (Brand Word + Genre Keyword)]] - `cites` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Names_logos_and_IP_safety