---
source_file: "Playbook notes - Analytics and experiments.md"
type: "concept"
community: "Titles, search and copycat rules"
location: "L84"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Titles_search_and_copycat_rules
---

# Thumbnail Personalization

## Connections
- [[15 June 2026 RFY Change (28-day window)]] - `references` [EXTRACTED]
- [[Analytics and Experimentation for Roblox Experiences]] - `references` [EXTRACTED]
- [[No Icon AB Testing]] - `references` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Titles_search_and_copycat_rules