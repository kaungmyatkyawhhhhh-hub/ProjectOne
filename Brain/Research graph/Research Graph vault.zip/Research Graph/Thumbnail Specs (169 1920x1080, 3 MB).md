---
source_file: "Playbook notes - Thumbnails.md"
type: "concept"
community: "Thumbnail art study and testing"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Thumbnail_art_study_and_testing
---

# Thumbnail Specs (16:9 1920x1080, <3 MB)

## Connections
- [[Custom Thumbnail Required for Home (Oct 2026)]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Thumbnails]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Thumbnail_art_study_and_testing