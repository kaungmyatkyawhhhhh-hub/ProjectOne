---
source_file: "2026-11-01 Research - Popular incremental HUD layouts.md"
type: "document"
community: "Cutscenes and incremental HUDs"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Cutscenes_and_incremental_HUDs
---

# Popular incremental HUD layouts

## Connections
- [[7 shared incremental HUD rules]] - `references` [EXTRACTED]
- [[Astronomer star-chart UI motif]] - `references` [EXTRACTED]
- [[Avoiding the AI-made look]] - `references` [EXTRACTED]
- [[Immortality Incremental]] - `references` [EXTRACTED]
- [[Noob Incremental]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Cutscenes_and_incremental_HUDs