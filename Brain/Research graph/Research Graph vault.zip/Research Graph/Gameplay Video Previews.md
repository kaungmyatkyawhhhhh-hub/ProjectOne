---
source_file: "Playbook notes - Thumbnails.md"
type: "concept"
community: "Thumbnail art study and testing"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Thumbnail_art_study_and_testing
---

# Gameplay Video Previews

## Connections
- [[Playbook notes - Thumbnails]] - `references` [EXTRACTED]
- [[Standout Games Home Shelf]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Thumbnail_art_study_and_testing