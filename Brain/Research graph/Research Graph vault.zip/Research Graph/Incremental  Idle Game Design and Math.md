---
source_file: "Playbook notes - Incremental games.md"
type: "document"
community: "Core loop, incrementals and trends maths"
location: "L1"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Incremental / Idle Game Design and Math

## Connections
- [[Antimatter Dimensions Infinity Layer]] - `references` [EXTRACTED]
- [[Big Number Libraries (break_infinity, Quicknum, APInt)]] - `references` [EXTRACTED]
- [[Common Incremental Design Mistakes]] - `references` [EXTRACTED]
- [[Exponential Cost vs Polynomial Production Seesaw]] - `references` [EXTRACTED]
- [[GYM ARC Alter Prestige Gaps]] - `references` [EXTRACTED]
- [[Generators of Generators]] - `references` [EXTRACTED]
- [[Grass Cutting Incremental]] - `references` [EXTRACTED]
- [[Offline Progress]] - `references` [EXTRACTED]
- [[Prestige Formulas (Realm Grinder, AdCap, Cookie Clicker, Egg Inc.)]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths