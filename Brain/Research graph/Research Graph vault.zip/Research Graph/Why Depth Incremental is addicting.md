---
source_file: "2026-11-06 Research - Depth Incremental (10 videos watched).md"
type: "rationale"
community: "Trending games and next game ideas"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Trending_games_and_next_game_ideas
---

# Why Depth Incremental is addicting

## Connections
- [[+1 Depth Incremental]] - `rationale_for` [EXTRACTED]
- [[+1 SHRINK]] - `conceptually_related_to` [EXTRACTED]
- [[Curiosity drives playtime (CHI 2024 study)]] - `semantically_similar_to` [INFERRED]
- [[Depth Incremental (10 videos watched)]] - `references` [EXTRACTED]
- [[Galaxy distance how far bar]] - `conceptually_related_to` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Trending_games_and_next_game_ideas