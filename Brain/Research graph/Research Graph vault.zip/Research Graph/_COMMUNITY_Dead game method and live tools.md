---
type: community
cohesion: 0.13
members: 26
---

# Dead game method and live tools

**Cohesion:** 0.13 - loosely connected
**Members:** 26 nodes

## Members
- [[Admin abuse events_1]] - concept - Playbook notes - Admin panels and live tools.md
- [[Admin panels and live tools]] - document - Playbook notes - Admin panels and live tools.md
- [[Adonis]] - concept - Playbook notes - Admin panels and live tools.md
- [[Atlas Reactor]] - concept - 2026-11-09 Research - Dead game method (shut-down multiplayer games as an idea library).md
- [[Club Penguin]] - concept - 2026-11-09 Research - Dead game method (shut-down multiplayer games as an idea library).md
- [[Config kill switch pattern]] - concept - Playbook notes - Admin panels and live tools.md
- [[Dead Game Method]] - document - 2026-11-09 Research - Dead game method (shut-down multiplayer games as an idea library).md
- [[Dead Game Method_1]] - rationale - 2026-11-09 Research - Dead game method (shut-down multiplayer games as an idea library).md
- [[ELEMENT DODGE concept]] - concept - 2026-11-09 Research - Dead game method (shut-down multiplayer games as an idea library).md
- [[EventController server module]] - concept - Playbook notes - Admin panels and live tools.md
- [[Evolve]] - concept - 2026-11-09 Research - Dead game method (shut-down multiplayer games as an idea library).md
- [[Experience Configs (ConfigService)]] - concept - Playbook notes - Admin panels and live tools.md
- [[HD Admin]] - concept - Playbook notes - Admin panels and live tools.md
- [[Knockout City]] - concept - 2026-11-09 Research - Dead game method (shut-down multiplayer games as an idea library).md
- [[MONSTER GROW concept]] - concept - 2026-11-09 Research - Dead game method (shut-down multiplayer games as an idea library).md
- [[MessagingService]] - concept - Playbook notes - Admin panels and live tools.md
- [[Monthly free party event]] - concept - 2026-11-09 Research - Dead game method (shut-down multiplayer games as an idea library).md
- [[PET PARTY PLAZA concept]] - concept - 2026-11-09 Research - Dead game method (shut-down multiplayer games as an idea library).md
- [[PLAN & SPLAT concept]] - concept - 2026-11-09 Research - Dead game method (shut-down multiplayer games as an idea library).md
- [[PRANK PATROL concept]] - concept - 2026-11-09 Research - Dead game method (shut-down multiplayer games as an idea library).md
- [[PlayersBanAsync Ban API]] - concept - Playbook notes - Admin panels and live tools.md
- [[Server-authoritative admin permissions]] - rationale - Playbook notes - Admin panels and live tools.md
- [[Spellbreak]] - concept - 2026-11-09 Research - Dead game method (shut-down multiplayer games as an idea library).md
- [[TextChatCommand]] - concept - Playbook notes - Admin panels and live tools.md
- [[Toontown Online]] - concept - 2026-11-09 Research - Dead game method (shut-down multiplayer games as an idea library).md
- [[Update day workflow]] - concept - Playbook notes - Admin panels and live tools.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Dead_game_method_and_live_tools
SORT file.name ASC
```

## Connections to other communities
- 3 edges to [[_COMMUNITY_Trending games and next game ideas]]

## Top bridge nodes
- [[Monthly free party event]] - degree 5, connects to 1 community
- [[MONSTER GROW concept]] - degree 4, connects to 1 community
- [[Admin abuse events_1]] - degree 4, connects to 1 community