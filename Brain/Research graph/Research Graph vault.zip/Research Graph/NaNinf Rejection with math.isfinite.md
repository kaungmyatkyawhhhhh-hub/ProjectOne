---
source_file: "Playbook notes - Performance, data and security.md"
type: "concept"
community: "Performance, data and security"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Performance_data_and_security
---

# NaN/inf Rejection with math.isfinite

## Connections
- [[Playbook notes - Performance, data and security]] - `references` [EXTRACTED]
- [[Server-Authoritative Remote Validation]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Performance_data_and_security