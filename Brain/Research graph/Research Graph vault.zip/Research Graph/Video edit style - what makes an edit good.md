---
source_file: "2026-11-07 Video edit style - what makes an edit good (reference study).md"
type: "document"
community: "Cutscenes and incremental HUDs"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Cutscenes_and_incremental_HUDs
---

# Video edit style - what makes an edit good

## Connections
- [[Beat-synced edit rules]] - `references` [EXTRACTED]
- [[EarShot critique]] - `references` [EXTRACTED]
- [[Galaxy TikTok v2 beat-sync edit]] - `references` [EXTRACTED]
- [[Remotion]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Cutscenes_and_incremental_HUDs