---
source_file: "Playbook notes - Updates and live ops.md"
type: "concept"
community: "Updates, events and release slot"
location: "L288"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# Admin abuse events

## Connections
- [[GYM ARC Saturday 1500 UTC release rule]] - `references` [EXTRACTED]
- [[Weekly admin abuse events (spikes fade within hours)]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Updates_events_and_release_slot