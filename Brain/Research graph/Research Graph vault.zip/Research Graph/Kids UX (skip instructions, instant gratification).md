---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "Kids onboarding UX"
location: "L31"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/Kids_onboarding_UX
---

# Kids UX (skip instructions, instant gratification)

## Connections
- [[Roblox onboarding guidance (timed hints, moment of joy)]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/INFERRED #community/Kids_onboarding_UX