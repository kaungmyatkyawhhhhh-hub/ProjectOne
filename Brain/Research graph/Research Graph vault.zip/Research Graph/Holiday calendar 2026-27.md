---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "Seasonal calendar"
location: "L65"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Seasonal_calendar
---

# Holiday calendar 2026-27

## Connections
- [[Saturday 1500 UTC update slot]] - `references` [EXTRACTED]
- [[Solo dev yearly seasonal calendar]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Seasonal_calendar