---
source_file: "Playbook notes - Onboarding, retention and live ops.md"
type: "concept"
community: "Weekly updates and trainer collection"
location: "L104"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Weekly_updates_and_trainer_collection
---

# Experience Notifications (Open Cloud)

## Connections
- [[Experience Events, Update Announcements and Notifications]] - `semantically_similar_to` [INFERRED]
- [[Safe Kids' Simulator Retention Stack]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Weekly_updates_and_trainer_collection