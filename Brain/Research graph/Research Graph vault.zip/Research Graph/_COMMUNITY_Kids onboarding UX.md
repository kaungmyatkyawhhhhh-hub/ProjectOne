---
type: community
cohesion: 1.00
members: 2
---

# Kids onboarding UX

**Cohesion:** 1.00 - tightly connected
**Members:** 2 nodes

## Members
- [[Kids UX (skip instructions, instant gratification)]] - concept - Playbook notes - Whole-game research (Oct 2026).md
- [[Roblox onboarding guidance (timed hints, moment of joy)]] - concept - Playbook notes - Whole-game research (Oct 2026).md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Kids_onboarding_UX
SORT file.name ASC
```
