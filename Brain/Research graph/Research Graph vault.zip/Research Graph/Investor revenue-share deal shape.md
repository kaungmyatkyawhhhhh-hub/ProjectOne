---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "Ads break-even and investor deals"
location: "L74"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Ads_break-even_and_investor_deals
---

# Investor revenue-share deal shape

## Connections
- [[DevEx rate and terms]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Ads_break-even_and_investor_deals