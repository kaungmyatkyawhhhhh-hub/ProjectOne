---
source_file: "2026-11-06 Research - 20 trending Roblox games (videos watched).md"
type: "concept"
community: "Trending games and next game ideas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Trending_games_and_next_game_ideas
---

# Sell a Million Sushi

## Connections
- [[20 trending Roblox games]] - `references` [EXTRACTED]
- [[The title is the game]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Trending_games_and_next_game_ideas