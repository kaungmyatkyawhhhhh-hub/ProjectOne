---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "Updates, events and release slot"
location: "L16"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/Updates_events_and_release_slot
---

# Experience Notifications rules

## Connections
- [[Eventsupdates tools (announcements, events, thumbnail personalization, Configs)]] - `conceptually_related_to` [INFERRED]
- [[Personalized Experience Notifications]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/INFERRED #community/Updates_events_and_release_slot