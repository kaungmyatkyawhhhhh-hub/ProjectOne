---
source_file: "2026-11-06 Research - 20 trending Roblox games (videos watched).md"
type: "document"
community: "Trending games and next game ideas"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Trending_games_and_next_game_ideas
---

# 20 trending Roblox games

## Connections
- [[+1 Anime Eyes]] - `references` [EXTRACTED]
- [[Bug Evolution]] - `references` [EXTRACTED]
- [[Clean the Moon!]] - `references` [EXTRACTED]
- [[DONT SPLASH]] - `references` [EXTRACTED]
- [[Depth Incremental (10 videos watched)]] - `cites` [EXTRACTED]
- [[PLAN - Trend research applied to Galaxy Incremental and +1 SHRINK]] - `cites` [EXTRACTED]
- [[Sell a Million Sushi]] - `references` [EXTRACTED]
- [[Sol's-RNG style rare reveal]] - `references` [EXTRACTED]
- [[Steal An Egg]] - `references` [EXTRACTED]
- [[The title is the game]] - `references` [EXTRACTED]
- [[Throw Food For Animals]] - `references` [EXTRACTED]
- [[Trending game patterns (Nov 2026)]] - `references` [EXTRACTED]
- [[obby but you get smaller every stage]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Trending_games_and_next_game_ideas