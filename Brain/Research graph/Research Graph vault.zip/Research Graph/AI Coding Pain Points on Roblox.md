---
source_file: "Playbook notes - Game quality and QA.md"
type: "concept"
community: "Quality and polish"
location: "L139"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Quality_and_polish
---

# AI Coding Pain Points on Roblox

## Connections
- [[Art Style Guide and Asset Kit]] - `references` [EXTRACTED]
- [[Game Quality and Polish for Roblox Kids' Simulators]] - `references` [EXTRACTED]
- [[Studio Testing APIs (StudioTestService, VirtualInput)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Quality_and_polish