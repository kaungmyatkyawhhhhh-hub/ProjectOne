---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "rationale"
community: "Names, logos and IP safety"
location: "L504"
tags:
  - graphify/rationale
  - graphify/INFERRED
  - community/Names_logos_and_IP_safety
---

# Never Ship AI Images Rule

## Connections
- [[AI-Generated Logos and US Copyright Office Report]] - `conceptually_related_to` [INFERRED]
- [[Blender GFX Thumbnail Workflow (Thumbnail F)]] - `rationale_for` [INFERRED]
- [[Coach Dex]] - `references` [EXTRACTED]
- [[ViewportFrame Portrait Recipe (Coach Dex)]] - `rationale_for` [INFERRED]

#graphify/rationale #graphify/INFERRED #community/Names_logos_and_IP_safety