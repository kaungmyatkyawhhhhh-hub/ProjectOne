---
source_file: "Playbook notes - Sound and music.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# AudioFader Mixer Buses

## Connections
- [[Audio API (AudioPlayer, Wire, AudioEmitter, AudioDeviceOutput)]] - `implements` [EXTRACTED]
- [[Loudness Targets (-16 to -18 LUFS mobile)]] - `conceptually_related_to` [INFERRED]
- [[Music Ducking Under Stingers]] - `references` [EXTRACTED]
- [[Playbook notes - Sound and music]] - `references` [EXTRACTED]
- [[SoundGroups Volume Mixing]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel