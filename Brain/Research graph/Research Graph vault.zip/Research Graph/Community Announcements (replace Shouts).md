---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "Community announcements"
location: "L21"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Community_announcements
---

# Community Announcements (replace Shouts)

#graphify/concept #graphify/EXTRACTED #community/Community_announcements