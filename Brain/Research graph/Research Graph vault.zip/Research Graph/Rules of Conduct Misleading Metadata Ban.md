---
source_file: "Playbook notes - Names and descriptions.md"
type: "concept"
community: "Optimization and retention mechanics"
location: "L85"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# Rules of Conduct: Misleading Metadata Ban

## Connections
- [[Discount Honesty Rules (no fake sales or resetting timers)]] - `semantically_similar_to` [INFERRED]
- [[Recommended For You 28-Day Window Change (Apr 2026)]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Optimization_and_retention_mechanics