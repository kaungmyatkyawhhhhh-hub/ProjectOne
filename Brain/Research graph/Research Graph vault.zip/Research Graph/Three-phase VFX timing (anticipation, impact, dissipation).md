---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L112"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# Three-phase VFX timing (anticipation, impact, dissipation)

## Connections
- [[Game juice (Jonasson & Purho; Nijman)]] - `semantically_similar_to` [INFERRED]
- [[Squash (particle stretch)]] - `references` [EXTRACTED]
- [[TimeScale (particle hit-stop  slow-mo)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles