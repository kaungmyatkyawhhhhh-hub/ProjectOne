---
source_file: "2026-11-01 Research - Popular incremental HUD layouts.md"
type: "concept"
community: "Cutscenes and incremental HUDs"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Cutscenes_and_incremental_HUDs
---

# Immortality Incremental

## Connections
- [[7 shared incremental HUD rules]] - `references` [EXTRACTED]
- [[Popular incremental HUD layouts]] - `references` [EXTRACTED]
- [[Sol's RNG]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Cutscenes_and_incremental_HUDs