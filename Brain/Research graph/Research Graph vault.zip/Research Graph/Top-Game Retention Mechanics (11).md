---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "rationale"
community: "Optimization and retention mechanics"
location: "L37"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# Top-Game Retention Mechanics (11)

## Connections
- [[Co-play Sessions 1.9x Longer]] - `conceptually_related_to` [INFERRED]
- [[GYM ARC Ranked Retention Plan]] - `implements` [EXTRACTED]
- [[Grow a Garden]] - `references` [EXTRACTED]
- [[Roblox Discovery Algorithm Signals]] - `rationale_for` [INFERRED]
- [[Sol's RNG_1]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Optimization_and_retention_mechanics