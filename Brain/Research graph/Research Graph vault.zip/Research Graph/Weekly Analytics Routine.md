---
source_file: "Playbook notes - Analytics and experiments.md"
type: "rationale"
community: "Analytics events"
location: "L135"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Analytics_events
---

# Weekly Analytics Routine

## Connections
- [[Analytics and Experimentation for Roblox Experiences]] - `references` [EXTRACTED]
- [[Creator Hub Analytics Dashboards]] - `references` [EXTRACTED]
- [[Onboarding Funnel Events]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Analytics_events