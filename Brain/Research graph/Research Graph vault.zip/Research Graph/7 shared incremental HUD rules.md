---
source_file: "2026-11-01 Research - Popular incremental HUD layouts.md"
type: "rationale"
community: "Cutscenes and incremental HUDs"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Cutscenes_and_incremental_HUDs
---

# 7 shared incremental HUD rules

## Connections
- [[Galaxy Incremental (was Supernova Incremental)]] - `conceptually_related_to` [EXTRACTED]
- [[Immortality Incremental]] - `references` [EXTRACTED]
- [[Noob Incremental]] - `references` [EXTRACTED]
- [[Popular incremental HUD layouts]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Cutscenes_and_incremental_HUDs