---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "concept"
community: "Optimization and retention mechanics"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# Sol's RNG

## Connections
- [[GYM ARC Aura Tier Recipe]] - `references` [EXTRACTED]
- [[Rarity Roll Reveal  Altar Reveal]] - `references` [EXTRACTED]
- [[Top-Game Retention Mechanics (11)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Optimization_and_retention_mechanics