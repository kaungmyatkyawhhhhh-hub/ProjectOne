---
source_file: "Playbook notes - Names and descriptions.md"
type: "concept"
community: "Names, logos and IP safety"
location: "L33"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# Title Decorations (bracketed emoji prefix)

## Connections
- [[Grow a Garden_3]] - `references` [EXTRACTED]
- [[Title Truncation (~15 characters)]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Names_logos_and_IP_safety