---
source_file: "Playbook notes - Core loop design.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L81"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Steal a Brainrot

## Connections
- [[Core Loop Design for Roblox Simulators and Casual Games]] - `references` [EXTRACTED]
- [[Steal a Brainrot (trend case)]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths