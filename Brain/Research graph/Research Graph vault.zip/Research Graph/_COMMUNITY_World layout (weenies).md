---
type: community
cohesion: 1.00
members: 1
---

# World layout (weenies)

**Cohesion:** 1.00 - tightly connected
**Members:** 1 nodes

## Members
- [[Weenies and world layout (Rogers, GDC 2009)]] - concept - Playbook notes - Whole-game research (Oct 2026).md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/World_layout_weenies
SORT file.name ASC
```
