---
source_file: "Playbook notes - Updates and live ops.md"
type: "concept"
community: "Updates, events and release slot"
location: "L158"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# Server Management Restart Servers (soft shutdown)

## Connections
- [[DataModel.ServerRestartScheduled event]] - `references` [EXTRACTED]
- [[Launch checklist for a solo kids' simulator (D-7 to launch)]] - `references` [EXTRACTED]
- [[Rollback via previous place version + backward-compatible DataStore schema]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Updates_events_and_release_slot