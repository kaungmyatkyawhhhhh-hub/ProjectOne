---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L89"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# Emitter pooling on Attachments

## Connections
- [[Emit(n) burst on disabled emitter]] - `references` [EXTRACTED]
- [[Highlight (255 limit, first costs ~1 ms GPU on mobile)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles