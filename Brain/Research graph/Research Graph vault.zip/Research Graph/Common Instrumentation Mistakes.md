---
source_file: "Playbook notes - Analytics in practice.md"
type: "rationale"
community: "Analytics benchmarks and diagnosis"
location: "L87"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Analytics_benchmarks_and_diagnosis
---

# Common Instrumentation Mistakes

## Connections
- [[Practical Roblox Analytics Instrumentation and Diagnosis]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Analytics_benchmarks_and_diagnosis