---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L117"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# Coin burst recipe

## Connections
- [[Emit(n) burst on disabled emitter]] - `implements` [EXTRACTED]
- [[Particle flipbooks (Grid layouts, max 30 fps, auto-off on low memory)]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles