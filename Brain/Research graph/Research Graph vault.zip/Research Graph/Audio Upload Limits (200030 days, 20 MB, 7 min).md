---
source_file: "Playbook notes - Sound and music.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Audio Upload Limits (2000/30 days, 20 MB, 7 min)

## Connections
- [[Creator Store Partner Audio (APM, Monstercat)]] - `conceptually_related_to` [EXTRACTED]
- [[March 2022 Audio Privacy Change]] - `conceptually_related_to` [INFERRED]
- [[Playbook notes - Sound and music]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel