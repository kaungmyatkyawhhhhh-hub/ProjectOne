---
source_file: "Playbook notes - UI, game feel, art and sound.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Polished UI Kit

## Connections
- [[9-Slice UI Design]] - `references` [EXTRACTED]
- [[Chunky Kids' Simulator Button Recipe]] - `semantically_similar_to` [INFERRED]
- [[Colour and Hierarchy Rules]] - `conceptually_related_to` [EXTRACTED]
- [[Placeholder-Look Mistakes]] - `conceptually_related_to` [INFERRED]
- [[Playbook notes - UI, game feel, art and sound]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel