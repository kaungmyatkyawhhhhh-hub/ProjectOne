---
source_file: "Playbook notes - Discovery and marketing.md"
type: "document"
community: "Discovery and ads"
location: "L1"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Discovery_and_ads
---

# Roblox Discovery and Marketing

## Connections
- [[Ads Manager  Sponsored Ads]] - `references` [EXTRACTED]
- [[Charts (Top Playing Now etc.)]] - `references` [EXTRACTED]
- [[Creator Rewards and Share Links]] - `references` [EXTRACTED]
- [[Experience Betas]] - `references` [EXTRACTED]
- [[Experience Notifications_1]] - `references` [EXTRACTED]
- [[Friend Invite Reward System]] - `references` [EXTRACTED]
- [[Recommended For You Algorithm]] - `references` [EXTRACTED]
- [[Rewarded Video Ads]] - `references` [EXTRACTED]
- [[Roblox Search]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Discovery_and_ads