---
source_file: "Playbook notes - UI deep dive.md"
type: "code"
community: "UI, sound and game feel"
tags:
  - graphify/code
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# FontFace / Font Datatype

## Connections
- [[Chunky Kids' Simulator Button Recipe]] - `references` [EXTRACTED]
- [[Playbook notes - UI deep dive]] - `references` [EXTRACTED]

#graphify/code #graphify/EXTRACTED #community/UI_sound_and_game_feel