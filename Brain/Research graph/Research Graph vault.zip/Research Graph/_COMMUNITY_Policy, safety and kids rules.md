---
type: community
cohesion: 0.23
members: 15
---

# Policy, safety and kids rules

**Cohesion:** 0.23 - loosely connected
**Members:** 15 nodes

## Members
- [[Ads Manager Engagement Objective]] - concept - Playbook notes - Policy, safety and community.md
- [[Chat Age Checks and Age Bands]] - concept - Playbook notes - Policy, safety and community.md
- [[Content Maturity Labels (MinimalMildModerateRestricted)]] - concept - Playbook notes - Policy, safety and community.md
- [[Experience Notifications]] - concept - Playbook notes - Policy, safety and community.md
- [[Free-Form User Creation Restriction (16+)]] - concept - Playbook notes - Policy, safety and community.md
- [[Independent In-Game Advertising Rules]] - concept - Playbook notes - Policy, safety and community.md
- [[Maturity & Compliance Questionnaire]] - concept - Playbook notes - Policy, safety and community.md
- [[Off-Platform Links Ban in Experiences]] - concept - Playbook notes - Policy, safety and community.md
- [[Playbook notes - Policy, safety and community]] - document - Playbook notes - Policy, safety and community.md
- [[PolicyService RegionalAge Gating]] - concept - Playbook notes - Policy, safety and community.md
- [[Roblox Kids and Select Eligibility]] - concept - Playbook notes - Policy, safety and community.md
- [[Simulated Gambling Ban and Odds Disclosure]] - concept - Playbook notes - Policy, safety and community.md
- [[Social Hangout Age Restriction]] - concept - Playbook notes - Policy, safety and community.md
- [[Social Links Slots (16+ only)]] - concept - Playbook notes - Policy, safety and community.md
- [[TextService FilterStringAsync Filtering]] - concept - Playbook notes - Policy, safety and community.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Policy_safety_and_kids_rules
SORT file.name ASC
```

## Connections to other communities
- 1 edge to [[_COMMUNITY_UI, sound and game feel]]
- 1 edge to [[_COMMUNITY_Thumbnail art study and testing]]
- 1 edge to [[_COMMUNITY_Passes and products]]

## Top bridge nodes
- [[Playbook notes - Policy, safety and community]] - degree 15, connects to 1 community
- [[Simulated Gambling Ban and Odds Disclosure]] - degree 3, connects to 1 community
- [[TextService FilterStringAsync Filtering]] - degree 3, connects to 1 community