---
source_file: "2026-11-01 Research - Popular incremental HUD layouts.md"
type: "rationale"
community: "Cutscenes and incremental HUDs"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Cutscenes_and_incremental_HUDs
---

# Avoiding the AI-made look

## Connections
- [[Astronomer star-chart UI motif]] - `implements` [EXTRACTED]
- [[Popular incremental HUD layouts]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Cutscenes_and_incremental_HUDs