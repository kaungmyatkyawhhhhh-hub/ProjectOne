---
source_file: "Playbook notes - Genres and trends.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L11"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/Core_loop_incrementals_and_trends_maths
---

# Geometric Rebirth Cost Formula

## Connections
- [[Exponential Cost vs Polynomial Production Seesaw]] - `semantically_similar_to` [INFERRED]
- [[Prestige Formulas (Realm Grinder, AdCap, Cookie Clicker, Egg Inc.)]] - `semantically_similar_to` [INFERRED]
- [[Proven Simulator Template]] - `references` [EXTRACTED]

#graphify/concept #graphify/INFERRED #community/Core_loop_incrementals_and_trends_maths