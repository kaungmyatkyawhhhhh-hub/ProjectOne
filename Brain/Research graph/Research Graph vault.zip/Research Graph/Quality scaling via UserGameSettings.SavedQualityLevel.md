---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L88"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/VFX_and_particles
---

# Quality scaling via UserGameSettings.SavedQualityLevel

## Connections
- [[Cheap-phone particle budget (~300 alive on screen)]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/INFERRED #community/VFX_and_particles