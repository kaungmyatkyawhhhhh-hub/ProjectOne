---
source_file: "Playbook notes - Onboarding, retention and live ops.md"
type: "concept"
community: "Names, logos and IP safety"
location: "L20"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# Creator Rewards 10-Minute Threshold

## Connections
- [[Creator Rewards (Daily Engagement Reward)]] - `semantically_similar_to` [INFERRED]
- [[Friend Referral System]] - `conceptually_related_to` [EXTRACTED]
- [[Suggested Simulator Funnel Steps]] - `rationale_for` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Names_logos_and_IP_safety