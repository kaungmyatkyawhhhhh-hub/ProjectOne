---
source_file: "2026-11-06 PLAN - Trend research applied to Galaxy Incremental and +1 SHRINK.md"
type: "concept"
community: "Trending games and next game ideas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Trending_games_and_next_game_ideas
---

# Galaxy distance "how far" bar

## Connections
- [[Galaxy Incremental (was Supernova Incremental)]] - `implements` [EXTRACTED]
- [[PLAN - Trend research applied to Galaxy Incremental and +1 SHRINK]] - `references` [EXTRACTED]
- [[Why Depth Incremental is addicting]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Trending_games_and_next_game_ideas