---
source_file: "Playbook notes - Costly mistakes of big games.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L19"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# SPTS and Muscle Transform Update Stops

## Connections
- [[The 12 Rules from Big-Game Mistakes]] - `rationale_for` [EXTRACTED]
- [[Trend Lifecycle]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths