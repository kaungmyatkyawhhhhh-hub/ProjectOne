---
source_file: "Playbook notes - Genres and trends.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L50"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Grow a Garden (trend case)

## Connections
- [[Grow a Garden_2]] - `semantically_similar_to` [INFERRED]
- [[Grow a Garden Complexity Decline]] - `conceptually_related_to` [INFERRED]
- [[Roblox Genre Design and Trends]] - `references` [EXTRACTED]
- [[Splitting Point Studios]] - `conceptually_related_to` [EXTRACTED]
- [[Trend Lifecycle]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths