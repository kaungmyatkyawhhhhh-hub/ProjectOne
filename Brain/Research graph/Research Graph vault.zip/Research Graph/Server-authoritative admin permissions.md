---
source_file: "Playbook notes - Admin panels and live tools.md"
type: "rationale"
community: "Dead game method and live tools"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Dead_game_method_and_live_tools
---

# Server-authoritative admin permissions

## Connections
- [[Admin panels and live tools]] - `references` [EXTRACTED]
- [[PlayersBanAsync Ban API]] - `conceptually_related_to` [EXTRACTED]
- [[TextChatCommand]] - `conceptually_related_to` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Dead_game_method_and_live_tools