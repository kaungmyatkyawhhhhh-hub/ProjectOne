---
source_file: "Playbook notes - Icons and titles.md"
type: "concept"
community: "Titles, search and copycat rules"
location: "L11"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Titles_search_and_copycat_rules
---

# Experience Icon Spec (512x512, reads at 150px)

## Connections
- [[No Icon AB Testing]] - `conceptually_related_to` [EXTRACTED]
- [[Roblox Experience Icons, Titles and Descriptions]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Titles_search_and_copycat_rules