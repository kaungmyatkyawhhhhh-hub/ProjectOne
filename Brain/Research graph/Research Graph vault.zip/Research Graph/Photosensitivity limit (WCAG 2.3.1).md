---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "VFX and particles"
location: "L64"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/VFX_and_particles
---

# Photosensitivity limit (WCAG 2.3.1)

## Connections
- [[Flash limit ~3 per second (photosensitivity)]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/INFERRED #community/VFX_and_particles