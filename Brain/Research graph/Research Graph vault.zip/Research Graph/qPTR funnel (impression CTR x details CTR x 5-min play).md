---
source_file: "2026-11-03 Research - High CTR Roblox thumbnails.md"
type: "concept"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# qPTR funnel (impression CTR x details CTR x 5-min play)

## Connections
- [[High CTR Roblox thumbnails]] - `references` [EXTRACTED]
- [[Qualified Play Through Rate (qPTR)]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks