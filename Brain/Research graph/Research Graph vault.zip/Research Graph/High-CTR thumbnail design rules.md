---
source_file: "2026-11-03 Research - High CTR Roblox thumbnails.md"
type: "rationale"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/rationale
  - graphify/INFERRED
  - community/Icons_thumbnails_and_owner_clicks
---

# High-CTR thumbnail design rules

## Connections
- [[Gymsimulator thumbnail rules (one hero, bright bg, progress numbers)]] - `semantically_similar_to` [INFERRED]
- [[High CTR Roblox thumbnails]] - `references` [EXTRACTED]
- [[Owner click patterns (one hero, emotion, one glow, one number)]] - `semantically_similar_to` [INFERRED]

#graphify/rationale #graphify/INFERRED #community/Icons_thumbnails_and_owner_clicks