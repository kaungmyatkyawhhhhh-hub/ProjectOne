---
source_file: "Playbook notes - Lighting, cameras and cutscenes.md"
type: "concept"
community: "Lighting and cameras"
location: "L78"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Lighting_and_cameras
---

# Cutscene Building Methods

## Connections
- [[CineCam v3 Plugin]] - `implements` [EXTRACTED]
- [[LetterBoxer Module]] - `implements` [EXTRACTED]
- [[Lighting, Cameras and Cutscenes for Roblox Simulators]] - `references` [EXTRACTED]
- [[Scriptable Camera]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Lighting_and_cameras