---
source_file: "2026-10-30 Icon and thumbnail testing.md"
type: "document"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# Icon and thumbnail testing

## Connections
- [[GYM ARC]] - `references` [EXTRACTED]
- [[GYM ARC barbell-overhead Hall of Fame icon]] - `references` [EXTRACTED]
- [[High CTR Roblox thumbnails]] - `cites` [EXTRACTED]
- [[Icons cannot be AB tested on Roblox]] - `references` [EXTRACTED]
- [[Qualified Play Through Rate (qPTR)]] - `references` [EXTRACTED]
- [[Thumbnail Personalization]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks