---
source_file: "Playbook notes - Logos.md"
type: "concept"
community: "Money: DevEx and pricing"
location: "L70"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Money_DevEx_and_pricing
---

# DevEx Rate $0.0038 per Robux

## Connections
- [[Developer Exchange (DevEx)]] - `semantically_similar_to` [INFERRED]
- [[Logo Commission Pricing (Robux)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Money_DevEx_and_pricing