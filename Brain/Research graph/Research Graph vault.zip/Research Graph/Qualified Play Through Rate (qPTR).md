---
source_file: "2026-10-30 Icon and thumbnail testing.md"
type: "concept"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# Qualified Play Through Rate (qPTR)

## Connections
- [[Icon and thumbnail testing]] - `references` [EXTRACTED]
- [[Icons cannot be AB tested on Roblox]] - `conceptually_related_to` [EXTRACTED]
- [[Thumbnail Personalization]] - `conceptually_related_to` [EXTRACTED]
- [[qPTR funnel (impression CTR x details CTR x 5-min play)]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks