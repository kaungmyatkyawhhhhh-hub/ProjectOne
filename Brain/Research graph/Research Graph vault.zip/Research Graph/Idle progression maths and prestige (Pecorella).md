---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "Idle maths and offline progress"
location: "L46"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/Idle_maths_and_offline_progress
---

# Idle progression maths and prestige (Pecorella)

## Connections
- [[Economy sinks and sources (LogEconomyEvent)]] - `conceptually_related_to` [INFERRED]
- [[Offline progress (Pecorella, GDC 2015)]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/INFERRED #community/Idle_maths_and_offline_progress