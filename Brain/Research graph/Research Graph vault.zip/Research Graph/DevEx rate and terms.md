---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "Ads break-even and investor deals"
location: "L73"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Ads_break-even_and_investor_deals
---

# DevEx rate and terms

## Connections
- [[Investor revenue-share deal shape]] - `references` [EXTRACTED]
- [[Paid-player break-even (2.6-7.1 R$ lifetime)]] - `shares_data_with` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Ads_break-even_and_investor_deals