---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L22"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# Emit(n) burst on disabled emitter

## Connections
- [[Coin burst recipe]] - `implements` [EXTRACTED]
- [[Emitter pooling on Attachments]] - `references` [EXTRACTED]
- [[ParticleEmitter]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles