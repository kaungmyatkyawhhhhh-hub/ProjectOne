---
source_file: "Playbook notes - Analytics and experiments.md"
type: "concept"
community: "Analytics benchmarks and diagnosis"
location: "L71"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Analytics_benchmarks_and_diagnosis
---

# Experiments on Configs (A/B testing)

## Connections
- [[Analytics and Experimentation for Roblox Experiences]] - `references` [EXTRACTED]
- [[DAU-gated Analytics Thresholds]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Analytics_benchmarks_and_diagnosis