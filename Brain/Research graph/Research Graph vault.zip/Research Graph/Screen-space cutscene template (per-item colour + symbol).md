---
source_file: "2026-11-05 Research - Sols RNG 100M+ aura cutscenes (40 watched) + Immortality and Regrowth videos.md"
type: "concept"
community: "Cutscenes and incremental HUDs"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Cutscenes_and_incremental_HUDs
---

# Screen-space cutscene template (per-item colour + symbol)

## Connections
- [[Five-beat aura cutscene structure]] - `implements` [EXTRACTED]
- [[GYM ARC]] - `conceptually_related_to` [EXTRACTED]
- [[Galaxy Incremental (was Supernova Incremental)]] - `conceptually_related_to` [EXTRACTED]
- [[Good cutscene checklist (earned, short, skippable, opens a question)]] - `conceptually_related_to` [EXTRACTED]
- [[Sol's RNG aura cutscenes + Immortality and Regrowth]] - `references` [EXTRACTED]
- [[Stinger drop sync rule]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Cutscenes_and_incremental_HUDs