---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "concept"
community: "Optimization and retention mechanics"
location: "L159"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# ParticleEmitter Performance Rules

## Connections
- [[GYM ARC Aura Tier Recipe]] - `references` [EXTRACTED]
- [[Particle and Effect Cost]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Optimization_and_retention_mechanics