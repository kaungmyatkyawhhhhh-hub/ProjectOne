---
source_file: "Playbook notes - Passes and products catalogue.md"
type: "concept"
community: "Passes and products"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/Passes_and_products
---

# Gift-a-Pass Developer Product Pattern

## Connections
- [[Converting Shop Layout]] - `conceptually_related_to` [INFERRED]
- [[Grant Developer Products Only in ProcessReceipt]] - `conceptually_related_to` [INFERRED]
- [[Playbook notes - Passes and products catalogue]] - `references` [EXTRACTED]

#graphify/concept #graphify/INFERRED #community/Passes_and_products