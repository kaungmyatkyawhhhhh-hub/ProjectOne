---
source_file: "Playbook notes - Thumbnails.md"
type: "concept"
community: "Thumbnail art study and testing"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Thumbnail_art_study_and_testing
---

# Standout Games Home Shelf

## Connections
- [[Gameplay Video Previews]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Thumbnails]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Thumbnail_art_study_and_testing