---
type: community
cohesion: 0.28
members: 9
---

# Analytics benchmarks and diagnosis

**Cohesion:** 0.28 - loosely connected
**Members:** 9 nodes

## Members
- [[Common Instrumentation Mistakes]] - rationale - Playbook notes - Analytics in practice.md
- [[DAU-gated Analytics Thresholds]] - concept - Playbook notes - Analytics in practice.md
- [[Diagnosis Playbooks]] - rationale - Playbook notes - Analytics in practice.md
- [[Error Report]] - concept - Playbook notes - Analytics in practice.md
- [[Experiments on Configs (AB testing)]] - concept - Playbook notes - Analytics and experiments.md
- [[GameAnalytics 2026 Roblox Benchmarks]] - concept - Playbook notes - Analytics in practice.md
- [[Practical Roblox Analytics Instrumentation and Diagnosis]] - document - Playbook notes - Analytics in practice.md
- [[Retention Levers (D1 FTUE, D7 progression, D30 updatessocial)]] - concept - Playbook notes - Analytics in practice.md
- [[Similar-game Benchmarks]] - concept - Playbook notes - Analytics and experiments.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Analytics_benchmarks_and_diagnosis
SORT file.name ASC
```

## Connections to other communities
- 5 edges to [[_COMMUNITY_Analytics events]]
- 1 edge to [[_COMMUNITY_Discovery and ads]]
- 1 edge to [[_COMMUNITY_Core loop, incrementals and trends maths]]
- 1 edge to [[_COMMUNITY_Solo QA]]

## Top bridge nodes
- [[Practical Roblox Analytics Instrumentation and Diagnosis]] - degree 10, connects to 2 communities
- [[Error Report]] - degree 3, connects to 1 community
- [[GameAnalytics 2026 Roblox Benchmarks]] - degree 3, connects to 1 community
- [[Experiments on Configs (AB testing)]] - degree 2, connects to 1 community
- [[Similar-game Benchmarks]] - degree 2, connects to 1 community