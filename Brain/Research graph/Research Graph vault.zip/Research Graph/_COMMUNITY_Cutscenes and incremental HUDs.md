---
type: community
cohesion: 0.14
members: 23
---

# Cutscenes and incremental HUDs

**Cohesion:** 0.14 - loosely connected
**Members:** 23 nodes

## Members
- [[7 shared incremental HUD rules]] - rationale - 2026-11-01 Research - Popular incremental HUD layouts.md
- [[Astronomer star-chart UI motif]] - concept - 2026-11-01 Research - Popular incremental HUD layouts.md
- [[Avoiding the AI-made look]] - rationale - 2026-11-01 Research - Popular incremental HUD layouts.md
- [[Beat-synced edit rules]] - rationale - 2026-11-07 Video edit style - what makes an edit good (reference study).md
- [[Curiosity drives playtime (CHI 2024 study)]] - concept - 2026-11-01 Research - Do cutscenes help, what makes a good one.md
- [[Do cutscenes help, what makes a good one]] - document - 2026-11-01 Research - Do cutscenes help, what makes a good one.md
- [[Drop-off happens in the first 90 seconds]] - concept - 2026-11-01 Research - Do cutscenes help, what makes a good one.md
- [[EarShot critique]] - concept - 2026-11-07 Video edit style - what makes an edit good (reference study).md
- [[Five-beat aura cutscene structure]] - rationale - 2026-11-05 Research - Sols RNG 100M+ aura cutscenes (40 watched) + Immortality and Regrowth videos.md
- [[Galaxy TikTok v2 beat-sync edit]] - concept - 2026-11-07 Video edit style - what makes an edit good (reference study).md
- [[Gargantua aura]] - concept - 2026-11-05 Research - Sols RNG 100M+ aura cutscenes (40 watched) + Immortality and Regrowth videos.md
- [[Good cutscene checklist (earned, short, skippable, opens a question)]] - rationale - 2026-11-01 Research - Do cutscenes help, what makes a good one.md
- [[Immortality Incremental]] - concept - 2026-11-01 Research - Popular incremental HUD layouts.md
- [[Noob Incremental]] - concept - 2026-11-01 Research - Popular incremental HUD layouts.md
- [[Popular incremental HUD layouts]] - document - 2026-11-01 Research - Popular incremental HUD layouts.md
- [[Regrowth Incremental]] - concept - 2026-11-05 Research - Sols RNG 100M+ aura cutscenes (40 watched) + Immortality and Regrowth videos.md
- [[Remotion]] - concept - 2026-11-07 Video edit style - what makes an edit good (reference study).md
- [[Screen-space cutscene template (per-item colour + symbol)]] - concept - 2026-11-05 Research - Sols RNG 100M+ aura cutscenes (40 watched) + Immortality and Regrowth videos.md
- [[Sol's RNG]] - concept - 2026-11-05 Research - Sols RNG 100M+ aura cutscenes (40 watched) + Immortality and Regrowth videos.md
- [[Sol's RNG aura cutscenes + Immortality and Regrowth]] - document - 2026-11-05 Research - Sols RNG 100M+ aura cutscenes (40 watched) + Immortality and Regrowth videos.md
- [[Stinger drop sync rule]] - concept - 2026-11-05 Research - Sols RNG 100M+ aura cutscenes (40 watched) + Immortality and Regrowth videos.md
- [[Supernova cutscene (5 s first, 2 s repeats)]] - concept - 2026-11-01 Research - Do cutscenes help, what makes a good one.md
- [[Video edit style - what makes an edit good]] - document - 2026-11-07 Video edit style - what makes an edit good (reference study).md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Cutscenes_and_incremental_HUDs
SORT file.name ASC
```

## Connections to other communities
- 6 edges to [[_COMMUNITY_Trending games and next game ideas]]
- 1 edge to [[_COMMUNITY_Icons, thumbnails and owner clicks]]

## Top bridge nodes
- [[Screen-space cutscene template (per-item colour + symbol)]] - degree 6, connects to 2 communities
- [[Galaxy TikTok v2 beat-sync edit]] - degree 5, connects to 1 community
- [[Supernova cutscene (5 s first, 2 s repeats)]] - degree 4, connects to 1 community
- [[7 shared incremental HUD rules]] - degree 4, connects to 1 community
- [[Sol's RNG]] - degree 4, connects to 1 community