---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "concept"
community: "Weekly updates and trainer collection"
location: "L234"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Weekly_updates_and_trainer_collection
---

# Endowed Progress Effect

## Connections
- [[Collection Book (Trainer Index)]] - `rationale_for` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Weekly_updates_and_trainer_collection