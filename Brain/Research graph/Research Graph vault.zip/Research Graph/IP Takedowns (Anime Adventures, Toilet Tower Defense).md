---
source_file: "Playbook notes - Costly mistakes of big games.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L24"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# IP Takedowns (Anime Adventures, Toilet Tower Defense)

## Connections
- [[The 12 Rules from Big-Game Mistakes]] - `rationale_for` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths