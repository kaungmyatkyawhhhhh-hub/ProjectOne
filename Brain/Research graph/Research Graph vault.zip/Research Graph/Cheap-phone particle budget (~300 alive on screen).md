---
source_file: "Playbook notes - Visual effects.md"
type: "rationale"
community: "VFX and particles"
location: "L87"
tags:
  - graphify/rationale
  - graphify/INFERRED
  - community/VFX_and_particles
---

# Cheap-phone particle budget (~300 alive on screen)

## Connections
- [[Overdraw  fill-rate cost of transparent particles]] - `rationale_for` [EXTRACTED]
- [[Particle rate limit (400s per emitter, 100 on mobile)]] - `rationale_for` [INFERRED]
- [[Quality scaling via UserGameSettings.SavedQualityLevel]] - `conceptually_related_to` [INFERRED]

#graphify/rationale #graphify/INFERRED #community/VFX_and_particles