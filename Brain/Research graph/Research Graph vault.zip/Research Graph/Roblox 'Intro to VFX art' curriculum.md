---
source_file: "Playbook notes - Visual effects.md"
type: "paper"
community: "VFX and particles"
location: "L108"
tags:
  - graphify/paper
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# Roblox 'Intro to VFX art' curriculum

## Connections
- [[Playbook notes Roblox VFX for kids' simulators on cheap phones]] - `cites` [EXTRACTED]

#graphify/paper #graphify/EXTRACTED #community/VFX_and_particles