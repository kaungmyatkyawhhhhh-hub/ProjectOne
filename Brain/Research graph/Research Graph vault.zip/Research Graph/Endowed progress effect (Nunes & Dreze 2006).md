---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "paper"
community: "Progress psychology"
location: "L26"
tags:
  - graphify/paper
  - graphify/EXTRACTED
  - community/Progress_psychology
---

# Endowed progress effect (Nunes & Dreze 2006)

## Connections
- [[Goal gradient effect (Kivetz)]] - `conceptually_related_to` [EXTRACTED]

#graphify/paper #graphify/EXTRACTED #community/Progress_psychology