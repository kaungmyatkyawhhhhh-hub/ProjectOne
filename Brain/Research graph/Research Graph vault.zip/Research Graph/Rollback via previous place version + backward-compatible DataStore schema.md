---
source_file: "Playbook notes - Updates and live ops.md"
type: "concept"
community: "Updates, events and release slot"
location: "L219"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# Rollback via previous place version + backward-compatible DataStore schema

## Connections
- [[DataStore versioning, ProfileStore, Right to Erasure]] - `conceptually_related_to` [INFERRED]
- [[Deploy early, hide content behind config flag]] - `conceptually_related_to` [EXTRACTED]
- [[Server Management Restart Servers (soft shutdown)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Updates_events_and_release_slot