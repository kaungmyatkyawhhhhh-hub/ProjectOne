---
source_file: "2026-10-31 Roblox Plus.md"
type: "document"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# Roblox Plus for developers

## Connections
- [[GYM ARC Plus perks (+20% EXP, +10% coins, +15% stamina)]] - `references` [EXTRACTED]
- [[Player.HasRobloxSubscription]] - `references` [EXTRACTED]
- [[Roblox Plus subscriber payouts (250 Robuxmonth x3)]] - `references` [EXTRACTED]
- [[Roblox Plus subscription]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks