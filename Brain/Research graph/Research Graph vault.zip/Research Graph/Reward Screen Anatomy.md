---
source_file: "Playbook notes - UI deep dive.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Reward Screen Anatomy

## Connections
- [[Playbook notes - UI deep dive]] - `references` [EXTRACTED]
- [[Rarity Colour Ladder]] - `references` [EXTRACTED]
- [[UIGradient (radialconical beta)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel