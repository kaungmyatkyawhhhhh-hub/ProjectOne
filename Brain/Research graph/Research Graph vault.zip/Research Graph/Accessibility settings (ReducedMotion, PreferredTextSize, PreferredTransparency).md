---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "VFX and particles"
location: "L56"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/VFX_and_particles
---

# Accessibility settings (ReducedMotion, PreferredTextSize, PreferredTransparency)

## Connections
- [[GuiService.ReducedMotionEnabled]] - `references` [INFERRED]
- [[Rarity colour ladder (grey to gold + Mythic)]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/INFERRED #community/VFX_and_particles