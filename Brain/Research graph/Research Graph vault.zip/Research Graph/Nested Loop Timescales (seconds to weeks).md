---
source_file: "Playbook notes - Core loop design.md"
type: "rationale"
community: "Core loop, incrementals and trends maths"
location: "L34"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Nested Loop Timescales (seconds to weeks)

## Connections
- [[Core Loop (Katkoff dual session loops)]] - `rationale_for` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths