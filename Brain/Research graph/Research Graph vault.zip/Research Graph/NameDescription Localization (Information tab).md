---
source_file: "Playbook notes - Names and descriptions.md"
type: "concept"
community: "Names, logos and IP safety"
location: "L61"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# Name/Description Localization (Information tab)

## Connections
- [[Kid-Friendly Description Structure]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Names_logos_and_IP_safety