---
source_file: "Playbook notes - Logos.md"
type: "rationale"
community: "Logos, loading screen and GYM ARC art"
location: "L26"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Logos_loading_screen_and_GYM_ARC_art
---

# Roblox Game Logo Layer Recipe

## Connections
- [[3D Extrusion Body and Bevel Technique]] - `references` [EXTRACTED]
- [[DevForum Basics of Game Logo Design Tutorial]] - `cites` [EXTRACTED]
- [[Experience Icon Spec (512, shown ~150px)]] - `references` [EXTRACTED]
- [[Hue-Shift Shading]] - `references` [EXTRACTED]
- [[Logo on Main Menu and Loading Screen]] - `conceptually_related_to` [INFERRED]
- [[Roblox Community (Group) Emblem and Banner]] - `conceptually_related_to` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Logos_loading_screen_and_GYM_ARC_art