---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "rationale"
community: "Weekly updates and trainer collection"
location: "L215"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Weekly_updates_and_trainer_collection
---

# Trainer Inventory UX Spec

## Connections
- [[Collection Book (Trainer Index)]] - `references` [EXTRACTED]
- [[Paid Random Items Policy]] - `references` [EXTRACTED]
- [[Premium vs AI-Slop Visual Rules]] - `rationale_for` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Weekly_updates_and_trainer_collection