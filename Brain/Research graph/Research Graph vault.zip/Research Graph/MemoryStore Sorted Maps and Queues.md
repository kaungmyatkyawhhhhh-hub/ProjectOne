---
source_file: "Playbook notes - Performance, data and security.md"
type: "concept"
community: "Performance, data and security"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Performance_data_and_security
---

# MemoryStore Sorted Maps and Queues

## Connections
- [[OrderedDataStore Leaderboards]] - `semantically_similar_to` [INFERRED]
- [[Playbook notes - Performance, data and security]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Performance_data_and_security