---
source_file: "Playbook notes - Admin panels and live tools.md"
type: "document"
community: "Dead game method and live tools"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Dead_game_method_and_live_tools
---

# Admin panels and live tools

## Connections
- [[Admin abuse events_1]] - `references` [EXTRACTED]
- [[Adonis]] - `references` [EXTRACTED]
- [[Config kill switch pattern]] - `references` [EXTRACTED]
- [[EventController server module]] - `references` [EXTRACTED]
- [[Experience Configs (ConfigService)]] - `references` [EXTRACTED]
- [[HD Admin]] - `references` [EXTRACTED]
- [[MessagingService]] - `references` [EXTRACTED]
- [[PlayersBanAsync Ban API]] - `references` [EXTRACTED]
- [[Server-authoritative admin permissions]] - `references` [EXTRACTED]
- [[TextChatCommand]] - `references` [EXTRACTED]
- [[Update day workflow]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Dead_game_method_and_live_tools