---
type: community
cohesion: 0.09
members: 40
---

# Trending games and next game ideas

**Cohesion:** 0.09 - loosely connected
**Members:** 40 nodes

## Members
- [[+1  evolution wave]] - concept - 2026-11-06 Research - Next game ideas from live Roblox charts.md
- [[+1 Anime Eyes]] - concept - 2026-11-06 Research - 20 trending Roblox games (videos watched).md
- [[+1 Depth Incremental]] - concept - 2026-11-06 Research - Depth Incremental (10 videos watched).md
- [[+1 SHRINK]] - concept - 2026-11-06 PLAN - Trend research applied to Galaxy Incremental and +1 SHRINK.md
- [[+1 Venom Evolution]] - concept - 2026-11-03 Research - Gym, simulator and evolution thumbnails (owner screenshots).md
- [[20 trending Roblox games]] - document - 2026-11-06 Research - 20 trending Roblox games (videos watched).md
- [[Blender Python model pipeline (vertex colours, .fbx)]] - concept - 2026-11-01 Research - Modeling like a professional (stylized low poly).md
- [[Boss - key - rebirth room]] - concept - 2026-11-06 Research - Depth Incremental (10 videos watched).md
- [[Bug Evolution]] - concept - 2026-11-06 Research - 20 trending Roblox games (videos watched).md
- [[Clean the Moon!]] - concept - 2026-11-06 Research - 20 trending Roblox games (videos watched).md
- [[DONT SPLASH]] - concept - 2026-11-06 Research - 20 trending Roblox games (videos watched).md
- [[Depth Incremental (10 videos watched)]] - document - 2026-11-06 Research - Depth Incremental (10 videos watched).md
- [[Depth Incremental monetization]] - concept - 2026-11-06 Research - Depth Incremental (10 videos watched).md
- [[Fossil rarity lists with max counts]] - concept - 2026-11-06 Research - Depth Incremental (10 videos watched).md
- [[Galaxy Incremental (was Supernova Incremental)]] - concept - 2026-11-06 PLAN - Trend research applied to Galaxy Incremental and +1 SHRINK.md
- [[Galaxy distance how far bar]] - concept - 2026-11-06 PLAN - Trend research applied to Galaxy Incremental and +1 SHRINK.md
- [[Miner's Haven]] - concept - 2026-11-04 Reincarnated Tycoon - next game check.md
- [[Modeling like a professional (stylized low poly)]] - document - 2026-11-01 Research - Modeling like a professional (stylized low poly).md
- [[Next game ideas from live Roblox charts]] - document - 2026-11-06 Research - Next game ideas from live Roblox charts.md
- [[Original muscle titan monster (not Venom)]] - concept - 2026-11-05 PLAYBOOK - Roblox icon, thumbnail and logo recipe.md
- [[PLAN - Trend research applied to Galaxy Incremental and +1 SHRINK]] - document - 2026-11-06 PLAN - Trend research applied to Galaxy Incremental and +1 SHRINK.md
- [[RNG titles kept on rebirth]] - concept - 2026-11-06 Research - Depth Incremental (10 videos watched).md
- [[Reincarnated Tycoon - next game check]] - document - 2026-11-04 Reincarnated Tycoon - next game check.md
- [[Reincarnated Tycoon]] - concept - 2026-11-04 Reincarnated Tycoon - next game check.md
- [[Retention kit (offline earnings, daily rewards, quests, codes, events)]] - concept - 2026-11-06 PLAN - Trend research applied to Galaxy Incremental and +1 SHRINK.md
- [[Roblox front page icons]] - document - 2026-11-03 Research - Roblox front page icons (owner screenshots 3 Nov).md
- [[Roblox-avatar simulator thumbnail style]] - concept - 2026-11-03 Research - Roblox front page icons (owner screenshots 3 Nov).md
- [[SPEED ARC (+1 Speed)]] - concept - 2026-11-06 Research - Next game ideas from live Roblox charts.md
- [[SPLIT beforeafter face concept]] - concept - 2026-11-03 Research - Roblox front page icons (owner screenshots 3 Nov).md
- [[Sell a Million Sushi]] - concept - 2026-11-06 Research - 20 trending Roblox games (videos watched).md
- [[Sol's-RNG style rare reveal]] - concept - 2026-11-06 Research - 20 trending Roblox games (videos watched).md
- [[Steal An Egg]] - concept - 2026-11-06 Research - 20 trending Roblox games (videos watched).md
- [[Stylized low-poly modeling principles]] - rationale - 2026-11-01 Research - Modeling like a professional (stylized low poly).md
- [[Supernova kit style guide (round + brass, faceted crystals)]] - concept - 2026-11-01 Research - Modeling like a professional (stylized low poly).md
- [[The title is the game]] - concept - 2026-11-06 Research - 20 trending Roblox games (videos watched).md
- [[Throw Food For Animals]] - concept - 2026-11-06 Research - 20 trending Roblox games (videos watched).md
- [[Tower Incremental]] - concept - 2026-11-06 Research - Depth Incremental (10 videos watched).md
- [[Trending game patterns (Nov 2026)]] - concept - 2026-11-06 Research - 20 trending Roblox games (videos watched).md
- [[Why Depth Incremental is addicting]] - rationale - 2026-11-06 Research - Depth Incremental (10 videos watched).md
- [[obby but you get smaller every stage]] - concept - 2026-11-06 Research - 20 trending Roblox games (videos watched).md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Trending_games_and_next_game_ideas
SORT file.name ASC
```

## Connections to other communities
- 7 edges to [[_COMMUNITY_Icons, thumbnails and owner clicks]]
- 6 edges to [[_COMMUNITY_Cutscenes and incremental HUDs]]
- 3 edges to [[_COMMUNITY_Dead game method and live tools]]

## Top bridge nodes
- [[Galaxy Incremental (was Supernova Incremental)]] - degree 12, connects to 2 communities
- [[+1 Depth Incremental]] - degree 10, connects to 1 community
- [[+1 SHRINK]] - degree 7, connects to 1 community
- [[+1 Venom Evolution]] - degree 5, connects to 1 community
- [[Roblox-avatar simulator thumbnail style]] - degree 5, connects to 1 community