---
source_file: "Playbook notes - Updates and live ops.md"
type: "concept"
community: "Updates, events and release slot"
location: "L133"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# GameJoinContext.EventId (event joiner attribution)

## Connections
- [[72-hour post-update scorecard]] - `shares_data_with` [INFERRED]
- [[Roblox Experience Events (Notify Me, Events section)]] - `shares_data_with` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Updates_events_and_release_slot