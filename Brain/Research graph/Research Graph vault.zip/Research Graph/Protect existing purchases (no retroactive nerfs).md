---
source_file: "Playbook notes - Updates and live ops.md"
type: "rationale"
community: "Updates, events and release slot"
location: "L53"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# Protect existing purchases (no retroactive nerfs)

## Connections
- [[Blox Fruits major-update timeline]] - `rationale_for` [EXTRACTED]
- [[Keep existing goals in reach (content above cap, catch-up boosts)]] - `conceptually_related_to` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Updates_events_and_release_slot