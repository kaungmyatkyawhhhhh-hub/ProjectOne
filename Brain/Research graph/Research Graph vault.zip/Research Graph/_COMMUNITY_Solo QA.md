---
type: community
cohesion: 0.25
members: 8
---

# Solo QA

**Cohesion:** 0.25 - loosely connected
**Members:** 8 nodes

## Members
- [[Error Report Monitoring]] - concept - Playbook notes - Game quality and QA.md
- [[Experience Betas]] - concept - Playbook notes - Discovery and marketing.md
- [[Experience Betas (QA)]] - concept - Playbook notes - Game quality and QA.md
- [[Low-end Android Device Testing Matrix]] - concept - Playbook notes - Game quality and QA.md
- [[Playtesting with Children]] - concept - Playbook notes - Game quality and QA.md
- [[Solo QA Process]] - rationale - Playbook notes - Game quality and QA.md
- [[Structured Logging (LogService templates)]] - concept - Playbook notes - Game quality and QA.md
- [[Version History and Rollback]] - concept - Playbook notes - Game quality and QA.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Solo_QA
SORT file.name ASC
```

## Connections to other communities
- 2 edges to [[_COMMUNITY_Quality and polish]]
- 1 edge to [[_COMMUNITY_Discovery and ads]]
- 1 edge to [[_COMMUNITY_Analytics benchmarks and diagnosis]]

## Top bridge nodes
- [[Solo QA Process]] - degree 7, connects to 1 community
- [[Error Report Monitoring]] - degree 3, connects to 1 community
- [[Experience Betas]] - degree 2, connects to 1 community