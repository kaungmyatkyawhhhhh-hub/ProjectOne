---
source_file: "Playbook notes - UI deep dive.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# React-Lua (Roact deprecated)

## Connections
- [[Playbook notes - UI deep dive]] - `references` [EXTRACTED]
- [[WindowManager and PopupQueue]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel