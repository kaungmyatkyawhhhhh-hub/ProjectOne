---
source_file: "Playbook notes - Performance, data and security.md"
type: "concept"
community: "Performance, data and security"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Performance_data_and_security
---

# Baseline Device Budget (1k draw calls / 1M triangles)

## Connections
- [[Avoid Partial Transparency (overdraw)]] - `conceptually_related_to` [EXTRACTED]
- [[Instance Streaming (Opportunistic stream-out)]] - `conceptually_related_to` [EXTRACTED]
- [[Mesh and Texture Reuse for Draw-Call Batching]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Performance, data and security]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Performance_data_and_security