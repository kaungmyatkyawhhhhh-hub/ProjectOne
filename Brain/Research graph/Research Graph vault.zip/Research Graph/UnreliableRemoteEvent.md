---
source_file: "Playbook notes - Optimization deep dive.md"
type: "concept"
community: "Optimization and retention mechanics"
location: "L342"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# UnreliableRemoteEvent

## Connections
- [[MicroProfiler Tag Table]] - `conceptually_related_to` [INFERRED]
- [[Prioritized Optimization Checklist]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Optimization_and_retention_mechanics