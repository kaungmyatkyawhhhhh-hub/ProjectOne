---
source_file: "2026-10-31 Atlas myth and trainer stories.md"
type: "rationale"
community: "Atlas story"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Atlas_story
---

# GYM ARC Atlas meteor-catch story

## Connections
- [[Atlas (Titan holding the sky)]] - `conceptually_related_to` [EXTRACTED]
- [[Atlas myth and trainer stories]] - `references` [EXTRACTED]
- [[Farnese Atlas statue]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Atlas_story