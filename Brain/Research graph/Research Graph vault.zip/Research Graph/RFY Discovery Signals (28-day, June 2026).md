---
source_file: "Playbook notes - Analytics and experiments.md"
type: "concept"
community: "Discovery and ads"
location: "L110"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Discovery_and_ads
---

# RFY Discovery Signals (28-day, June 2026)

## Connections
- [[Analytics and Experimentation for Roblox Experiences]] - `references` [EXTRACTED]
- [[Recommended For You Algorithm]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Discovery_and_ads