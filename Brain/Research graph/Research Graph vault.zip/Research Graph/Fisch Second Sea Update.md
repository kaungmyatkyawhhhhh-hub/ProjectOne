---
source_file: "Playbook notes - Costly mistakes of big games.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L15"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Fisch Second Sea Update

## Connections
- [[The 12 Rules from Big-Game Mistakes]] - `rationale_for` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths