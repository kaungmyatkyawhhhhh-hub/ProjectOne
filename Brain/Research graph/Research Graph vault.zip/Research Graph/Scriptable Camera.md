---
source_file: "Playbook notes - Lighting, cameras and cutscenes.md"
type: "concept"
community: "Lighting and cameras"
location: "L60"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Lighting_and_cameras
---

# Scriptable Camera

## Connections
- [[Cutscene Building Methods]] - `implements` [EXTRACTED]
- [[GG Camera Shake]] - `conceptually_related_to` [INFERRED]
- [[Lighting Quality Follows Camera.Focus]] - `conceptually_related_to` [EXTRACTED]
- [[Lighting, Cameras and Cutscenes for Roblox Simulators]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Lighting_and_cameras