---
source_file: "Playbook notes - Sound and music.md"
type: "document"
community: "UI, sound and game feel"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Playbook notes - Sound and music

## Connections
- [[AcousticSimulationEnabled OcclusionReverb]] - `references` [EXTRACTED]
- [[Audio API (AudioPlayer, Wire, AudioEmitter, AudioDeviceOutput)]] - `references` [EXTRACTED]
- [[Audio Upload Limits (200030 days, 20 MB, 7 min)]] - `references` [EXTRACTED]
- [[AudioFader Mixer Buses]] - `references` [EXTRACTED]
- [[AudioPlayer Pooling and Voice Limiting]] - `references` [EXTRACTED]
- [[Character Sounds Immersion Study (2024)]] - `references` [EXTRACTED]
- [[Creator Store Partner Audio (APM, Monstercat)]] - `references` [EXTRACTED]
- [[Legacy Sound and SoundService]] - `references` [EXTRACTED]
- [[Loudness Targets (-16 to -18 LUFS mobile)]] - `references` [EXTRACTED]
- [[Music Ducking Under Stingers]] - `references` [EXTRACTED]
- [[PitchVolume Variation on Repeated Sounds]] - `references` [EXTRACTED]
- [[Playbook notes - UI, game feel, art and sound]] - `references` [EXTRACTED]
- [[Rarity Stinger Escalation Ladder]] - `references` [EXTRACTED]
- [[UI Sound Vocabulary (one family, music key)]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/UI_sound_and_game_feel