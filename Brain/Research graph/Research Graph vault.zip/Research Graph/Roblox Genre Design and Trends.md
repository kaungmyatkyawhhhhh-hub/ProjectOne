---
source_file: "Playbook notes - Genres and trends.md"
type: "document"
community: "Core loop, incrementals and trends maths"
location: "L1"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Roblox Genre Design and Trends

## Connections
- [[99 Nights in the Forest]] - `references` [EXTRACTED]
- [[Dead Rails]] - `references` [EXTRACTED]
- [[Grow a Garden (trend case)]] - `references` [EXTRACTED]
- [[Pet Simulator 99 (BIG Games)]] - `references` [EXTRACTED]
- [[Proven Simulator Template]] - `references` [EXTRACTED]
- [[Roblox Creator Earnings Distribution]] - `references` [EXTRACTED]
- [[Steal a Brainrot (trend case)]] - `references` [EXTRACTED]
- [[Trend Lifecycle]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths