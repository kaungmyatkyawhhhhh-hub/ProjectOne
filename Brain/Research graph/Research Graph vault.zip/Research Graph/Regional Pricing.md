---
source_file: "Playbook notes - Monetization.md"
type: "concept"
community: "Money: DevEx and pricing"
location: "L108"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Money_DevEx_and_pricing
---

# Regional Pricing

## Connections
- [[Managed Pricing]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Money_DevEx_and_pricing