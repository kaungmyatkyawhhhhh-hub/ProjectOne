---
source_file: "Playbook notes - Updates and live ops.md"
type: "concept"
community: "Updates, events and release slot"
location: "L43"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# RoWatcher

## Connections
- [[Blox Fruits major-update timeline]] - `cites` [EXTRACTED]
- [[Platform concurrency peak Saturday ~1900 UTC (RoWatcher)]] - `cites` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Updates_events_and_release_slot