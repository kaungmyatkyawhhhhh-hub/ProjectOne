---
source_file: "Playbook notes - Passes and products catalogue.md"
type: "concept"
community: "Passes and products"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Passes_and_products
---

# Gym/Running Simulator Starter Catalogue (6-8 passes)

## Connections
- [[Pet Simulator 99 Pass Catalogue]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Passes and products catalogue]] - `references` [EXTRACTED]
- [[Promoted Pass Price Window (49-801 R$)]] - `rationale_for` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Passes_and_products