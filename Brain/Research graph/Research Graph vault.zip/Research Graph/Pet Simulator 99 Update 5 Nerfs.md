---
source_file: "Playbook notes - Costly mistakes of big games.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L17"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Pet Simulator 99 Update 5 Nerfs

## Connections
- [[Pet Simulator 99 (BIG Games)]] - `conceptually_related_to` [INFERRED]
- [[The 12 Rules from Big-Game Mistakes]] - `rationale_for` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths