---
source_file: "Playbook notes - Updates and live ops.md"
type: "rationale"
community: "Updates, events and release slot"
location: "L54"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# Vary event types to avoid repetitive-event fatigue

## Connections
- [[Grow a Garden weekly updates and 2-week events]] - `rationale_for` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Updates_events_and_release_slot