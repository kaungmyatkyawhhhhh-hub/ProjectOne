---
source_file: "Playbook notes - Analytics in practice.md"
type: "concept"
community: "Analytics benchmarks and diagnosis"
location: "L136"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Analytics_benchmarks_and_diagnosis
---

# Retention Levers (D1 FTUE, D7 progression, D30 updates/social)

## Connections
- [[Diagnosis Playbooks]] - `references` [EXTRACTED]
- [[Practical Roblox Analytics Instrumentation and Diagnosis]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Analytics_benchmarks_and_diagnosis