---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L20"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# ParticleOrientation modes

## Connections
- [[ParticleEmitter]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles