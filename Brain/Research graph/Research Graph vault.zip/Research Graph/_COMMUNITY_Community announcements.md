---
type: community
cohesion: 1.00
members: 1
---

# Community announcements

**Cohesion:** 1.00 - tightly connected
**Members:** 1 nodes

## Members
- [[Community Announcements (replace Shouts)]] - concept - Playbook notes - Whole-game research (Oct 2026).md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Community_announcements
SORT file.name ASC
```
