---
source_file: "Playbook notes - Logos.md"
type: "concept"
community: "Names, logos and IP safety"
location: "L56"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# AI-Generated Logos and US Copyright Office Report

## Connections
- [[Never Ship AI Images Rule]] - `conceptually_related_to` [INFERRED]
- [[Trademark  IP Basics for Logos]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Names_logos_and_IP_safety