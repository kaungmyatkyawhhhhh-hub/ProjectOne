---
source_file: "Playbook notes - Analytics and experiments.md"
type: "concept"
community: "Analytics events"
location: "L43"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Analytics_events
---

# Onboarding Funnel Events

## Connections
- [[AnalyticsService API]] - `implements` [EXTRACTED]
- [[Simulator Instrumentation Event Map]] - `references` [EXTRACTED]
- [[Weekly Analytics Routine]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Analytics_events