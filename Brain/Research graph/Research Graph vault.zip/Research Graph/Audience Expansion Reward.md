---
source_file: "Playbook notes - Monetization.md"
type: "concept"
community: "Names, logos and IP safety"
location: "L42"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# Audience Expansion Reward

## Connections
- [[Creator Rewards (Daily Engagement Reward)]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Names_logos_and_IP_safety