---
source_file: "Playbook notes - UI deep dive.md"
type: "concept"
community: "Passes and products"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/Passes_and_products
---

# Converting Shop Layout

## Connections
- [[Bundle-Fit Price Ladder]] - `conceptually_related_to` [INFERRED]
- [[Gift-a-Pass Developer Product Pattern]] - `conceptually_related_to` [INFERRED]
- [[Playbook notes - UI deep dive]] - `references` [EXTRACTED]

#graphify/concept #graphify/INFERRED #community/Passes_and_products