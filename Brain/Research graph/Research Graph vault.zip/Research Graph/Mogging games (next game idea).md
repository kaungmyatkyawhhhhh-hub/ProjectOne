---
source_file: "2026-11-06 Research - Mogging games (next game idea).md"
type: "document"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# Mogging games (next game idea)

## Connections
- [[Flexpose-off battle for GYM ARC]] - `references` [EXTRACTED]
- [[Mog and Gym (Looksmax and Mog)]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks