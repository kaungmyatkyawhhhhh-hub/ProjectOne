---
source_file: "Playbook notes - Game quality and QA.md"
type: "concept"
community: "Solo QA"
location: "L89"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Solo_QA
---

# Error Report Monitoring

## Connections
- [[Error Report]] - `semantically_similar_to` [INFERRED]
- [[Solo QA Process]] - `references` [EXTRACTED]
- [[Structured Logging (LogService templates)]] - `shares_data_with` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Solo_QA