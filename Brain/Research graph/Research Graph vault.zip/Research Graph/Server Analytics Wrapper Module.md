---
source_file: "Playbook notes - Analytics in practice.md"
type: "code"
community: "Analytics events"
location: "L54"
tags:
  - graphify/code
  - graphify/EXTRACTED
  - community/Analytics_events
---

# Server Analytics Wrapper Module

## Connections
- [[AnalyticsService API]] - `implements` [EXTRACTED]
- [[Simulator Instrumentation Event Map]] - `references` [EXTRACTED]

#graphify/code #graphify/EXTRACTED #community/Analytics_events