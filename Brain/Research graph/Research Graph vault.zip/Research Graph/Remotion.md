---
source_file: "2026-11-07 Video edit style - what makes an edit good (reference study).md"
type: "concept"
community: "Cutscenes and incremental HUDs"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Cutscenes_and_incremental_HUDs
---

# Remotion

## Connections
- [[Galaxy TikTok v2 beat-sync edit]] - `references` [EXTRACTED]
- [[Video edit style - what makes an edit good]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Cutscenes_and_incremental_HUDs