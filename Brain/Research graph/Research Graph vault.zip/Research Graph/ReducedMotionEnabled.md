---
source_file: "Playbook notes - UI, game feel, art and sound.md"
type: "code"
community: "UI, sound and game feel"
tags:
  - graphify/code
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# ReducedMotionEnabled

## Connections
- [[Accessibility Preference APIs]] - `conceptually_related_to` [EXTRACTED]
- [[CanvasGroup Memory Cost]] - `conceptually_related_to` [EXTRACTED]
- [[Juice (Juice it or lose it)]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - UI, game feel, art and sound]] - `references` [EXTRACTED]

#graphify/code #graphify/EXTRACTED #community/UI_sound_and_game_feel