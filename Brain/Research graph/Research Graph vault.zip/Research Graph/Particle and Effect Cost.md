---
source_file: "Playbook notes - Optimization deep dive.md"
type: "concept"
community: "Optimization and retention mechanics"
location: "L208"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# Particle and Effect Cost

## Connections
- [[MicroProfiler Tag Table]] - `references` [EXTRACTED]
- [[ParticleEmitter Performance Rules]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Optimization_and_retention_mechanics