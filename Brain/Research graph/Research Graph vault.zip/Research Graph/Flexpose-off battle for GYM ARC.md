---
source_file: "2026-11-06 Research - Mogging games (next game idea).md"
type: "rationale"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# Flex/pose-off battle for GYM ARC

## Connections
- [[GYM ARC]] - `conceptually_related_to` [EXTRACTED]
- [[Mog and Gym (Looksmax and Mog)]] - `conceptually_related_to` [EXTRACTED]
- [[Mogging games (next game idea)]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks