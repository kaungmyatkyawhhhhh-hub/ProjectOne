---
source_file: "Playbook notes - Optimization deep dive.md"
type: "concept"
community: "Memory debugging"
location: "L135"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Memory_debugging
---

# Luau Heap Snapshots

## Connections
- [[Developer Console Memory Categories]] - `references` [EXTRACTED]
- [[Mobile Out-of-Memory Exits]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Memory_debugging