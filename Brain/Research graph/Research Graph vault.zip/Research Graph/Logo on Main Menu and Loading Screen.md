---
source_file: "Playbook notes - Logos.md"
type: "concept"
community: "Logos, loading screen and GYM ARC art"
location: "L103"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/Logos_loading_screen_and_GYM_ARC_art
---

# Logo on Main Menu and Loading Screen

## Connections
- [[Loading Screen Design (GYM ARC)]] - `conceptually_related_to` [INFERRED]
- [[Roblox Game Logo Layer Recipe]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/INFERRED #community/Logos_loading_screen_and_GYM_ARC_art