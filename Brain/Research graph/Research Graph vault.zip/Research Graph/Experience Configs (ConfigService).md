---
source_file: "Playbook notes - Admin panels and live tools.md"
type: "concept"
community: "Dead game method and live tools"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Dead_game_method_and_live_tools
---

# Experience Configs (ConfigService)

## Connections
- [[Admin panels and live tools]] - `references` [EXTRACTED]
- [[Config kill switch pattern]] - `implements` [EXTRACTED]
- [[EventController server module]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Dead_game_method_and_live_tools