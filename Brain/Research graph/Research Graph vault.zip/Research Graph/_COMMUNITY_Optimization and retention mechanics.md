---
type: community
cohesion: 0.08
members: 30
---

# Optimization and retention mechanics

**Cohesion:** 0.08 - loosely connected
**Members:** 30 nodes

## Members
- [[Discount Honesty Rules (no fake sales or resetting timers)]] - rationale - Playbook notes - Monetization.md
- [[Flipbook Textures]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[GYM ARC Aura Tier Recipe]] - rationale - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[GYM ARC Starter 49 R$  Premium Pack 199 R$]] - concept - Playbook notes - Monetization.md
- [[Lighting.LightingStyle and Local Light Cost]] - concept - Playbook notes - Optimization deep dive.md
- [[Luau Native Code Generation]] - concept - Playbook notes - Optimization deep dive.md
- [[Luau Performance Idioms]] - concept - Playbook notes - Optimization deep dive.md
- [[Mesh Instancing and Batching]] - concept - Playbook notes - Optimization deep dive.md
- [[MicroProfiler]] - concept - Playbook notes - Optimization deep dive.md
- [[MicroProfiler Bar Colors (orangebluered)]] - concept - Playbook notes - Optimization deep dive.md
- [[MicroProfiler Tag Table]] - concept - Playbook notes - Optimization deep dive.md
- [[Parallel Luau (Actors)]] - concept - Playbook notes - Optimization deep dive.md
- [[Particle and Effect Cost]] - concept - Playbook notes - Optimization deep dive.md
- [[ParticleEmitter Performance Rules]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Performance Dashboard]] - concept - Playbook notes - Optimization deep dive.md
- [[Prioritized Optimization Checklist]] - rationale - Playbook notes - Optimization deep dive.md
- [[Rarity Roll Reveal  Altar Reveal]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Recommended For You 28-Day Window Change (Apr 2026)]] - concept - Playbook notes - Names and descriptions.md
- [[Reference Case 31 FPS, 24k Parts, 421 Lights, 681 SurfaceGuis]] - concept - Playbook notes - Optimization deep dive.md
- [[Roblox Discovery Algorithm Signals]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Rules of Conduct Misleading Metadata Ban]] - concept - Playbook notes - Names and descriptions.md
- [[Script Profiler]] - concept - Playbook notes - Optimization deep dive.md
- [[Server Memory Capacity (6.25 GiB + 100 MiB per player)]] - concept - Playbook notes - Optimization deep dive.md
- [[Shop UX and Calm Wording for Minors]] - rationale - Playbook notes - Monetization.md
- [[Sol's RNG_1]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Starter Packs]] - concept - Playbook notes - Monetization.md
- [[SurfaceGui  BillboardGui Render Cost]] - concept - Playbook notes - Optimization deep dive.md
- [[Top-Game Retention Mechanics (11)]] - rationale - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[University of Sydney Study on Deceptive Purchase Design]] - paper - Playbook notes - Monetization.md
- [[UnreliableRemoteEvent]] - concept - Playbook notes - Optimization deep dive.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Optimization_and_retention_mechanics
SORT file.name ASC
```

## Connections to other communities
- 2 edges to [[_COMMUNITY_Weekly updates and trainer collection]]
- 1 edge to [[_COMMUNITY_Names, logos and IP safety]]
- 1 edge to [[_COMMUNITY_Logos, loading screen and GYM ARC art]]

## Top bridge nodes
- [[Top-Game Retention Mechanics (11)]] - degree 5, connects to 2 communities
- [[Prioritized Optimization Checklist]] - degree 7, connects to 1 community