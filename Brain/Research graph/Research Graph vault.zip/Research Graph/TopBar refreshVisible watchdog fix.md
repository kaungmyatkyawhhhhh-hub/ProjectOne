---
source_file: "2026-10-30 TopbarPlus not showing.md"
type: "rationale"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# TopBar refreshVisible watchdog fix

## Connections
- [[GYM ARC]] - `conceptually_related_to` [EXTRACTED]
- [[TopbarPlus (v3.4.0  v3.5.0)]] - `conceptually_related_to` [EXTRACTED]
- [[TopbarPlus not showing]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks