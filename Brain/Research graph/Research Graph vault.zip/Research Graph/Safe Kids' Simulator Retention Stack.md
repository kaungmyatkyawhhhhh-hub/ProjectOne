---
source_file: "Playbook notes - Onboarding, retention and live ops.md"
type: "rationale"
community: "Weekly updates and trainer collection"
location: "L123"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Weekly_updates_and_trainer_collection
---

# Safe Kids' Simulator Retention Stack

## Connections
- [[Experience Notifications (Open Cloud)]] - `references` [EXTRACTED]
- [[Grow a Garden_1]] - `references` [EXTRACTED]
- [[Paid Random Items Policy_2]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Weekly_updates_and_trainer_collection