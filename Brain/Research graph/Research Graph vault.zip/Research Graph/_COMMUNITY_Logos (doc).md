---
type: community
cohesion: 1.00
members: 1
---

# Logos (doc)

**Cohesion:** 1.00 - tightly connected
**Members:** 1 nodes

## Members
- [[Playbook notes - Logos]] - document - Playbook notes - Logos.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Logos_doc
SORT file.name ASC
```
