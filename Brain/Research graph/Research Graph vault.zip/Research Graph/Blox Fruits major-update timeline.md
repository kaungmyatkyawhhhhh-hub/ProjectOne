---
source_file: "Playbook notes - Updates and live ops.md"
type: "concept"
community: "Updates, events and release slot"
location: "L32"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# Blox Fruits major-update timeline

## Connections
- [[Protect existing purchases (no retroactive nerfs)]] - `rationale_for` [EXTRACTED]
- [[RoWatcher]] - `cites` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Updates_events_and_release_slot