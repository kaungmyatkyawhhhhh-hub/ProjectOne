---
source_file: "Playbook notes - Performance, data and security.md"
type: "concept"
community: "Performance, data and security"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Performance_data_and_security
---

# Texture Memory Budget (<=512 px)

## Connections
- [[Instance Streaming (Opportunistic stream-out)]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Performance, data and security]] - `references` [EXTRACTED]
- [[Sprite Sheet Icon Atlas]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Performance_data_and_security