---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "World layout (weenies)"
location: "L54"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/World_layout_weenies
---

# Weenies and world layout (Rogers, GDC 2009)

#graphify/concept #graphify/EXTRACTED #community/World_layout_weenies