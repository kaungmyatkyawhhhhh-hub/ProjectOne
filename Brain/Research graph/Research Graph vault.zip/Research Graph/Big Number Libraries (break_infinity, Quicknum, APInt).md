---
source_file: "Playbook notes - Incremental games.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L62"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Big Number Libraries (break_infinity, Quicknum, APInt)

## Connections
- [[Antimatter Dimensions Infinity Layer]] - `references` [EXTRACTED]
- [[Incremental  Idle Game Design and Math]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths