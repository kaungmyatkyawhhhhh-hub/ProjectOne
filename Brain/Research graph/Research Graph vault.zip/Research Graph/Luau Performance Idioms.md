---
source_file: "Playbook notes - Optimization deep dive.md"
type: "concept"
community: "Optimization and retention mechanics"
location: "L282"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/Optimization_and_retention_mechanics
---

# Luau Performance Idioms

## Connections
- [[Luau Native Code Generation]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/INFERRED #community/Optimization_and_retention_mechanics