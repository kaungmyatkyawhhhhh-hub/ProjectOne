---
source_file: "Playbook notes - Sound and music.md"
type: "paper"
community: "UI, sound and game feel"
tags:
  - graphify/paper
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Character Sounds Immersion Study (2024)

## Connections
- [[Playbook notes - Sound and music]] - `references` [EXTRACTED]
- [[UI Sound Vocabulary (one family, music key)]] - `rationale_for` [INFERRED]

#graphify/paper #graphify/EXTRACTED #community/UI_sound_and_game_feel