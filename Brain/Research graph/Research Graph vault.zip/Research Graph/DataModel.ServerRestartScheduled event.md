---
source_file: "Playbook notes - Updates and live ops.md"
type: "concept"
community: "Updates, events and release slot"
location: "L166"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# DataModel.ServerRestartScheduled event

## Connections
- [[Server Management Restart Servers (soft shutdown)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Updates_events_and_release_slot