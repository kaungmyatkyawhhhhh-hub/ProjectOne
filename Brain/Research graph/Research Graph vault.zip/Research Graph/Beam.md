---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L37"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# Beam

## Connections
- [[Level-up recipe]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles