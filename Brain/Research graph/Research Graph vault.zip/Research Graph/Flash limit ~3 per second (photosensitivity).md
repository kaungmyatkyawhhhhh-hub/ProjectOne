---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L125"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# Flash limit ~3 per second (photosensitivity)

## Connections
- [[Camera shake, FOV punch and hit-stop]] - `references` [EXTRACTED]
- [[Photosensitivity limit (WCAG 2.3.1)]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles