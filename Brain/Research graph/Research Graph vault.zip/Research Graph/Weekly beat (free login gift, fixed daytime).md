---
source_file: "Playbook notes - Updates and live ops.md"
type: "concept"
community: "Updates, events and release slot"
location: "L48"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# Weekly beat (free login gift, fixed day/time)

## Connections
- [[Pet Simulator 99 Saturday Update]] - `rationale_for` [EXTRACTED]
- [[Two-tier update cadence (weekly beat + 2-4 week content drops)]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Updates_events_and_release_slot