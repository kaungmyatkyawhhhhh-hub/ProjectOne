---
source_file: "Playbook notes - Optimization deep dive.md"
type: "concept"
community: "Optimization and retention mechanics"
location: "L263"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# Luau Native Code Generation

## Connections
- [[Luau Performance Idioms]] - `conceptually_related_to` [INFERRED]
- [[Script Profiler]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Optimization_and_retention_mechanics