---
type: community
cohesion: 0.67
members: 3
---

# Memory debugging

**Cohesion:** 0.67 - moderately connected
**Members:** 3 nodes

## Members
- [[Developer Console Memory Categories]] - concept - Playbook notes - Optimization deep dive.md
- [[Luau Heap Snapshots]] - concept - Playbook notes - Optimization deep dive.md
- [[Mobile Out-of-Memory Exits]] - concept - Playbook notes - Optimization deep dive.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Memory_debugging
SORT file.name ASC
```
