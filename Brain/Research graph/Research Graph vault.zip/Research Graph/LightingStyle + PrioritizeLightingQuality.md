---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "VFX and particles"
location: "L55"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/VFX_and_particles
---

# LightingStyle + PrioritizeLightingQuality

## Connections
- [[Lighting.Technology superseded by LightingStyle + PrioritizeLightingQuality]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/INFERRED #community/VFX_and_particles