---
source_file: "Playbook notes - Incremental games.md"
type: "rationale"
community: "Core loop, incrementals and trends maths"
location: "L73"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Greedy Purchase Simulation

## Connections
- [[Exponential Cost vs Polynomial Production Seesaw]] - `rationale_for` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths