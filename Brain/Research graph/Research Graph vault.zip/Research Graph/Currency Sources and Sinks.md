---
source_file: "Playbook notes - Core loop design.md"
type: "concept"
community: "Analytics events"
location: "L126"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Analytics_events
---

# Currency Sources and Sinks

## Connections
- [[Core Loop Design for Roblox Simulators and Casual Games]] - `references` [EXTRACTED]
- [[Economy SourceSink Events]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Analytics_events