---
source_file: "Playbook notes - Analytics and experiments.md"
type: "concept"
community: "Analytics events"
location: "L94"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Analytics_events
---

# Managed Pricing / Price Optimization

## Connections
- [[Analytics and Experimentation for Roblox Experiences]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Analytics_events