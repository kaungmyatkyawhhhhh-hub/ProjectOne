---
source_file: "Playbook notes - Names and descriptions.md"
type: "concept"
community: "Optimization and retention mechanics"
location: "L92"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# Recommended For You 28-Day Window Change (Apr 2026)

## Connections
- [[Roblox Discovery Algorithm Signals]] - `semantically_similar_to` [INFERRED]
- [[Rules of Conduct Misleading Metadata Ban]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Optimization_and_retention_mechanics