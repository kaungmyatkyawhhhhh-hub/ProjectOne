---
source_file: "Playbook notes - Thumbnails.md"
type: "concept"
community: "Thumbnail art study and testing"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Thumbnail_art_study_and_testing
---

# PTR / qPTR Ranking Signals

## Connections
- [[Clickbait and Honesty Rules]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Thumbnails]] - `references` [EXTRACTED]
- [[Thumbnail Personalization (multi-armed bandit)]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Thumbnail_art_study_and_testing