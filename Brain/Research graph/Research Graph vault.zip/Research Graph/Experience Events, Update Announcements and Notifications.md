---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "concept"
community: "Weekly updates and trainer collection"
location: "L440"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Weekly_updates_and_trainer_collection
---

# Experience Events, Update Announcements and Notifications

## Connections
- [[Experience Notifications (Open Cloud)]] - `semantically_similar_to` [INFERRED]
- [[Weekly Saturday Update Template]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Weekly_updates_and_trainer_collection