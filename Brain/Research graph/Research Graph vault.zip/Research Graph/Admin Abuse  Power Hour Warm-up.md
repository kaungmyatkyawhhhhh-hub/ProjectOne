---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "concept"
community: "Weekly updates and trainer collection"
location: "L447"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Weekly_updates_and_trainer_collection
---

# Admin Abuse / Power Hour Warm-up

## Connections
- [[Admin Abuse Events  Admin War]] - `semantically_similar_to` [INFERRED]
- [[Grow a Garden]] - `references` [EXTRACTED]
- [[Weekly Saturday Update Template]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Weekly_updates_and_trainer_collection