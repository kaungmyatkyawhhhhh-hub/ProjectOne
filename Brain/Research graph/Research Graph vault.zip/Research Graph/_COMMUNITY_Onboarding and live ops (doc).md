---
type: community
cohesion: 1.00
members: 1
---

# Onboarding and live ops (doc)

**Cohesion:** 1.00 - tightly connected
**Members:** 1 nodes

## Members
- [[Playbook notes - Onboarding, retention and live ops]] - document - Playbook notes - Onboarding, retention and live ops.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Onboarding_and_live_ops_doc
SORT file.name ASC
```
