---
source_file: "Playbook notes - Sound and music.md"
type: "rationale"
community: "UI, sound and game feel"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Pitch/Volume Variation on Repeated Sounds

## Connections
- [[AudioPlayer Pooling and Voice Limiting]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Sound and music]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/UI_sound_and_game_feel