---
source_file: "Playbook notes - Game quality and QA.md"
type: "concept"
community: "Discovery and ads"
location: "L7"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Discovery_and_ads
---

# Behaviour-based Quality Judgement

## Connections
- [[Game Quality and Polish for Roblox Kids' Simulators]] - `references` [EXTRACTED]
- [[Recommended For You Algorithm]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Discovery_and_ads