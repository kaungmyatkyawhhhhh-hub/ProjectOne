---
source_file: "Playbook notes - Genres and trends.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L96"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Trend Lifecycle

## Connections
- [[Grow a Garden (trend case)]] - `references` [EXTRACTED]
- [[Roblox Genre Design and Trends]] - `references` [EXTRACTED]
- [[SPTS and Muscle Transform Update Stops]] - `conceptually_related_to` [INFERRED]
- [[Steal a Brainrot (trend case)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths