---
source_file: "Playbook notes - Updates and live ops.md"
type: "concept"
community: "Updates, events and release slot"
location: "L212"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/Updates_events_and_release_slot
---

# 72-hour post-update scorecard

## Connections
- [[GameJoinContext.EventId (event joiner attribution)]] - `shares_data_with` [INFERRED]
- [[Platform concurrency peak Saturday ~1900 UTC (RoWatcher)]] - `rationale_for` [INFERRED]

#graphify/concept #graphify/INFERRED #community/Updates_events_and_release_slot