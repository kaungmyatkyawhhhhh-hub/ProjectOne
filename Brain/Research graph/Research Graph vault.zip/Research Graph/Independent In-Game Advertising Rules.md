---
source_file: "Playbook notes - Policy, safety and community.md"
type: "concept"
community: "Policy, safety and kids rules"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Policy_safety_and_kids_rules
---

# Independent In-Game Advertising Rules

## Connections
- [[Playbook notes - Policy, safety and community]] - `references` [EXTRACTED]
- [[PolicyService RegionalAge Gating]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Policy_safety_and_kids_rules