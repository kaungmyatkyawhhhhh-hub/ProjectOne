---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "rationale"
community: "Updates, events and release slot"
location: "L49"
tags:
  - graphify/rationale
  - graphify/INFERRED
  - community/Updates_events_and_release_slot
---

# Kids' monetization ethics (FTC vs HoYoverse, UK Children's Code)

## Connections
- [[Gacha norms (visible pity, duplicate conversion)]] - `conceptually_related_to` [INFERRED]
- [[Paid random items rules (odds, PolicyService)]] - `conceptually_related_to` [INFERRED]

#graphify/rationale #graphify/INFERRED #community/Updates_events_and_release_slot