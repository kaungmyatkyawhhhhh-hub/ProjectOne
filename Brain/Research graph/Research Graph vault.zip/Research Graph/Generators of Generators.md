---
source_file: "Playbook notes - Incremental games.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L20"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Generators of Generators

## Connections
- [[Antimatter Dimensions Infinity Layer]] - `conceptually_related_to` [EXTRACTED]
- [[Incremental  Idle Game Design and Math]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths