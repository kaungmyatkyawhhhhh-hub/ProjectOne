---
type: community
cohesion: 0.17
members: 15
---

# Lighting and cameras

**Cohesion:** 0.17 - loosely connected
**Members:** 15 nodes

## Members
- [[AI-generated Icon and Safe Imagery Rules]] - concept - Playbook notes - Icons and titles.md
- [[Atmosphere and Post-processing Effects]] - concept - Playbook notes - Lighting, cameras and cutscenes.md
- [[CineCam v3 Plugin]] - concept - Playbook notes - Lighting, cameras and cutscenes.md
- [[Cutscene Building Methods]] - concept - Playbook notes - Lighting, cameras and cutscenes.md
- [[GG Camera Shake]] - concept - Playbook notes - Lighting, cameras and cutscenes.md
- [[LetterBoxer Module]] - concept - Playbook notes - Lighting, cameras and cutscenes.md
- [[Lighting Quality Follows Camera.Focus]] - concept - Playbook notes - Lighting, cameras and cutscenes.md
- [[Lighting, Cameras and Cutscenes for Roblox Simulators]] - document - Playbook notes - Lighting, cameras and cutscenes.md
- [[LightingStyle (Realistic  Soft)]] - concept - Playbook notes - Lighting, cameras and cutscenes.md
- [[Local Light Cost (Spot  Surface  Point)]] - concept - Playbook notes - Lighting, cameras and cutscenes.md
- [[Phone-first Lighting Baseline]] - rationale - Playbook notes - Lighting, cameras and cutscenes.md
- [[PrioritizeLightingQuality]] - concept - Playbook notes - Lighting, cameras and cutscenes.md
- [[Reduced Motion (GuiService.ReducedMotionEnabled)]] - concept - Playbook notes - Lighting, cameras and cutscenes.md
- [[Scriptable Camera]] - concept - Playbook notes - Lighting, cameras and cutscenes.md
- [[ThumbnailIcon Photo-booth Capture]] - rationale - Playbook notes - Lighting, cameras and cutscenes.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Lighting_and_cameras
SORT file.name ASC
```

## Connections to other communities
- 1 edge to [[_COMMUNITY_Titles, search and copycat rules]]

## Top bridge nodes
- [[AI-generated Icon and Safe Imagery Rules]] - degree 2, connects to 1 community