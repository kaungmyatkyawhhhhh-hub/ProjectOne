---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "Co-play signals"
location: "L30"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Co-play_signals
---

# Social co-play and friend invites

## Connections
- [[Recommended For You discovery signals (Jun 2026)]] - `shares_data_with` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Co-play_signals