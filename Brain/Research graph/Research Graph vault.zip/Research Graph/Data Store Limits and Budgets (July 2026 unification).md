---
source_file: "Playbook notes - Performance, data and security.md"
type: "concept"
community: "Performance, data and security"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Performance_data_and_security
---

# Data Store Limits and Budgets (July 2026 unification)

## Connections
- [[OrderedDataStore Leaderboards]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Performance, data and security]] - `references` [EXTRACTED]
- [[ProfileStore Session-Locked Saving]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Performance_data_and_security