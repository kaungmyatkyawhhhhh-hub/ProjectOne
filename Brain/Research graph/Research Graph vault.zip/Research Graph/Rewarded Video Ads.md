---
source_file: "Playbook notes - Discovery and marketing.md"
type: "concept"
community: "Discovery and ads"
location: "L241"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Discovery_and_ads
---

# Rewarded Video Ads

## Connections
- [[Roblox Discovery and Marketing]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Discovery_and_ads