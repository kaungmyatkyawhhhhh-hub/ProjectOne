---
source_file: "Playbook notes - Admin panels and live tools.md"
type: "concept"
community: "Dead game method and live tools"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Dead_game_method_and_live_tools
---

# EventController server module

## Connections
- [[Admin abuse events_1]] - `implements` [EXTRACTED]
- [[Admin panels and live tools]] - `references` [EXTRACTED]
- [[Experience Configs (ConfigService)]] - `references` [EXTRACTED]
- [[MessagingService]] - `references` [EXTRACTED]
- [[Monthly free party event]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Dead_game_method_and_live_tools