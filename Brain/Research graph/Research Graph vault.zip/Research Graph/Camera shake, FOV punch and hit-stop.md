---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L125"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# Camera shake, FOV punch and hit-stop

## Connections
- [[Flash limit ~3 per second (photosensitivity)]] - `references` [EXTRACTED]
- [[Game juice (Jonasson & Purho; Nijman)]] - `conceptually_related_to` [INFERRED]
- [[GuiService.ReducedMotionEnabled]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles