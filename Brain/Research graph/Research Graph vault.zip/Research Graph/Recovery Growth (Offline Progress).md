---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "concept"
community: "Weekly updates and trainer collection"
location: "L61"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Weekly_updates_and_trainer_collection
---

# Recovery Growth (Offline Progress)

## Connections
- [[GYM ARC Ranked Retention Plan]] - `references` [EXTRACTED]
- [[Grow a Garden]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Weekly_updates_and_trainer_collection