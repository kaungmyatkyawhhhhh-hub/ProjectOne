---
source_file: "2026-11-03 Research - Bacon hair in thumbnails.md"
type: "concept"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# Bacon Hair (Pal Hair default avatar)

## Connections
- [[Bacon growth-row thumbnail (4'0 - 5'8 - 7'0)]] - `conceptually_related_to` [EXTRACTED]
- [[Bacon hair in thumbnails]] - `references` [EXTRACTED]
- [[Noob avatar (classic default)]] - `conceptually_related_to` [EXTRACTED]
- [[Roblox-avatar simulator thumbnail style]] - `references` [EXTRACTED]
- [[Thumbnail Personalization]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks