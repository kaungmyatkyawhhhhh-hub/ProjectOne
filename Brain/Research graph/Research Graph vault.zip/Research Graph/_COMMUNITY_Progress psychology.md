---
type: community
cohesion: 1.00
members: 2
---

# Progress psychology

**Cohesion:** 1.00 - tightly connected
**Members:** 2 nodes

## Members
- [[Endowed progress effect (Nunes & Dreze 2006)]] - paper - Playbook notes - Whole-game research (Oct 2026).md
- [[Goal gradient effect (Kivetz)]] - paper - Playbook notes - Whole-game research (Oct 2026).md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Progress_psychology
SORT file.name ASC
```
