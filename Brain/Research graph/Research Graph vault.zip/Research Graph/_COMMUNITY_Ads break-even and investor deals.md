---
type: community
cohesion: 0.50
members: 4
---

# Ads break-even and investor deals

**Cohesion:** 0.50 - moderately connected
**Members:** 4 nodes

## Members
- [[DevEx rate and terms]] - concept - Playbook notes - Whole-game research (Oct 2026).md
- [[Investor revenue-share deal shape]] - concept - Playbook notes - Whole-game research (Oct 2026).md
- [[Paid-player break-even (2.6-7.1 R$ lifetime)]] - rationale - Playbook notes - Whole-game research (Oct 2026).md
- [[Roblox Ads Manager (cost per play benchmarks)]] - concept - Playbook notes - Whole-game research (Oct 2026).md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Ads_break-even_and_investor_deals
SORT file.name ASC
```
