---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "VFX and particles"
location: "L45"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/VFX_and_particles
---

# Game juice (Jonasson & Purho; Nijman)

## Connections
- [[Camera shake, FOV punch and hit-stop]] - `conceptually_related_to` [INFERRED]
- [[Three-phase VFX timing (anticipation, impact, dissipation)]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/INFERRED #community/VFX_and_particles