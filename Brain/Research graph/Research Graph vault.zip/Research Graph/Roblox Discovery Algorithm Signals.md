---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "concept"
community: "Optimization and retention mechanics"
location: "L27"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/Optimization_and_retention_mechanics
---

# Roblox Discovery Algorithm Signals

## Connections
- [[Recommended For You 28-Day Window Change (Apr 2026)]] - `semantically_similar_to` [INFERRED]
- [[Top-Game Retention Mechanics (11)]] - `rationale_for` [INFERRED]

#graphify/concept #graphify/INFERRED #community/Optimization_and_retention_mechanics