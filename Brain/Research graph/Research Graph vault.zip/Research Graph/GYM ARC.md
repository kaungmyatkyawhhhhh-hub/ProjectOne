---
source_file: "2026-10-30 Icon and thumbnail testing.md"
type: "concept"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# GYM ARC

## Connections
- [[Bacon growth-row thumbnail (4'0 - 5'8 - 7'0)]] - `conceptually_related_to` [EXTRACTED]
- [[Blender Python model pipeline (vertex colours, .fbx)]] - `conceptually_related_to` [EXTRACTED]
- [[Flexpose-off battle for GYM ARC]] - `conceptually_related_to` [EXTRACTED]
- [[GEM giant thumbnail concept]] - `conceptually_related_to` [EXTRACTED]
- [[GYM ARC Plus perks (+20% EXP, +10% coins, +15% stamina)]] - `conceptually_related_to` [EXTRACTED]
- [[GYM ARC barbell-overhead Hall of Fame icon]] - `conceptually_related_to` [EXTRACTED]
- [[GYM ARC logo (final v6v7)]] - `conceptually_related_to` [EXTRACTED]
- [[Icon and thumbnail testing]] - `references` [EXTRACTED]
- [[Mog and Gym (Looksmax and Mog)]] - `conceptually_related_to` [EXTRACTED]
- [[Screen-space cutscene template (per-item colour + symbol)]] - `conceptually_related_to` [EXTRACTED]
- [[Search shows first 169 gallery image (since 16 Mar 2026)]] - `conceptually_related_to` [EXTRACTED]
- [[TopBar refreshVisible watchdog fix]] - `conceptually_related_to` [EXTRACTED]
- [[TrainerStories narrator]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks