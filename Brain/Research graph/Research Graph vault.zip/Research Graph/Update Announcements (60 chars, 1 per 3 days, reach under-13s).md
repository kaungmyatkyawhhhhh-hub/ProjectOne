---
source_file: "Playbook notes - Updates and live ops.md"
type: "concept"
community: "Updates, events and release slot"
location: "L143"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# Update Announcements (60 chars, 1 per 3 days, reach under-13s)

## Connections
- [[Eventsupdates tools (announcements, events, thumbnail personalization, Configs)]] - `references` [INFERRED]
- [[Launch checklist for a solo kids' simulator (D-7 to launch)]] - `references` [EXTRACTED]
- [[Personalized Experience Notifications]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Updates_events_and_release_slot