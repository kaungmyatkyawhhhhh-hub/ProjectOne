---
source_file: "Playbook notes - Logos.md"
type: "concept"
community: "Money: DevEx and pricing"
location: "L63"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Money_DevEx_and_pricing
---

# Logo Commission Pricing (Robux)

## Connections
- [[DevEx Rate $0.0038 per Robux]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Money_DevEx_and_pricing