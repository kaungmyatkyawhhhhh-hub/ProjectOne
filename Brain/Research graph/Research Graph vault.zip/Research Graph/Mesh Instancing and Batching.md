---
source_file: "Playbook notes - Optimization deep dive.md"
type: "concept"
community: "Optimization and retention mechanics"
location: "L181"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# Mesh Instancing and Batching

## Connections
- [[MicroProfiler Tag Table]] - `references` [EXTRACTED]
- [[Prioritized Optimization Checklist]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Optimization_and_retention_mechanics