---
source_file: "Playbook notes - Discovery and marketing.md"
type: "concept"
community: "Discovery and ads"
location: "L307"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Discovery_and_ads
---

# Friend Invite Reward System

## Connections
- [[Recommended For You Algorithm]] - `conceptually_related_to` [EXTRACTED]
- [[Roblox Discovery and Marketing]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Discovery_and_ads