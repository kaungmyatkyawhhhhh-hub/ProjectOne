---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L25"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# TimeScale (particle hit-stop / slow-mo)

## Connections
- [[ParticleEmitter]] - `references` [EXTRACTED]
- [[Three-phase VFX timing (anticipation, impact, dissipation)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles