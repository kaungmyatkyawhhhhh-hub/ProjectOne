---
source_file: "Playbook notes - Updates and live ops.md"
type: "concept"
community: "Updates, events and release slot"
location: "L150"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# Personalized Experience Notifications

## Connections
- [[Experience Notifications rules]] - `semantically_similar_to` [INFERRED]
- [[Update Announcements (60 chars, 1 per 3 days, reach under-13s)]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Updates_events_and_release_slot