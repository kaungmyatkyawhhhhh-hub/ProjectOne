---
source_file: "Playbook notes - Optimization deep dive.md"
type: "concept"
community: "Optimization and retention mechanics"
location: "L24"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# Performance Dashboard

## Connections
- [[MicroProfiler]] - `conceptually_related_to` [EXTRACTED]
- [[Parallel Luau (Actors)]] - `references` [EXTRACTED]
- [[Server Memory Capacity (6.25 GiB + 100 MiB per player)]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Optimization_and_retention_mechanics