---
source_file: "2026-11-01 Research - Popular incremental HUD layouts.md"
type: "concept"
community: "Cutscenes and incremental HUDs"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Cutscenes_and_incremental_HUDs
---

# Astronomer star-chart UI motif

## Connections
- [[Avoiding the AI-made look]] - `implements` [EXTRACTED]
- [[Popular incremental HUD layouts]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Cutscenes_and_incremental_HUDs