---
source_file: "2026-11-06 Research - 20 trending Roblox games (videos watched).md"
type: "concept"
community: "Trending games and next game ideas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Trending_games_and_next_game_ideas
---

# obby but you get smaller every stage

## Connections
- [[+1 SHRINK]] - `conceptually_related_to` [EXTRACTED]
- [[20 trending Roblox games]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Trending_games_and_next_game_ideas