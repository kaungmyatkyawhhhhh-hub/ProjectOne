---
source_file: "2026-11-05 Research - Sols RNG 100M+ aura cutscenes (40 watched) + Immortality and Regrowth videos.md"
type: "document"
community: "Cutscenes and incremental HUDs"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Cutscenes_and_incremental_HUDs
---

# Sol's RNG aura cutscenes + Immortality and Regrowth

## Connections
- [[Five-beat aura cutscene structure]] - `references` [EXTRACTED]
- [[Gargantua aura]] - `references` [EXTRACTED]
- [[Regrowth Incremental]] - `references` [EXTRACTED]
- [[Screen-space cutscene template (per-item colour + symbol)]] - `references` [EXTRACTED]
- [[Sol's RNG]] - `references` [EXTRACTED]
- [[Stinger drop sync rule]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Cutscenes_and_incremental_HUDs