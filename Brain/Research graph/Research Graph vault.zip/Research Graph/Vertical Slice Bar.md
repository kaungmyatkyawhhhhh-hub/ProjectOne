---
source_file: "Playbook notes - Game quality and QA.md"
type: "rationale"
community: "Quality and polish"
location: "L59"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Quality_and_polish
---

# Vertical Slice Bar

## Connections
- [[Polish Checklist]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Quality_and_polish