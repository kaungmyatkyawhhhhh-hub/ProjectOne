---
source_file: "Playbook notes - Logos.md"
type: "concept"
community: "Logos, loading screen and GYM ARC art"
location: "L93"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Logos_loading_screen_and_GYM_ARC_art
---

# Thumbnail Spec and Logo Placement

## Connections
- [[Experience Icon Spec (512, shown ~150px)]] - `conceptually_related_to` [EXTRACTED]
- [[Thumbnail and Icon Click Rules]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Logos_loading_screen_and_GYM_ARC_art