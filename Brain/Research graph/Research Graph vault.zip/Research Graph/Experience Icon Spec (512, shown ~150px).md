---
source_file: "Playbook notes - Logos.md"
type: "concept"
community: "Logos, loading screen and GYM ARC art"
location: "L99"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Logos_loading_screen_and_GYM_ARC_art
---

# Experience Icon Spec (512, shown ~150px)

## Connections
- [[Roblox Game Logo Layer Recipe]] - `references` [EXTRACTED]
- [[Thumbnail Spec and Logo Placement]] - `conceptually_related_to` [EXTRACTED]
- [[Thumbnail and Icon Click Rules]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Logos_loading_screen_and_GYM_ARC_art