---
source_file: "2026-11-07 Video edit style - what makes an edit good (reference study).md"
type: "concept"
community: "Cutscenes and incremental HUDs"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Cutscenes_and_incremental_HUDs
---

# Galaxy TikTok v2 beat-sync edit

## Connections
- [[Beat-synced edit rules]] - `implements` [EXTRACTED]
- [[EarShot critique]] - `references` [EXTRACTED]
- [[Galaxy Incremental (was Supernova Incremental)]] - `conceptually_related_to` [EXTRACTED]
- [[Remotion]] - `references` [EXTRACTED]
- [[Video edit style - what makes an edit good]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Cutscenes_and_incremental_HUDs