---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L143"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# UI-layer VFX in top simulators

## Connections
- [[UIGradient shine (GUI Shine Module)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles