---
source_file: "Playbook notes - Lighting, cameras and cutscenes.md"
type: "rationale"
community: "Lighting and cameras"
location: "L133"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Lighting_and_cameras
---

# Thumbnail/Icon Photo-booth Capture

## Connections
- [[AI-generated Icon and Safe Imagery Rules]] - `conceptually_related_to` [INFERRED]
- [[Atmosphere and Post-processing Effects]] - `references` [EXTRACTED]
- [[Lighting, Cameras and Cutscenes for Roblox Simulators]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Lighting_and_cameras