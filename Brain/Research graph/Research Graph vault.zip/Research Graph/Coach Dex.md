---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "concept"
community: "Names, logos and IP safety"
location: "L358"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# Coach Dex

## Connections
- [[Dialogue Box Design for Kids on Phones]] - `references` [EXTRACTED]
- [[Gym Unlock Cutscene (GymReveal)]] - `references` [EXTRACTED]
- [[Never Ship AI Images Rule]] - `references` [EXTRACTED]
- [[ViewportFrame Portrait Recipe (Coach Dex)]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Names_logos_and_IP_safety