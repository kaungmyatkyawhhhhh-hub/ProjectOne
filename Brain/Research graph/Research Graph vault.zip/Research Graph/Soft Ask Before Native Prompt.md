---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "rationale"
community: "Logos, loading screen and GYM ARC art"
location: "L398"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Logos_loading_screen_and_GYM_ARC_art
---

# Soft Ask Before Native Prompt

## Connections
- [[GroupServicePromptJoinAsync]] - `references` [EXTRACTED]
- [[Like-Goal Code Board]] - `conceptually_related_to` [INFERRED]

#graphify/rationale #graphify/EXTRACTED #community/Logos_loading_screen_and_GYM_ARC_art