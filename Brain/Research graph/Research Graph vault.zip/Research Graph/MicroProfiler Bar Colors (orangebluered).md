---
source_file: "Playbook notes - Optimization deep dive.md"
type: "concept"
community: "Optimization and retention mechanics"
location: "L62"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# MicroProfiler Bar Colors (orange/blue/red)

## Connections
- [[MicroProfiler]] - `references` [EXTRACTED]
- [[Script Profiler]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Optimization_and_retention_mechanics