---
source_file: "Playbook notes - Performance, data and security.md"
type: "concept"
community: "Performance, data and security"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Performance_data_and_security
---

# Instance Streaming (Opportunistic stream-out)

## Connections
- [[Baseline Device Budget (1k draw calls  1M triangles)]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Performance, data and security]] - `references` [EXTRACTED]
- [[Server Authority (AuthorityMode=Server, beta)]] - `references` [EXTRACTED]
- [[Texture Memory Budget (=512 px)]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Performance_data_and_security