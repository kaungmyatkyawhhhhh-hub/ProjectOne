---
source_file: "Playbook notes - Sound and music.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Rarity Stinger Escalation Ladder

## Connections
- [[Juice (Juice it or lose it)]] - `semantically_similar_to` [INFERRED]
- [[Music Ducking Under Stingers]] - `references` [EXTRACTED]
- [[Playbook notes - Sound and music]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel