---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L18"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# ZOffset render-order layering

## Connections
- [[ParticleEmitter]] - `references` [EXTRACTED]
- [[VisuallyFX 'Introduction to VFX Particles' (DevForum)]] - `cites` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles