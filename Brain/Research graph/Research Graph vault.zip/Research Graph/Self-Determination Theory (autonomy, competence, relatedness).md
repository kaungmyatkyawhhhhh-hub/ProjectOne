---
source_file: "Playbook notes - Core loop design.md"
type: "concept"
community: "Core loop, incrementals and trends maths"
location: "L15"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Core_loop_incrementals_and_trends_maths
---

# Self-Determination Theory (autonomy, competence, relatedness)

## Connections
- [[Core Loop (Katkoff dual session loops)]] - `rationale_for` [EXTRACTED]
- [[Core Loop Design for Roblox Simulators and Casual Games]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Core_loop_incrementals_and_trends_maths