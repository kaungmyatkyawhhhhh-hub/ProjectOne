---
source_file: "Playbook notes - Policy, safety and community.md"
type: "concept"
community: "Policy, safety and kids rules"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Policy_safety_and_kids_rules
---

# Free-Form User Creation Restriction (16+)

## Connections
- [[Content Maturity Labels (MinimalMildModerateRestricted)]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Policy, safety and community]] - `references` [EXTRACTED]
- [[TextService FilterStringAsync Filtering]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Policy_safety_and_kids_rules