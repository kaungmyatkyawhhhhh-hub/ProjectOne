---
source_file: "Playbook notes - Monetization.md"
type: "concept"
community: "Money: DevEx and pricing"
location: "L11"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Money_DevEx_and_pricing
---

# Passes and Developer Products (70% share)

## Connections
- [[Developer Exchange (DevEx)]] - `shares_data_with` [INFERRED]
- [[Escrow Hold Conflict (30 days vs ~5 days)]] - `references` [EXTRACTED]
- [[Managed Pricing]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Money_DevEx_and_pricing