---
source_file: "2026-10-31 Atlas myth and trainer stories.md"
type: "concept"
community: "Atlas story"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Atlas_story
---

# AudioTextToSpeech (Roblox text to speech)

## Connections
- [[Atlas myth and trainer stories]] - `references` [EXTRACTED]
- [[TrainerStories narrator]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Atlas_story