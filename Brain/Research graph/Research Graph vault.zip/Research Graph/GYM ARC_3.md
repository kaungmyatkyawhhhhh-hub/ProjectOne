---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "concept"
community: "Logos, loading screen and GYM ARC art"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Logos_loading_screen_and_GYM_ARC_art
---

# GYM ARC

## Connections
- [[Gym League_2]] - `conceptually_related_to` [EXTRACTED]
- [[Gym Star Simulator_1]] - `conceptually_related_to` [EXTRACTED]
- [[Muscle Legends_1]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Loading, auras, trainers, retention (29 Oct 2026)]] - `references` [EXTRACTED]
- [[Roblox Retention Benchmarks (GameAnalytics D1D7D30)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Logos_loading_screen_and_GYM_ARC_art