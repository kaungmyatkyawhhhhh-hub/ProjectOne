---
source_file: "Playbook notes - Onboarding, retention and live ops.md"
type: "concept"
community: "Names, logos and IP safety"
location: "L163"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# Roblox Party

## Connections
- [[Co-play Sessions 1.9x Longer]] - `rationale_for` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Names_logos_and_IP_safety