---
source_file: "Playbook notes - Analytics and experiments.md"
type: "concept"
community: "Analytics events"
location: "L34"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Analytics_events
---

# AnalyticsService API

## Connections
- [[Analytics and Experimentation for Roblox Experiences]] - `references` [EXTRACTED]
- [[Economy SourceSink Events]] - `conceptually_related_to` [EXTRACTED]
- [[GameAnalytics Roblox SDK]] - `semantically_similar_to` [INFERRED]
- [[Onboarding Funnel Events]] - `implements` [EXTRACTED]
- [[Server Analytics Wrapper Module]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Analytics_events