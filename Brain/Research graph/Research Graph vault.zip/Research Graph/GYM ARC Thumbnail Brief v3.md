---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "rationale"
community: "Logos, loading screen and GYM ARC art"
location: "L755"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Logos_loading_screen_and_GYM_ARC_art
---

# GYM ARC Thumbnail Brief v3

## Connections
- [[Blender GFX Thumbnail Workflow (Thumbnail F)]] - `implements` [EXTRACTED]
- [[Gym Star Simulator_1]] - `references` [EXTRACTED]
- [[Thumbnail AB Testing]] - `references` [EXTRACTED]
- [[Thumbnail and Icon Click Rules]] - `rationale_for` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Logos_loading_screen_and_GYM_ARC_art