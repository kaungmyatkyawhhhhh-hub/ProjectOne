---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L119"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# Rarity reveal / egg hatch recipe

## Connections
- [[Rarity colour readability (paired with shapesize)]] - `references` [INFERRED]
- [[UIGradient shine (GUI Shine Module)]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles