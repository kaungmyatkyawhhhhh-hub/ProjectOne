---
source_file: "Playbook notes - Onboarding, retention and live ops.md"
type: "concept"
community: "Logos, loading screen and GYM ARC art"
location: "L18"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Logos_loading_screen_and_GYM_ARC_art
---

# BLOXG Genre Retention Benchmarks

## Connections
- [[Roblox Analytics Benchmark Scorecards]] - `conceptually_related_to` [EXTRACTED]
- [[Roblox Retention Benchmarks (GameAnalytics D1D7D30)]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Logos_loading_screen_and_GYM_ARC_art