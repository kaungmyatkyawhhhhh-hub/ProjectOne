---
source_file: "2026-11-06 PLAN - Trend research applied to Galaxy Incremental and +1 SHRINK.md"
type: "concept"
community: "Trending games and next game ideas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Trending_games_and_next_game_ideas
---

# +1 SHRINK

## Connections
- [[+1 Depth Incremental]] - `conceptually_related_to` [EXTRACTED]
- [[Boss - key - rebirth room]] - `implements` [EXTRACTED]
- [[Bug Evolution]] - `conceptually_related_to` [EXTRACTED]
- [[MONSTER GROW concept]] - `conceptually_related_to` [EXTRACTED]
- [[PLAN - Trend research applied to Galaxy Incremental and +1 SHRINK]] - `references` [EXTRACTED]
- [[Why Depth Incremental is addicting]] - `conceptually_related_to` [EXTRACTED]
- [[obby but you get smaller every stage]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Trending_games_and_next_game_ideas