---
source_file: "Playbook notes - Monetization.md"
type: "paper"
community: "Optimization and retention mechanics"
location: "L151"
tags:
  - graphify/paper
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# University of Sydney Study on Deceptive Purchase Design

## Connections
- [[Discount Honesty Rules (no fake sales or resetting timers)]] - `conceptually_related_to` [INFERRED]
- [[Shop UX and Calm Wording for Minors]] - `rationale_for` [EXTRACTED]

#graphify/paper #graphify/EXTRACTED #community/Optimization_and_retention_mechanics