---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "Mobile UI layout"
location: "L52"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Mobile_UI_layout
---

# Mobile UI layout rules

#graphify/concept #graphify/EXTRACTED #community/Mobile_UI_layout