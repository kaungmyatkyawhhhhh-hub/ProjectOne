---
source_file: "Playbook notes - Names and descriptions.md"
type: "concept"
community: "Names, logos and IP safety"
location: "L16"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# Title Truncation (~15 characters)

## Connections
- [[Hybrid Name Formula (Brand Word + Genre Keyword)]] - `references` [EXTRACTED]
- [[Name-Checking Checklist]] - `references` [EXTRACTED]
- [[Title Decorations (bracketed emoji prefix)]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Names_logos_and_IP_safety