---
source_file: "2026-11-01 Research - Modeling like a professional (stylized low poly).md"
type: "concept"
community: "Trending games and next game ideas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Trending_games_and_next_game_ideas
---

# Blender Python model pipeline (vertex colours, .fbx)

## Connections
- [[GYM ARC]] - `conceptually_related_to` [EXTRACTED]
- [[Modeling like a professional (stylized low poly)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Trending_games_and_next_game_ideas