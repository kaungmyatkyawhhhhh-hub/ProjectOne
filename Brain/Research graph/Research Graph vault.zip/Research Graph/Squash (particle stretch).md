---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L19"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/VFX_and_particles
---

# Squash (particle stretch)

## Connections
- [[ParticleEmitter]] - `references` [EXTRACTED]
- [[Three-phase VFX timing (anticipation, impact, dissipation)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/VFX_and_particles