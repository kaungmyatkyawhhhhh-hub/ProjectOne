---
source_file: "2026-11-05 PLAYBOOK - Roblox icon, thumbnail and logo recipe.md"
type: "concept"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# Roblox icon, thumbnail and logo recipe

## Connections
- [[Bright white face rule]] - `rationale_for` [EXTRACTED]
- [[ChatGPT final-art pipeline (real render + one style ref + logo)]] - `references` [EXTRACTED]
- [[Icon contrast test (10-15% white, 40-50% black at 64 px)]] - `rationale_for` [EXTRACTED]
- [[One-try ChatGPT prompt templates]] - `references` [EXTRACTED]
- [[Owner click patterns (one hero, emotion, one glow, one number)]] - `conceptually_related_to` [INFERRED]
- [[PLAYBOOK - Roblox icon, thumbnail and logo recipe]] - `references` [EXTRACTED]
- [[Roblox GFX logo style]] - `conceptually_related_to` [INFERRED]
- [[Thumbnail Personalization]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks