---
source_file: "Playbook notes - Thumbnails.md"
type: "document"
community: "Thumbnail art study and testing"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Thumbnail_art_study_and_testing
---

# Playbook notes - Thumbnails

## Connections
- [[AI-Looking Thumbnail Signals]] - `references` [EXTRACTED]
- [[Clickbait and Honesty Rules]] - `references` [EXTRACTED]
- [[Custom Thumbnail Required for Home (Oct 2026)]] - `references` [EXTRACTED]
- [[Gameplay Video Previews]] - `references` [EXTRACTED]
- [[Include Existing Winner in New Tests]] - `references` [EXTRACTED]
- [[PTR  qPTR Ranking Signals]] - `references` [EXTRACTED]
- [[Playbook notes - Top games art study (Oct 2026)]] - `references` [EXTRACTED]
- [[Simulator Thumbnail Composition (hero + payoff)]] - `references` [EXTRACTED]
- [[Standout Games Home Shelf]] - `references` [EXTRACTED]
- [[Thumbnail Personalization (multi-armed bandit)]] - `references` [EXTRACTED]
- [[Thumbnail Specs (169 1920x1080, 3 MB)]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Thumbnail_art_study_and_testing