---
source_file: "Playbook notes - UI deep dive.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Placeholder-Look Mistakes

## Connections
- [[Playbook notes - UI deep dive]] - `references` [EXTRACTED]
- [[Polished UI Kit]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel