---
source_file: "2026-11-05 PLAYBOOK - Roblox icon, thumbnail and logo recipe.md"
type: "concept"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# Icon contrast test (10-15% white, 40-50% black at 64 px)

## Connections
- [[PLAYBOOK - Roblox icon, thumbnail and logo recipe]] - `references` [EXTRACTED]
- [[Roblox icon, thumbnail and logo recipe]] - `rationale_for` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks