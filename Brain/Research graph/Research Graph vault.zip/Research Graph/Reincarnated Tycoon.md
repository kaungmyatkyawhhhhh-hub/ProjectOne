---
source_file: "2026-11-04 Reincarnated Tycoon - next game check.md"
type: "concept"
community: "Trending games and next game ideas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Trending_games_and_next_game_ideas
---

# Reincarnated [Tycoon]

## Connections
- [[Galaxy Incremental (was Supernova Incremental)]] - `conceptually_related_to` [EXTRACTED]
- [[Miner's Haven]] - `conceptually_related_to` [EXTRACTED]
- [[Reincarnated Tycoon - next game check]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Trending_games_and_next_game_ideas