---
source_file: "Playbook notes - Logos.md"
type: "concept"
community: "Logos, loading screen and GYM ARC art"
location: "L114"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Logos_loading_screen_and_GYM_ARC_art
---

# Roblox Community (Group) Emblem and Banner

## Connections
- [[GroupServicePromptJoinAsync]] - `conceptually_related_to` [INFERRED]
- [[Roblox Game Logo Layer Recipe]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Logos_loading_screen_and_GYM_ARC_art