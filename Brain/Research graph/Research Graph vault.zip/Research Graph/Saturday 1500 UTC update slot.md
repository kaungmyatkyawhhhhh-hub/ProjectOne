---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "Seasonal calendar"
location: "L65"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/Seasonal_calendar
---

# Saturday 15:00 UTC update slot

## Connections
- [[GYM ARC_2]] - `references` [INFERRED]
- [[GYM ARC Saturday 1500 UTC release rule]] - `semantically_similar_to` [INFERRED]
- [[Holiday calendar 2026-27]] - `references` [EXTRACTED]

#graphify/concept #graphify/INFERRED #community/Seasonal_calendar