---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "concept"
community: "Logos, loading screen and GYM ARC art"
location: "L611"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Logos_loading_screen_and_GYM_ARC_art
---

# Gym Star Simulator

## Connections
- [[GYM ARC_3]] - `conceptually_related_to` [EXTRACTED]
- [[GYM ARC Thumbnail Brief v3]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Logos_loading_screen_and_GYM_ARC_art