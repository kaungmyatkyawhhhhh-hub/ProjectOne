---
type: community
cohesion: 0.08
members: 27
---

# Logos, loading screen and GYM ARC art

**Cohesion:** 0.08 - loosely connected
**Members:** 27 nodes

## Members
- [[3D Extrusion Body and Bevel Technique]] - concept - Playbook notes - Logos.md
- [[BLOXG Genre Retention Benchmarks]] - concept - Playbook notes - Onboarding, retention and live ops.md
- [[ContentProviderPreloadAsync]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[ContentProviderPreloadAsync_1]] - concept - Playbook notes - Optimization deep dive.md
- [[DevForum Basics of Game Logo Design Tutorial]] - document - Playbook notes - Logos.md
- [[Experience Icon Spec (512, shown ~150px)]] - concept - Playbook notes - Logos.md
- [[GYM ARC_3]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[GYM ARC Thumbnail Brief v3]] - rationale - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[GroupServicePromptJoinAsync]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Gym League_2]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Gym Star Simulator_1]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Hue-Shift Shading]] - concept - Playbook notes - Logos.md
- [[Like-Goal Code Board]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Loading Screen Design (GYM ARC)]] - rationale - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Logo on Main Menu and Loading Screen]] - concept - Playbook notes - Logos.md
- [[Muscle Legends_1]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Perceived Wait Time  Progress Bar Psychology]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Playbook notes - Loading, auras, trainers, retention (29 Oct 2026)]] - document - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[ReplicatedFirst Loading Script]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Roblox Analytics Benchmark Scorecards]] - concept - Playbook notes - Onboarding, retention and live ops.md
- [[Roblox Community (Group) Emblem and Banner]] - concept - Playbook notes - Logos.md
- [[Roblox Game Logo Layer Recipe]] - rationale - Playbook notes - Logos.md
- [[Roblox Retention Benchmarks (GameAnalytics D1D7D30)]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Soft Ask Before Native Prompt]] - rationale - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Thumbnail AB Testing]] - concept - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md
- [[Thumbnail Spec and Logo Placement]] - concept - Playbook notes - Logos.md
- [[Thumbnail and Icon Click Rules]] - rationale - Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Logos_loading_screen_and_GYM_ARC_art
SORT file.name ASC
```

## Connections to other communities
- 1 edge to [[_COMMUNITY_Names, logos and IP safety]]
- 1 edge to [[_COMMUNITY_Optimization and retention mechanics]]

## Top bridge nodes
- [[GYM ARC Thumbnail Brief v3]] - degree 4, connects to 1 community
- [[ContentProviderPreloadAsync_1]] - degree 2, connects to 1 community