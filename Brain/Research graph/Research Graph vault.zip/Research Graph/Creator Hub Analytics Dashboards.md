---
source_file: "Playbook notes - Analytics and experiments.md"
type: "concept"
community: "Analytics events"
location: "L5"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Analytics_events
---

# Creator Hub Analytics Dashboards

## Connections
- [[Analytics and Experimentation for Roblox Experiences]] - `references` [EXTRACTED]
- [[Similar-game Benchmarks]] - `references` [EXTRACTED]
- [[Weekly Analytics Routine]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Analytics_events