---
source_file: "Playbook notes - Updates and live ops.md"
type: "concept"
community: "Seasonal calendar"
location: "L262"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Seasonal_calendar
---

# The Hunt: Mega Edition platform event

## Connections
- [[ROLearn seasonal trends & launch timing]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Seasonal_calendar