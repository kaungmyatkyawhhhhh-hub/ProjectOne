---
source_file: "Playbook notes - Thumbnails.md"
type: "concept"
community: "Thumbnail art study and testing"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Thumbnail_art_study_and_testing
---

# Thumbnail Personalization (multi-armed bandit)

## Connections
- [[IconThumbnail Upload Checklist]] - `references` [EXTRACTED]
- [[Include Existing Winner in New Tests]] - `implements` [EXTRACTED]
- [[PTR  qPTR Ranking Signals]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Thumbnails]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Thumbnail_art_study_and_testing