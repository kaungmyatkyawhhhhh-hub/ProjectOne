---
source_file: "Playbook notes - Sound and music.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Music Ducking Under Stingers

## Connections
- [[AudioFader Mixer Buses]] - `references` [EXTRACTED]
- [[Playbook notes - Sound and music]] - `references` [EXTRACTED]
- [[Rarity Stinger Escalation Ladder]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel