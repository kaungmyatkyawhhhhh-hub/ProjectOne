---
source_file: "Playbook notes - Onboarding, retention and live ops.md"
type: "concept"
community: "Weekly updates and trainer collection"
location: "L113"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Weekly_updates_and_trainer_collection
---

# Paid Random Items Policy

## Connections
- [[Paid Random Items Policy_1]] - `semantically_similar_to` [INFERRED]
- [[Safe Kids' Simulator Retention Stack]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Weekly_updates_and_trainer_collection