---
type: community
cohesion: 1.00
members: 1
---

# Names and descriptions (doc)

**Cohesion:** 1.00 - tightly connected
**Members:** 1 nodes

## Members
- [[Playbook notes - Names and descriptions]] - document - Playbook notes - Names and descriptions.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Names_and_descriptions_doc
SORT file.name ASC
```
