---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "paper"
community: "Seasonal calendar"
location: "L24"
tags:
  - graphify/paper
  - graphify/EXTRACTED
  - community/Seasonal_calendar
---

# GameAnalytics 2026 Roblox retention benchmarks

## Connections
- [[GYM ARC_2]] - `references` [EXTRACTED]

#graphify/paper #graphify/EXTRACTED #community/Seasonal_calendar