---
type: community
cohesion: 1.00
members: 1
---

# Sound design basics

**Cohesion:** 1.00 - tightly connected
**Members:** 1 nodes

## Members
- [[Sound design (pitch combos, loudness, ducking)]] - concept - Playbook notes - Whole-game research (Oct 2026).md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/Sound_design_basics
SORT file.name ASC
```
