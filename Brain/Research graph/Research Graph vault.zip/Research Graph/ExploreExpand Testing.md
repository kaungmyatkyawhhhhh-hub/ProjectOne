---
source_file: "Playbook notes - Discovery and marketing.md"
type: "concept"
community: "Discovery and ads"
location: "L46"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Discovery_and_ads
---

# Explore/Expand Testing

## Connections
- [[Ads Manager  Sponsored Ads]] - `conceptually_related_to` [EXTRACTED]
- [[Recommended For You Algorithm]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Discovery_and_ads