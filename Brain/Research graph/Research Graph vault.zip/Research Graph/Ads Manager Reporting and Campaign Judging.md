---
source_file: "Playbook notes - Analytics in practice.md"
type: "concept"
community: "Discovery and ads"
location: "L319"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Discovery_and_ads
---

# Ads Manager Reporting and Campaign Judging

## Connections
- [[Ads Manager  Sponsored Ads]] - `semantically_similar_to` [INFERRED]
- [[Practical Roblox Analytics Instrumentation and Diagnosis]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Discovery_and_ads