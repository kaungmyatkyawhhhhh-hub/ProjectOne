---
source_file: "Playbook notes - Optimization deep dive.md"
type: "concept"
community: "Optimization and retention mechanics"
location: "L81"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# MicroProfiler Tag Table

## Connections
- [[Lighting.LightingStyle and Local Light Cost]] - `references` [EXTRACTED]
- [[Mesh Instancing and Batching]] - `references` [EXTRACTED]
- [[MicroProfiler]] - `references` [EXTRACTED]
- [[Particle and Effect Cost]] - `references` [EXTRACTED]
- [[SurfaceGui  BillboardGui Render Cost]] - `references` [EXTRACTED]
- [[UnreliableRemoteEvent]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Optimization_and_retention_mechanics