---
source_file: "Playbook notes - UI deep dive.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Chunky Kids' Simulator Button Recipe

## Connections
- [[FontFace  Font Datatype]] - `references` [EXTRACTED]
- [[Four Button States]] - `conceptually_related_to` [INFERRED]
- [[Playbook notes - UI deep dive]] - `references` [EXTRACTED]
- [[Polished UI Kit]] - `semantically_similar_to` [INFERRED]
- [[UICorner]] - `references` [EXTRACTED]
- [[UIGradient (radialconical beta)]] - `references` [EXTRACTED]
- [[UIStroke]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel