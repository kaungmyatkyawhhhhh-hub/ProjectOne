---
source_file: "2026-11-01 Research - Do cutscenes help, what makes a good one.md"
type: "rationale"
community: "Cutscenes and incremental HUDs"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Cutscenes_and_incremental_HUDs
---

# Good cutscene checklist (earned, short, skippable, opens a question)

## Connections
- [[Curiosity drives playtime (CHI 2024 study)]] - `rationale_for` [EXTRACTED]
- [[Do cutscenes help, what makes a good one]] - `references` [EXTRACTED]
- [[Drop-off happens in the first 90 seconds]] - `rationale_for` [EXTRACTED]
- [[Screen-space cutscene template (per-item colour + symbol)]] - `conceptually_related_to` [EXTRACTED]
- [[Supernova cutscene (5 s first, 2 s repeats)]] - `implements` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Cutscenes_and_incremental_HUDs