---
source_file: "Playbook notes - Onboarding, retention and live ops.md"
type: "concept"
community: "Names, logos and IP safety"
location: "L164"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Names_logos_and_IP_safety
---

# Friend Referral System

## Connections
- [[Co-play Sessions 1.9x Longer]] - `rationale_for` [EXTRACTED]
- [[Creator Rewards 10-Minute Threshold]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Names_logos_and_IP_safety