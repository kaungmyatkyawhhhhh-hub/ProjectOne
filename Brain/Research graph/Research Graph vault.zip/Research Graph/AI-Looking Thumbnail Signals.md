---
source_file: "Playbook notes - Thumbnails.md"
type: "concept"
community: "Thumbnail art study and testing"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Thumbnail_art_study_and_testing
---

# AI-Looking Thumbnail Signals

## Connections
- [[Playbook notes - Thumbnails]] - `references` [EXTRACTED]
- [[Simulator Thumbnail Composition (hero + payoff)]] - `rationale_for` [EXTRACTED]
- [[Slop vs Premium Art Criteria]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/Thumbnail_art_study_and_testing