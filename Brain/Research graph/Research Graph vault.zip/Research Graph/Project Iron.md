---
source_file: "2026-11-05 Research - What the owner clicks on Roblox (10 min watch).md"
type: "concept"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# Project: Iron

## Connections
- [[Owner click patterns (one hero, emotion, one glow, one number)]] - `references` [EXTRACTED]
- [[What the owner clicks on Roblox]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks