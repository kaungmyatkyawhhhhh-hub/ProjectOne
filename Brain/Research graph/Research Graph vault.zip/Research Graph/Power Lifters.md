---
source_file: "2026-11-03 Research - Gym, simulator and evolution thumbnails (owner screenshots).md"
type: "concept"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# Power Lifters

## Connections
- [[Concept ours, style borrowed rule]] - `references` [EXTRACTED]
- [[Gym, simulator and evolution thumbnails]] - `references` [EXTRACTED]
- [[Gymsimulator thumbnail rules (one hero, bright bg, progress numbers)]] - `references` [EXTRACTED]
- [[Owner click patterns (one hero, emotion, one glow, one number)]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks