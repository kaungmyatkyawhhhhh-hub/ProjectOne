---
source_file: "2026-11-03 Research - High CTR Roblox thumbnails.md"
type: "document"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# High CTR Roblox thumbnails

## Connections
- [[High-CTR thumbnail design rules]] - `references` [EXTRACTED]
- [[Icon and thumbnail testing]] - `cites` [EXTRACTED]
- [[Search shows first 169 gallery image (since 16 Mar 2026)]] - `references` [EXTRACTED]
- [[What the owner clicks on Roblox]] - `cites` [EXTRACTED]
- [[qPTR funnel (impression CTR x details CTR x 5-min play)]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks