---
source_file: "2026-11-06 PLAN - Trend research applied to Galaxy Incremental and +1 SHRINK.md"
type: "concept"
community: "Trending games and next game ideas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Trending_games_and_next_game_ideas
---

# Galaxy Incremental (was Supernova Incremental)

## Connections
- [[+1 Depth Incremental]] - `conceptually_related_to` [EXTRACTED]
- [[7 shared incremental HUD rules]] - `conceptually_related_to` [EXTRACTED]
- [[Galaxy TikTok v2 beat-sync edit]] - `conceptually_related_to` [EXTRACTED]
- [[Galaxy distance how far bar]] - `implements` [EXTRACTED]
- [[Monthly free party event]] - `conceptually_related_to` [EXTRACTED]
- [[PLAN - Trend research applied to Galaxy Incremental and +1 SHRINK]] - `references` [EXTRACTED]
- [[Reincarnated Tycoon]] - `conceptually_related_to` [EXTRACTED]
- [[Retention kit (offline earnings, daily rewards, quests, codes, events)]] - `conceptually_related_to` [EXTRACTED]
- [[Screen-space cutscene template (per-item colour + symbol)]] - `conceptually_related_to` [EXTRACTED]
- [[Sol's-RNG style rare reveal]] - `conceptually_related_to` [EXTRACTED]
- [[Supernova cutscene (5 s first, 2 s repeats)]] - `conceptually_related_to` [EXTRACTED]
- [[Supernova kit style guide (round + brass, faceted crystals)]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Trending_games_and_next_game_ideas