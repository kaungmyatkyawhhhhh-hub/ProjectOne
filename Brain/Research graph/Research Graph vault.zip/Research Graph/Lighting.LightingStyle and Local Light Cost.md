---
source_file: "Playbook notes - Optimization deep dive.md"
type: "concept"
community: "Optimization and retention mechanics"
location: "L194"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# Lighting.LightingStyle and Local Light Cost

## Connections
- [[GYM ARC Aura Tier Recipe]] - `conceptually_related_to` [INFERRED]
- [[MicroProfiler Tag Table]] - `references` [EXTRACTED]
- [[Prioritized Optimization Checklist]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Optimization_and_retention_mechanics