---
source_file: "Playbook notes - Logos.md"
type: "document"
community: "Logos, loading screen and GYM ARC art"
location: "L11"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Logos_loading_screen_and_GYM_ARC_art
---

# DevForum Basics of Game Logo Design Tutorial

## Connections
- [[3D Extrusion Body and Bevel Technique]] - `cites` [EXTRACTED]
- [[Roblox Game Logo Layer Recipe]] - `cites` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Logos_loading_screen_and_GYM_ARC_art