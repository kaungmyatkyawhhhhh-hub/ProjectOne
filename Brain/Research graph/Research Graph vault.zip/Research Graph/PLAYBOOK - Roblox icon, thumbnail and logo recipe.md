---
source_file: "2026-11-05 PLAYBOOK - Roblox icon, thumbnail and logo recipe.md"
type: "document"
community: "Icons, thumbnails and owner clicks"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Icons_thumbnails_and_owner_clicks
---

# PLAYBOOK - Roblox icon, thumbnail and logo recipe

## Connections
- [[Bright white face rule]] - `references` [EXTRACTED]
- [[ChatGPT final-art pipeline (real render + one style ref + logo)]] - `references` [EXTRACTED]
- [[Icon contrast test (10-15% white, 40-50% black at 64 px)]] - `references` [EXTRACTED]
- [[One-try ChatGPT prompt templates]] - `references` [EXTRACTED]
- [[Original muscle titan monster (not Venom)]] - `references` [EXTRACTED]
- [[Roblox GFX logo style_1]] - `cites` [EXTRACTED]
- [[Roblox icon, thumbnail and logo recipe]] - `references` [EXTRACTED]
- [[Thumbnail style references (12 top games)]] - `cites` [EXTRACTED]
- [[What the owner clicks on Roblox]] - `cites` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Icons_thumbnails_and_owner_clicks