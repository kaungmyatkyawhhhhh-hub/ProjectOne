---
source_file: "Playbook notes - Thumbnails.md"
type: "rationale"
community: "Thumbnail art study and testing"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Thumbnail_art_study_and_testing
---

# Include Existing Winner in New Tests

## Connections
- [[Fixed Thumbnail Template]] - `conceptually_related_to` [INFERRED]
- [[Playbook notes - Thumbnails]] - `references` [EXTRACTED]
- [[Thumbnail Personalization (multi-armed bandit)]] - `implements` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Thumbnail_art_study_and_testing