---
source_file: "Playbook notes - UI deep dive.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# Sprite Sheet Icon Atlas

## Connections
- [[Playbook notes - UI deep dive]] - `references` [EXTRACTED]
- [[Texture Memory Budget (=512 px)]] - `semantically_similar_to` [INFERRED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel