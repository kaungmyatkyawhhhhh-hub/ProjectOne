---
source_file: "Playbook notes - Updates and live ops.md"
type: "rationale"
community: "Updates, events and release slot"
location: "L294"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# GYM ARC Saturday 15:00 UTC release rule

## Connections
- [[99 Nights in the Forest weekly update]] - `references` [EXTRACTED]
- [[Admin abuse events]] - `references` [EXTRACTED]
- [[Grow a Garden weekly updates and 2-week events]] - `references` [EXTRACTED]
- [[Launch checklist for a solo kids' simulator (D-7 to launch)]] - `conceptually_related_to` [INFERRED]
- [[Pet Simulator 99 Saturday Update]] - `references` [EXTRACTED]
- [[Saturday 1500 UTC update slot]] - `semantically_similar_to` [INFERRED]
- [[Steal a Brainrot Saturday update]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Updates_events_and_release_slot