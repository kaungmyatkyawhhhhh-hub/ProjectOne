---
source_file: "Playbook notes - Performance, data and security.md"
type: "rationale"
community: "Performance, data and security"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Performance_data_and_security
---

# Server-Authoritative Remote Validation

## Connections
- [[Grant Developer Products Only in ProcessReceipt]] - `conceptually_related_to` [INFERRED]
- [[NaNinf Rejection with math.isfinite]] - `implements` [EXTRACTED]
- [[Playbook notes - Performance, data and security]] - `references` [EXTRACTED]
- [[Server Authority (AuthorityMode=Server, beta)]] - `conceptually_related_to` [EXTRACTED]
- [[Token-Bucket Rate Limiting]] - `implements` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Performance_data_and_security