---
source_file: "Playbook notes - Lighting, cameras and cutscenes.md"
type: "concept"
community: "Lighting and cameras"
location: "L88"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Lighting_and_cameras
---

# CineCam v3 Plugin

## Connections
- [[Cutscene Building Methods]] - `implements` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Lighting_and_cameras