---
source_file: "Playbook notes - Loading, auras, trainers, retention (29 Oct 2026).md"
type: "document"
community: "Logos, loading screen and GYM ARC art"
tags:
  - graphify/document
  - graphify/EXTRACTED
  - community/Logos_loading_screen_and_GYM_ARC_art
---

# Playbook notes - Loading, auras, trainers, retention (29 Oct 2026)

## Connections
- [[GYM ARC_3]] - `references` [EXTRACTED]

#graphify/document #graphify/EXTRACTED #community/Logos_loading_screen_and_GYM_ARC_art