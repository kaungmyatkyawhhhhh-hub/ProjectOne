---
type: community
cohesion: 0.05
members: 42
---

# VFX and particles

**Cohesion:** 0.05 - loosely connected
**Members:** 42 nodes

## Members
- [[Accessibility settings (ReducedMotion, PreferredTextSize, PreferredTransparency)]] - concept - Playbook notes - Whole-game research (Oct 2026).md
- [[Aura recipe]] - concept - Playbook notes - Visual effects.md
- [[Beam]] - concept - Playbook notes - Visual effects.md
- [[Camera shake, FOV punch and hit-stop]] - concept - Playbook notes - Visual effects.md
- [[Cheap-phone particle budget (~300 alive on screen)]] - rationale - Playbook notes - Visual effects.md
- [[Coin burst recipe]] - concept - Playbook notes - Visual effects.md
- [[Drag and WindAffectsDrag]] - concept - Playbook notes - Visual effects.md
- [[Emit(n) burst on disabled emitter]] - concept - Playbook notes - Visual effects.md
- [[Emitter pooling on Attachments]] - concept - Playbook notes - Visual effects.md
- [[Flash limit ~3 per second (photosensitivity)]] - concept - Playbook notes - Visual effects.md
- [[Game juice (Jonasson & Purho; Nijman)]] - concept - Playbook notes - Whole-game research (Oct 2026).md
- [[Grayscale textures tinted in-engine]] - concept - Playbook notes - Visual effects.md
- [[GuiService.ReducedMotionEnabled]] - concept - Playbook notes - Visual effects.md
- [[Highlight (255 limit, first costs ~1 ms GPU on mobile)]] - concept - Playbook notes - Visual effects.md
- [[Level-up recipe]] - concept - Playbook notes - Visual effects.md
- [[LightEmission (additive blending)]] - concept - Playbook notes - Visual effects.md
- [[LightInfluence default gotcha (Studio 1 vs Instance.new 0)]] - concept - Playbook notes - Visual effects.md
- [[Lighting.Technology superseded by LightingStyle + PrioritizeLightingQuality]] - concept - Playbook notes - Visual effects.md
- [[LightingStyle + PrioritizeLightingQuality]] - concept - Playbook notes - Whole-game research (Oct 2026).md
- [[Overdraw  fill-rate cost of transparent particles]] - concept - Playbook notes - Visual effects.md
- [[Particle flipbooks (Grid layouts, max 30 fps, auto-off on low memory)]] - concept - Playbook notes - Visual effects.md
- [[Particle limits (100s mobile, 20 s lifetime, flipbooks 30 fps)]] - concept - Playbook notes - Whole-game research (Oct 2026).md
- [[Particle rate limit (400s per emitter, 100 on mobile)]] - concept - Playbook notes - Visual effects.md
- [[ParticleEmitter]] - concept - Playbook notes - Visual effects.md
- [[ParticleOrientation modes]] - concept - Playbook notes - Visual effects.md
- [[Photosensitivity limit (WCAG 2.3.1)]] - concept - Playbook notes - Whole-game research (Oct 2026).md
- [[Playbook notes Roblox VFX for kids' simulators on cheap phones]] - document - Playbook notes - Visual effects.md
- [[Post-processing effects (Bloom, ColorCorrection, ColorGrading)]] - concept - Playbook notes - Visual effects.md
- [[Quality scaling via UserGameSettings.SavedQualityLevel]] - concept - Playbook notes - Visual effects.md
- [[Rarity colour ladder (grey to gold + Mythic)]] - concept - Playbook notes - Whole-game research (Oct 2026).md
- [[Rarity colour readability (paired with shapesize)]] - concept - Playbook notes - Visual effects.md
- [[Rarity reveal  egg hatch recipe]] - concept - Playbook notes - Visual effects.md
- [[Roblox 'Intro to VFX art' curriculum]] - paper - Playbook notes - Visual effects.md
- [[Squash (particle stretch)]] - concept - Playbook notes - Visual effects.md
- [[Texture memory by pixel count (512256 guidance)]] - concept - Playbook notes - Visual effects.md
- [[Three-phase VFX timing (anticipation, impact, dissipation)]] - concept - Playbook notes - Visual effects.md
- [[TimeScale (particle hit-stop  slow-mo)]] - concept - Playbook notes - Visual effects.md
- [[UI-layer VFX in top simulators]] - concept - Playbook notes - Visual effects.md
- [[UIGradient shine (GUI Shine Module)]] - concept - Playbook notes - Visual effects.md
- [[ViewportFrame VFX limitations]] - concept - Playbook notes - Visual effects.md
- [[VisuallyFX 'Introduction to VFX Particles' (DevForum)]] - paper - Playbook notes - Visual effects.md
- [[ZOffset render-order layering]] - concept - Playbook notes - Visual effects.md

## Live Query (requires Dataview plugin)

```dataview
TABLE source_file, type FROM #community/VFX_and_particles
SORT file.name ASC
```
