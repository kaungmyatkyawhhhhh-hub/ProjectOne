---
source_file: "Playbook notes - Policy, safety and community.md"
type: "concept"
community: "Policy, safety and kids rules"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Policy_safety_and_kids_rules
---

# Social Hangout Age Restriction

## Connections
- [[Content Maturity Labels (MinimalMildModerateRestricted)]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - Policy, safety and community]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Policy_safety_and_kids_rules