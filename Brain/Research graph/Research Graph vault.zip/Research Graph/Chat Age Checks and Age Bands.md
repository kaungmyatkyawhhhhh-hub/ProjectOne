---
source_file: "Playbook notes - Policy, safety and community.md"
type: "concept"
community: "Policy, safety and kids rules"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Policy_safety_and_kids_rules
---

# Chat Age Checks and Age Bands

## Connections
- [[Experience Notifications]] - `conceptually_related_to` [INFERRED]
- [[Playbook notes - Policy, safety and community]] - `references` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Policy_safety_and_kids_rules