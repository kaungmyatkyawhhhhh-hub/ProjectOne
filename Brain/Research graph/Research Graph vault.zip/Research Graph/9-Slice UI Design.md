---
source_file: "Playbook notes - UI, game feel, art and sound.md"
type: "concept"
community: "UI, sound and game feel"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/UI_sound_and_game_feel
---

# 9-Slice UI Design

## Connections
- [[Automatic Translation (18 languages)]] - `conceptually_related_to` [EXTRACTED]
- [[Playbook notes - UI, game feel, art and sound]] - `references` [EXTRACTED]
- [[Polished UI Kit]] - `references` [EXTRACTED]
- [[SliceScale Formula]] - `conceptually_related_to` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/UI_sound_and_game_feel