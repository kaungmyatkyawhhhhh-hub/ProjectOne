---
source_file: "Playbook notes - Visual effects.md"
type: "concept"
community: "VFX and particles"
location: "L77"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/VFX_and_particles
---

# Particle rate limit (400/s per emitter, 100 on mobile)

## Connections
- [[Cheap-phone particle budget (~300 alive on screen)]] - `rationale_for` [INFERRED]
- [[Particle limits (100s mobile, 20 s lifetime, flipbooks 30 fps)]] - `semantically_similar_to` [INFERRED]
- [[ParticleEmitter]] - `references` [EXTRACTED]

#graphify/concept #graphify/INFERRED #community/VFX_and_particles