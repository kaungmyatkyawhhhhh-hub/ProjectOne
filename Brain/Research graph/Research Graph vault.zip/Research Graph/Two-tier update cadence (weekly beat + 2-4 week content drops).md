---
source_file: "Playbook notes - Updates and live ops.md"
type: "rationale"
community: "Updates, events and release slot"
location: "L46"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Updates_events_and_release_slot
---

# Two-tier update cadence (weekly beat + 2-4 week content drops)

## Connections
- [[Adopt Me (Uplift Games) weekly update cycle]] - `rationale_for` [INFERRED]
- [[Grow a Garden weekly updates and 2-week events]] - `rationale_for` [INFERRED]
- [[Playbook notes Updates and live ops]] - `references` [EXTRACTED]
- [[Weekly beat (free login gift, fixed daytime)]] - `conceptually_related_to` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Updates_events_and_release_slot