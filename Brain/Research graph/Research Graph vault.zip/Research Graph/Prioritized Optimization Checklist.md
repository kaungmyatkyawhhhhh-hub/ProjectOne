---
source_file: "Playbook notes - Optimization deep dive.md"
type: "rationale"
community: "Optimization and retention mechanics"
location: "L417"
tags:
  - graphify/rationale
  - graphify/EXTRACTED
  - community/Optimization_and_retention_mechanics
---

# Prioritized Optimization Checklist

## Connections
- [[ContentProviderPreloadAsync_1]] - `references` [EXTRACTED]
- [[Lighting.LightingStyle and Local Light Cost]] - `references` [EXTRACTED]
- [[Mesh Instancing and Batching]] - `references` [EXTRACTED]
- [[MicroProfiler]] - `references` [EXTRACTED]
- [[Reference Case 31 FPS, 24k Parts, 421 Lights, 681 SurfaceGuis]] - `references` [EXTRACTED]
- [[SurfaceGui  BillboardGui Render Cost]] - `references` [EXTRACTED]
- [[UnreliableRemoteEvent]] - `references` [EXTRACTED]

#graphify/rationale #graphify/EXTRACTED #community/Optimization_and_retention_mechanics