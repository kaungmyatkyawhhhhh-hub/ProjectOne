---
source_file: "Playbook notes - Whole-game research (Oct 2026).md"
type: "concept"
community: "Idle maths and offline progress"
location: "L27"
tags:
  - graphify/concept
  - graphify/INFERRED
  - community/Idle_maths_and_offline_progress
---

# Offline progress (Pecorella, GDC 2015)

## Connections
- [[Idle progression maths and prestige (Pecorella)]] - `conceptually_related_to` [INFERRED]

#graphify/concept #graphify/INFERRED #community/Idle_maths_and_offline_progress