import React from 'react';import {Composition} from 'remotion';import {Reel} from './Reel';
// "Reel" = 30 fps preview/stills. "Reel120" = 4 sub-frames per output frame, blended later for real motion blur.
export const Root=()=> <>
 <Composition id="Reel" component={Reel} durationInFrames={405} fps={30} width={1080} height={1920}/>
 <Composition id="Reel120" component={Reel} durationInFrames={1620} fps={120} width={1080} height={1920}/>
</>;
