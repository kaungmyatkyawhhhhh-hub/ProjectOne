import React from 'react';
import {AbsoluteFill, Img, staticFile, useCurrentFrame, useVideoConfig, Audio} from 'remotion';
// Render contract: every pixel is a pure function of t. No CSS transitions, no timers, seeded randomness only.
// Anti-placeholder contract: every interface on screen is a capture of the REAL site with live data. Nothing mocked.
const FONT = `@font-face{font-family:X;src:url(${staticFile('mont-900i.woff2')})}@font-face{font-family:Mo;src:url(${staticFile('mont-800.woff2')})}@font-face{font-family:M;src:url(${staticFile('myanmar-700.woff2')})}`;
const B = 0.5; // 120 BPM
const cl = (v: number, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
const sp = (t: number, t0: number, f = 3.4, z = 0.5) => { // closed-form spring 0 -> 1 with a tiny overshoot
  const x = t - t0; if (x <= 0) return 0;
  const w = 2 * Math.PI * f, wd = w * Math.sqrt(1 - z * z);
  return 1 - Math.exp(-z * w * x) * (Math.cos(wd * x) + (z * w / wd) * Math.sin(wd * x));
};
const easeIn = (k: number) => cl(k) ** 3;
const seg = (t: number, a: number, b: number) => cl((t - a) / (b - a));
const hit = (t: number, t0: number, d = 0.12) => (t >= t0 ? Math.exp(-(t - t0) / d) : 0);
const rnd = (s: number) => { let a = s * 2654435761 >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let x = Math.imul(a ^ a >>> 15, 1 | a); x = x + Math.imul(x ^ x >>> 7, 61 | x) ^ x; return ((x ^ x >>> 14) >>> 0) / 4294967296; }; };
// brand tokens read off the live site: black studs, white heavy italic, one green accent, gold only for prices
const GREEN = '#19c37d', GOLD = '#ffc93c', INK = '#0b0b0f';

const Coins: React.FC<{t: number; t0: number; n: number; seed: number; cx: number; cy: number; power?: number}> = ({t, t0, n, seed, cx, cy, power = 1}) => {
  const x = t - t0; if (x < 0 || x > 1.6) return null; const r = rnd(seed);
  return <>{Array.from({length: n}, (_, i) => {
    const ang = -Math.PI / 2 + (r() - 0.5) * 2.6, v = (700 + r() * 900) * power, g = 2600, size = 70 + r() * 70, spin = (r() - 0.5) * 900;
    return <Img key={i} src={staticFile('rb_coin.webp')} style={{position: 'absolute', left: cx + Math.cos(ang) * v * x - size / 2, top: cy + Math.sin(ang) * v * x + 0.5 * g * x * x - size / 2, width: size, opacity: cl(1.6 - x), transform: `rotate(${spin * x}deg)`}} />;
  })}</>;
};
// a real captured element that lands on a beat: flies in from a side, overshoots a little, punches on impact
const Land: React.FC<{t: number; t0: number; src: string; x: number; y: number; w: number; rot: number; from: [number, number]; suck?: number; out?: number}> = ({t, t0, src, x, y, w, rot, from, suck = 0, out = 0}) => {
  if (t < t0 - 0.2) return null;
  const k = sp(t, t0 - 0.2, 3.0, 0.55), s = (1 + 0.07 * hit(t, t0, 0.1)) * (1 - 0.95 * easeIn(suck)), o = easeIn(out);
  const px = lerp(x + from[0], lerp(x, 540 - w / 2, easeIn(suck)), k), py = lerp(y + from[1], lerp(y, 900, easeIn(suck)), k) + o * 1700;
  return <Img src={staticFile(src)} style={{position: 'absolute', left: px, top: py, width: w, borderRadius: w * 0.08, transform: `rotate(${lerp(rot * 4, rot, k) + suck * 200 * Math.sign(from[0] || 1)}deg) scale(${s})`, boxShadow: '0 30px 60px rgba(0,0,0,.6)'}} />;
};
const typedN = (n: number, t: number, t0: number, per: number) => cl(Math.floor((t - t0) / per) + 1, 0, n);

export const Reel: React.FC = () => {
  const f = useCurrentFrame(); const {fps} = useVideoConfig(); const t = f / fps;
  const beat = t / B, ph = beat - Math.floor(beat); const afterDrop = t >= 4 && t < 12.6;
  const pulse = afterDrop ? Math.exp(-ph * B / 0.11) : 0;
  const shakeAmt = 34 * hit(t, 0, 0.16) + 46 * hit(t, 4, 0.2) + 20 * hit(t, 10, 0.14) + 30 * hit(t, 12, 0.18);
  // one shake offset per OUTPUT frame, so the sub-frames of a blended frame agree
  const r = rnd(Math.floor(t * 30 + 1e-6) + 3); const shx = (r() - 0.5) * 2 * shakeAmt, shy = (r() - 0.5) * 2 * shakeAmt;
  const punch = 1 + 0.09 * hit(t, 4, 0.22) + 0.05 * hit(t, 0, 0.18) + 0.05 * hit(t, 12, 0.2) + 0.01 * pulse;
  const flash = 0.8 * cl(1 - (t - 4) / 0.16) * (t >= 4 ? 1 : 0) + 0.28 * cl(1 - t / 0.12) + 0.35 * cl(1 - (t - 12) / 0.14) * (t >= 12 ? 1 : 0);
  const dark = cl(seg(t, 3.55, 3.75)) * (t < 4 ? 1 : 0) + seg(t, 12.75, 13.45);
  // A
  const aOut = easeIn(seg(t, 1.62, 1.95));
  const chestS = lerp(1.4, 1, sp(t, -0.04, 3.2, 0.42)); // frame 1 must already READ as the payoff (it is the cover frame)
  const suck = seg(t, 3.3, 3.74);
  // wordmark: ONE element that never cuts (slam -> top -> covered by the real screens -> centre)
  const wmIn = sp(t, 4 - 0.03, 2.8, 0.42), toTop = sp(t, 5.86, 2.6, 0.62), toMid = sp(t, 9.9, 2.6, 0.55);
  const wmY = lerp(lerp(780, 250, toTop), 640, toMid), wmS = lerp(3.2, 1.12, wmIn) * lerp(lerp(1, 0.46, toTop), 1.0, toMid) * (1 + 0.03 * pulse + 0.07 * hit(t, 12, 0.2));
  const split = 14 * hit(t, 4, 0.1);
  // E: the real order flow, full-bleed. camera = scale + focus point, on springs
  const eIn = sp(t, 7.9, 2.8, 0.6), eOut = easeIn(seg(t, 9.84, 10.02));
  const nT = typedN(8, t, 8.04, 0.055);
  const shot = t < 8.5 ? `ui/type${nT}.png` : t < 9.0 ? 'ui/found.png' : 'ui/picked.png';
  const k1 = sp(t, 8.5, 2.6, 0.7), k2 = sp(t, 9.0 - 0.06, 2.6, 0.7);
  const zoom = lerp(lerp(1.05, 1.09, k1), 1.05, k2) + 0.015 * (t - 8), fy = lerp(lerp(900, 1100, k1), 1500, k2), fx = 540;
  const sheet = sp(t, 9.5 - 0.05, 2.8, 0.62), tap = seg(t, 9.0, 9.35);
  const nU = typedN(11, t, 10.5, 0.0625), url = 'studmm.shop'.slice(0, nU), cursor = Math.floor(t * 4) % 2 === 0;
  return <AbsoluteFill style={{background: '#000', overflow: 'hidden'}}>
    <style>{FONT}</style>
    <Audio src={staticFile('mix.wav')} />
    <AbsoluteFill style={{transform: `translate(${shx}px,${shy}px) scale(${punch})`}}>
      {/* the site's own background: black with studs. One green light, only after the drop */}
      <AbsoluteFill style={{background: INK}} />
      <AbsoluteFill style={{backgroundImage: `url(${staticFile('tex_studs.webp')})`, backgroundSize: '300px 300px', backgroundPosition: `${-t * 36}px ${-t * 22}px`, opacity: 0.55 + 0.25 * pulse}} />
      <div style={{position: 'absolute', left: 540 - 900, top: (t < 4 ? 900 : wmY) - 900, width: 1800, height: 1800, background: `radial-gradient(circle, rgba(25,195,125,${afterDrop ? 0.16 + 0.1 * pulse : 0.05}) 0%, transparent 60%)`}} />

      {/* A: the payoff on frame 1 */}
      {t < 2 && <div style={{position: 'absolute', inset: 0, transform: `translateX(${-1500 * aOut}px) scale(${1 - 0.06 * seg(t, 1.45, 1.62) + 0.06 * aOut})`}}>
        <Coins t={t} t0={0} n={18} seed={11} cx={540} cy={1000} power={1.3} />
        <Img src={staticFile('rb_t4.webp')} style={{position: 'absolute', left: 540 - 400, top: 600, width: 800, transform: `scale(${chestS}) rotate(${lerp(-10, 0, sp(t, 0, 3, 0.4))}deg)`, filter: 'drop-shadow(0 30px 40px rgba(0,0,0,.6))'}} />
        <div style={{position: 'absolute', left: 0, right: 0, top: 250, textAlign: 'center', fontFamily: 'X', fontSize: 230, color: '#fff', letterSpacing: -4, transform: `scale(${lerp(0, 1, sp(t, 0.5 - 0.03, 3.6, 0.42))}) rotate(${lerp(-10, -3, sp(t, 0.5, 3, 0.5))}deg)`, textShadow: '0 12px 0 rgba(0,0,0,.55)'}}>ROBUX</div>
        <div style={{position: 'absolute', left: 0, right: 0, top: 1440, textAlign: 'center', fontFamily: 'M', fontSize: 140, color: GOLD, transform: `scale(${lerp(0, 1, sp(t, 1.0 - 0.03, 3.6, 0.42))})`, textShadow: '0 10px 0 rgba(0,0,0,.6)'}}>လိုချင်လား?</div>
      </div>}

      {/* B: the three real shop tabs land on the beats (one big, two small), then get sucked into the centre */}
      {t >= 1.7 && t < 3.8 && <>
        <Land t={t} t0={2.0} src="ui/el_game0.png" x={40} y={540} w={640} rot={-4} from={[-1100, 0]} suck={suck} />
        <Land t={t} t0={2.5} src="ui/el_game1.png" x={650} y={470} w={390} rot={5} from={[1000, -200]} suck={suck} />
        <Land t={t} t0={3.0} src="ui/el_game2.png" x={630} y={960} w={400} rot={-3} from={[1000, 300]} suck={suck} />
      </>}

      {/* C: logo slam + the site's real headline */}
      {t >= 3.97 && <>
        <Coins t={t} t0={4} n={22} seed={5} cx={540} cy={900} power={1.25} /><Coins t={t} t0={12} n={12} seed={9} cx={540} cy={wmY + 140} power={0.9} />
        {[-1, 1].map(d => split > 0.5 && <Img key={d} src={staticFile('wordmark.webp')} style={{position: 'absolute', left: 540 - 430 + d * split, top: wmY - 213, width: 860, transform: `scale(${wmS})`, opacity: 0.5, filter: `hue-rotate(${d * 120}deg)`, mixBlendMode: 'screen'}} />)}
        <Img src={staticFile('wordmark.webp')} style={{position: 'absolute', left: 540 - 430, top: wmY - 213, width: 860, transform: `scale(${wmS}) rotate(${lerp(-7, 0, wmIn)}deg)`, filter: 'drop-shadow(0 26px 30px rgba(0,0,0,.6))'}} />
      </>}
      {t >= 4.9 && t < 6.2 && <div style={{position: 'absolute', left: 0, right: 0, top: lerp(1750, 1250, sp(t, 5 - 0.1, 3.2, 0.5)) + 900 * easeIn(seg(t, 5.8, 6.1)), textAlign: 'center', fontFamily: 'X, M', fontSize: 108, whiteSpace: 'nowrap', color: '#fff', transform: `scale(${1 + 0.08 * hit(t, 5, 0.1)}) rotate(-2deg)`, textShadow: '0 10px 0 rgba(0,0,0,.6)'}}>Robux <span style={{color: GOLD}}>33 Ks</span> ကစ</div>}

      {/* D: three real price tiles, one per beat, growing in size (not an equal row) */}
      {t >= 5.8 && t < 8 && <>
        <Land t={t} t0={6.0} src="ui/el_tile1.png" x={70} y={480} w={380} rot={-5} from={[-900, 0]} out={seg(t, 7.5, 7.8)} />
        <Land t={t} t0={6.5} src="ui/el_tile3.png" x={570} y={560} w={440} rot={4} from={[900, 0]} out={seg(t, 7.54, 7.84)} />
        <Land t={t} t0={7.0} src="ui/el_tile5.png" x={270} y={1120} w={520} rot={-2} from={[0, 1100]} out={seg(t, 7.58, 7.88)} />
      </>}

      {/* E: the real site, full-bleed: type a real username -> real live check -> pick R$ 500 -> real checkout */}
      {t >= 7.8 && t < 10.05 && <div style={{position: 'absolute', inset: 0, overflow: 'hidden', transform: `translateY(${lerp(1950, 0, eIn) - 2100 * eOut}px)`}}>
        <Img src={staticFile(shot)} style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, transformOrigin: `${fx}px ${fy}px`, transform: `translate(${540 - fx}px,${960 - fy}px) scale(${zoom})`}} />
        {/* tap ripple on the real Buy button */}
        {tap > 0 && tap < 1 && <div style={{position: 'absolute', left: 540 + (860 - fx) * zoom - 150 * tap - 20, top: 960 + (1455 - fy) * zoom - 150 * tap - 20, width: 300 * tap + 40, height: 300 * tap + 40, borderRadius: '50%', border: `${lerp(22, 0, tap)}px solid #fff`, opacity: 1 - tap}} />}
        {t >= 9.42 && <Img src={staticFile('ui/checkout1.png')} style={{position: 'absolute', left: 0, top: lerp(1920, 0, sheet), width: 1080, height: 1920}} />}
      </div>}

      {/* F: end card */}
      {t >= 10.2 && <>
        <div style={{position: 'absolute', left: 0, right: 0, top: 1100, display: 'flex', justifyContent: 'center'}}>
          <div style={{fontFamily: 'Mo', fontSize: 112, color: '#fff', background: '#16161d', border: `6px solid ${GREEN}`, borderRadius: 40, padding: '26px 64px 30px', minWidth: 300, transform: `scale(${sp(t, 10.3, 3.2, 0.5) * (1 + 0.06 * hit(t, 12, 0.2))})`, boxShadow: '0 18px 0 rgba(0,0,0,.5)'}}>{url}<span style={{opacity: cursor && t < 12.6 ? 1 : 0, color: GREEN}}>|</span></div>
        </div>
        {t >= 11.4 && <div style={{position: 'absolute', left: 0, right: 0, top: 1420, textAlign: 'center', fontFamily: 'M', fontSize: 112, color: GOLD, transform: `scale(${sp(t, 11.5 - 0.03, 3.6, 0.42) * (1 + 0.08 * hit(t, 12, 0.2))}) rotate(-3deg)`, textShadow: '0 10px 0 rgba(0,0,0,.6)'}}>အခုပဲ ဝယ်လိုက်!</div>}
      </>}
    </AbsoluteFill>
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at center,transparent 60%,rgba(0,0,0,.5) 100%)'}} />
    <AbsoluteFill style={{background: '#fff', opacity: cl(flash)}} />
    <AbsoluteFill style={{background: '#000', opacity: cl(dark)}} />
  </AbsoluteFill>;
};
