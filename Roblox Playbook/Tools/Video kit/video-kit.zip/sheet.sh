#!/bin/bash
# one frame per beat -> contact sheet (LOOK at it before any full render). stills one at a time (parallel runs clash)
cd "$(dirname "$0")"; mkdir -p st; rm -f st/b*.png
CH=/opt/pw-browsers/chromium-1243/chrome-linux64/chrome
for b in $(seq 0 26); do fr=$(python3 -c "print(min(404,int(round(($b*0.5+${1:-0.10})*30))))"); npx remotion still src/index.ts Reel st/b$(printf %02d $b).png --frame=$fr --browser-executable=$CH --scale=0.25 2>&1 | grep -i "error" ; done
python3 - <<'PY'
from PIL import Image,ImageDraw;import glob
fs=sorted(glob.glob('st/b*.png'));ims=[Image.open(f) for f in fs];w,h=ims[0].size
S=Image.new('RGB',(w*9,h*3))
for i,im in enumerate(ims):
    S.paste(im,((i%9)*w,(i//9)*h));ImageDraw.Draw(S).text(((i%9)*w+6,(i//9)*h+4),f'beat {i} {i*0.5:.1f}s',fill='yellow')
S.save('st/sheet.jpg');print(len(ims),'frames')
PY
