info=pg.evaluate("""()=>{const all=[...document.querySelectorAll('#rbx-chips *, #rbx *')];const t=all.find(e=>e.children.length<8&&/R\\$\\s*500/.test(e.textContent)&&e.offsetHeight<400&&e.offsetHeight>60);return t?JSON.stringify({cls:t.className,tag:t.tagName,par:t.parentElement.className,h:t.offsetHeight,oc:(t.getAttribute('onclick')||'').slice(0,80)}):'none'}""")
print(info)
pg.add_style_tag(content="*{caret-color:transparent}")
# 1 hero + tiles (real elements)
pg.locator('.hero').first.screenshot(path=HERE+'/el_hero.png')
for i,g in enumerate(['#g-rb']+[]): pass
gs=pg.locator('.game:visible'); print('games',gs.count())
for i in range(min(3,gs.count())): gs.nth(i).screenshot(path=HERE+f'/el_game{i}.png')
# 2 price tiles (hide the sticky bar so nothing covers them)
pg.add_style_tag(content='.bar{visibility:hidden}')
tiles=pg.locator('#rbx-chips > *'); print('tiles',tiles.count())
for i in range(tiles.count()): tiles.nth(i).screenshot(path=HERE+f'/el_tile{i}.png')
pg.add_style_tag(content='.bar{visibility:visible!important}')
# 3 username typing (real field, real live check)
pg.locator('#pid').scroll_into_view_if_needed(); pg.evaluate("window.scrollBy(0,-170)"); pg.wait_for_timeout(300)
name='RCBstore'; pg.locator('#pid').click()
for i in range(len(name)+1):
    pg.locator('#pid').fill(name[:i]); pg.wait_for_timeout(40); pg.screenshot(path=HERE+f'/type{i}.png')
pg.locator('#pid').dispatch_event('input'); pg.wait_for_timeout(2200); pg.screenshot(path=HERE+'/found.png')
# 4 pick R$ 500, see the real total in the bar
t=pg.locator('#rbx-chips > *',has_text='500').first; t.scroll_into_view_if_needed(); pg.evaluate("window.scrollBy(0,120)"); pg.wait_for_timeout(300); pg.screenshot(path=HERE+'/grid.png'); t.click(); pg.wait_for_timeout(500); pg.screenshot(path=HERE+'/picked.png')
print('total',pg.locator('#btot').inner_text(),'| sel',pg.locator('#bsel').inner_text())
# 5 buy -> real checkout sheet
pg.locator('#buy').click(); pg.wait_for_timeout(700); pg.screenshot(path=HERE+'/checkout0.png'); pg.wait_for_timeout(2200); pg.screenshot(path=HERE+'/checkout1.png')
