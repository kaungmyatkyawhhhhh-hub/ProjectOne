"""Capture the REAL site UI (real page code + live data snapshot) at 1080x1920 for use in the edit. No mock-ups."""
import json,sys,subprocess,time,os
from playwright.sync_api import sync_playwright
HERE=os.path.dirname(os.path.abspath(__file__)); PUB='/home/claude/flashtopup/public'
srv=subprocess.Popen(['python3','-m','http.server','8765','--directory',PUB],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
P=json.load(open(HERE+'/products.json'))
CFG={"shop":"Flash TopUp","contact":"@rongstrix","pay":{"kbz_number":"","kbz_name":"","wave_number":"","wave_name":""},"roblox_group":"https://www.roblox.com/communities/32473646/Radiant-Games-Studios","rbx_plus_max":1000,"rbx_tiers":[[40,5],[100,4],[200,3],[500,2],[800,1],[1000,0]]}
def api(route):
    u=route.request.url
    if '/api/config' in u: b=CFG
    elif '/api/products' in u: b=P
    elif '/api/stats' in u: b={"delivered":13,"median_min":2,"support_hours":""}
    elif '/api/rbx_check' in u: b={"ok":True,"found":True,"id":1,"name":"RCBstore","display":"RCBstore","in_group":True,"group_id":32473646,"days":394,"need":15}
    elif '/api/plus_left' in u: b={"ok":True,"day_left":500,"month_left":1000}
    else: b={}
    route.fulfill(status=200,content_type='application/json',body=json.dumps(b))
try:
    with sync_playwright() as p:
        br=p.chromium.launch(); cx=br.new_context(viewport={'width':360,'height':640},device_scale_factor=3,is_mobile=True,has_touch=True,locale='my-MM')
        pg=cx.new_page(); pg.route('**/api/**',api); pg.goto('http://localhost:8765/stud.html'); pg.wait_for_timeout(2500)
        exec(open(HERE+'/steps.py').read())
        br.close()
finally:
    srv.terminate()
