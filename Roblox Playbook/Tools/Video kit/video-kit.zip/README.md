# Video kit (10 Nov 2026) - used by the `pro-video-editing` skill
Order: score.py -> master.sh -> check_audio.py -> sheet.sh (look!) -> render Reel120 -> finish.sh -> check_video.py + check_audio.py on the final mp4.
- `npm i remotion @remotion/cli react react-dom` (4.0.300), fonts + art go in `public/`.
- `python3 score.py` writes out/mix_raw.wav + src/events.json (one timeline for sound and picture). `./master.sh` -> public/mix.wav (-14 LUFS).
- `./sheet.sh 0.10` -> st/sheet.jpg, one frame per beat.
- `npx remotion render src/index.ts Reel120 out/r120.mp4 --browser-executable=/opt/pw-browsers/chromium-1243/chrome-linux64/chrome --concurrency=2 --crf=12` then `./finish.sh`.
- `cap/cap.py` runs the real site page locally with live data (edit CFG/products/steps.py) and screenshots real states at 1080x1920.
Reel.tsx is the Stud Shop practice ad: copy its helpers (sp, hit, Land, Coins), not its content.
