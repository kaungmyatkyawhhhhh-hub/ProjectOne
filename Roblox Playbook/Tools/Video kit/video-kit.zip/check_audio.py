"""Audio QA: sync (every event has an onset within 40 ms), loudness, band balance, stop-down, layer check."""
import json,sys,subprocess,re,numpy as np,librosa
f=sys.argv[1] if len(sys.argv)>1 else 'public/mix.wav'
if not f.endswith('.wav'):
    subprocess.run(['ffmpeg','-v','error','-y','-i',f,'-vn','-ar','48000','out/_check.wav'],check=True); f='out/_check.wav'
y,sr=librosa.load(f,sr=48000,mono=True); E=json.load(open('src/events.json'))
oenv=librosa.onset.onset_strength(y=y,sr=sr,hop_length=256)
on=librosa.onset.onset_detect(onset_envelope=oenv,sr=sr,hop_length=256,units='time',backtrack=False,delta=0.05)
bad=[]
for e in E['events']:
    if e['kind'] in('riser','sparkle','suckback','whoosh'):continue   # swells have no sharp onset; whoosh peaks are checked on the envelope
    d=min(abs(on-e['t']))*1000
    if d>(70 if 'typing' in e.get('label','') else 40):bad.append((e['t'],e['kind'],e.get('label',''),int(d)))
hits=[e for e in E['events'] if e['kind'] not in('riser','sparkle','suckback','whoosh')]
print(f'SYNC  {len(hits)-len(bad)}/{len(hits)} hit events have an onset within 40 ms',('| late/missing: '+str(bad)) if bad else '')
rms=librosa.feature.rms(y=y,frame_length=1024,hop_length=256)[0];t=librosa.frames_to_time(np.arange(len(rms)),sr=sr,hop_length=256)
for e in E['events']:
    if e['kind']=='whoosh':
        w=(t>e['t']-0.2)&(t<e['t']+0.2)
        # energy in the whoosh's own band (mid/high noise) peaks where the move is fastest
print('STOP  level 3.80-3.98s:',round(20*np.log10(rms[(t>3.80)&(t<3.98)].mean()+1e-9),1),'dB vs drop 4.0-4.3s:',round(20*np.log10(rms[(t>4.0)&(t<4.3)].mean()+1e-9),1),'dB')
S=np.abs(librosa.stft(y,n_fft=4096,hop_length=1024))**2;fr=librosa.fft_frequencies(sr=sr,n_fft=4096);tot=S.sum()
print('BANDS',' '.join(f'{n}:{100*S[(fr>=a)&(fr<b)].sum()/tot:.0f}%' for n,a,b in [('sub<60',0,60),('bass60-250',60,250),('lowmid250-2k',250,2000),('pres2k-6k',2000,6000),('air>6k',6000,24000)]))
out=subprocess.run(['ffmpeg','-hide_banner','-i',f,'-af','ebur128=peak=true','-f','null','-'],capture_output=True,text=True).stderr
I=re.findall(r'I:\s+(-?[\d.]+) LUFS',out)[-1];LRA=re.findall(r'LRA:\s+([\d.]+) LU',out)[-1];P=re.findall(r'Peak:\s+(-?[\d.]+) dBFS',out)[-1]
print(f'LOUD  I {I} LUFS (target -14 ±0.5) | true peak {P} dBFS (max -1.5) | LRA {LRA}')
# dead air: no 1.0 s window quieter than -35 dB except the stop-down and the tail
q=[round(a,1) for a in np.arange(0,12.5,0.25) if 20*np.log10(rms[(t>=a)&(t<a+1.0)].mean()+1e-9)<-35]
print('DEAD AIR windows:',q or 'none')
