"""Score + sound design in code. One timeline (events.json) drives BOTH the sound and the picture.
Layers: music (kick, clap, hats, bass, plucks, lead) + SFX (each built from low/mid/high layers) -> mix -> master.
"""
import json, numpy as np, scipy.signal as sg, soundfile as sf
SR = 48000; BPM = 120; B = 60 / BPM; DUR = 13.5
N = int(SR * DUR); rng = np.random.default_rng(7)
L = np.zeros(N); R = np.zeros(N)            # sfx bus (stereo)
M = np.zeros(N)                             # music bus (mono core, widened later)


def env(n, a=0.002, d=0.2, curve=1.0):
    t = np.arange(n) / SR
    return np.minimum(1, t / a) * np.exp(-t / d) ** curve


def filt(x, kind, f, order=2):
    sos = sg.butter(order, np.array(f) / (SR / 2), kind, output='sos')
    return sg.sosfilt(sos, x)


def noise(n):
    return rng.standard_normal(n)


def put(bus, x, t):
    i = int(round(t * SR))
    if i < 0: x = x[-i:]; i = 0
    j = min(N, i + len(x))
    if j > i: bus[i:j] += x[:j - i]


def put_st(x, t, pan=0.0, g=1.0):           # pan -1..1 (equal power); x may be (n,) or pan sweep via tuple
    if isinstance(pan, tuple):
        p = np.linspace(pan[0], pan[1], len(x))
    else:
        p = np.full(len(x), pan)
    a = (p + 1) * np.pi / 4
    put(L, x * np.cos(a) * g, t); put(R, x * np.sin(a) * g, t)


IR = noise(int(1.6 * SR)) * np.exp(-np.arange(int(1.6 * SR)) / SR / 0.45)
IR = filt(IR, 'low', 6000); IR /= np.abs(IR).max()


def reverb(x, wet=0.25, tail=1.6):
    y = sg.fftconvolve(np.concatenate([x, np.zeros(int(tail * SR))]), IR)[:len(x) + int(tail * SR)]
    y /= max(1e-9, np.abs(y).max()) / max(1e-9, np.abs(x).max())
    out = np.concatenate([x, np.zeros(int(tail * SR))]) * (1 - wet * 0.3) + y * wet
    return out


# ---------- SFX: every sound = low + mid + high layer (a "layer cake") ----------
def impact(size=1.0):
    n = int(0.9 * SR); t = np.arange(n) / SR
    sub = np.sin(2 * np.pi * np.cumsum(30 + 70 * np.exp(-t / 0.06)) / SR) * np.exp(-t / 0.28)      # low: sub drop
    mid = filt(noise(n), 'low', 500, 4) * np.exp(-t / 0.09) * 1.4                                   # mid: thud
    hi = filt(noise(n), 'high', 3500) * np.exp(-t / 0.035) * 0.5                                    # high: crack
    return reverb((sub * 0.7 + mid * 0.8 + hi * 0.7) * size, wet=0.22)


def whoosh(dur=0.42, peak=0.55, bright=1.0):
    """Peak (loudest point) sits at `peak` of the sound: line it up with the fastest frame of the move."""
    n = int(dur * SR); t = np.arange(n) / n
    e = np.where(t < peak, (t / peak) ** 2.2, ((1 - t) / (1 - peak)) ** 1.6)
    out = np.zeros(n)
    for lo, hi, g in [(90, 260, 0.9), (500, 1800, 0.8), (3500, 9000, 0.45 * bright)]:               # low / mid / high
        out += filt(noise(n), 'band', [lo, hi]) * g
    # doppler-ish sweep: amplitude-modulated comb shimmer
    out *= e
    return out / np.abs(out).max()


def riser(dur):
    n = int(dur * SR); t = np.arange(n) / n
    f = 200 * (2 ** (t * 3.3))
    tone = np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.25 + np.sin(2 * np.pi * np.cumsum(f * 1.5) / SR) * 0.12
    air = np.zeros(n); x = noise(n)
    for k in range(8):                                                                               # opening filter in 8 steps
        a, b = int(n * k / 8), int(n * (k + 1) / 8)
        air[a:b] = filt(x, 'band', [300 + 500 * k, 1500 + 1300 * k])[a:b]
    return (tone + air * 0.5) * t ** 2.0


def suckback(dur=0.5):
    x = impact(0.8)[:int(dur * SR)][::-1]                                                            # a reversed hit = suck-back
    return x * np.linspace(0, 1, len(x)) ** 1.5


def pop(f=880.0):
    n = int(0.09 * SR); t = np.arange(n) / SR
    return (np.sin(2 * np.pi * np.cumsum(f * (1 + 1.2 * np.exp(-t / 0.012))) / SR) * np.exp(-t / 0.03)
            + filt(noise(n), 'high', 5000) * np.exp(-t / 0.006) * 0.3)


def click():
    n = int(0.03 * SR); t = np.arange(n) / SR
    return filt(noise(n), 'band', [1800, 6500]) * np.exp(-t / 0.004) + np.sin(2 * np.pi * 240 * t) * np.exp(-t / 0.008) * 0.5


def bell(f=1318.5, d=0.5):
    n = int(1.0 * SR); t = np.arange(n) / SR
    x = sum(np.sin(2 * np.pi * f * r * t) * a * np.exp(-t / (d / r ** 0.5)) for r, a in [(1, 1), (2.76, 0.45), (5.4, 0.25), (8.9, 0.12)])
    return reverb(x * 0.5, wet=0.2, tail=0.8)


def sparkle(dur=0.8, n_notes=14):
    out = np.zeros(int((dur + 0.5) * SR))
    for k in range(n_notes):
        f = rng.choice([2093, 2349, 2637, 3136, 3520, 4186]); t0 = rng.uniform(0, dur)
        b = bell(f, 0.12)[:int(0.3 * SR)] * rng.uniform(0.15, 0.4)
        i = int(t0 * SR); out[i:i + len(b)] += b[:len(out) - i]
    return out


# ---------- events: the ONE timeline shared with the picture ----------
EV = []
def ev(t, kind, **kw): EV.append(dict(t=round(t, 3), kind=kind, **kw))

ev(0.0, 'impact', label='chest burst', size=1.0); ev(0.02, 'sparkle', dur=0.9)
ev(0.5, 'pop', f=660, label='word 1'); ev(1.0, 'pop', f=880, label='word 2')
ev(1.72, 'whoosh', pan=(0.2, -0.8), label='exit left', dur=0.4, g=0.5)
for k, (t, pan) in enumerate([(2.0, (-0.9, 0.3)), (2.5, (0.9, -0.3)), (3.0, (-0.9, 0.3))]):
    ev(t - 0.11, 'whoosh', pan=pan, dur=0.34, peak=0.5, g=0.7, label=f'card {k + 1} in')   # whoosh peak = fastest frame, just before landing
    ev(t, 'thud', label=f'card {k + 1} lands')
ev(2.0, 'riser', dur=1.75)
ev(3.3, 'suckback', dur=0.45)
ev(4.0, 'impact', label='DROP logo slam', size=1.25); ev(4.03, 'sparkle', dur=0.7)
ev(5.0, 'pop', f=1046, label='tagline')
for t, lab in [(6.0, 'feature 1'), (6.5, 'feature 2'), (7.0, 'feature 3')]:
    ev(t, 'thud', label=lab); ev(t, 'pop', f=784)
ev(7.56, 'whoosh', pan=(0, 0), dur=0.4, peak=0.45, g=0.6, label='rows out')
ev(8.0, 'thud', label='UI card in', soft=True)
for k in range(8): ev(8.04 + k * 0.055, 'click', label='typing')
ev(8.5, 'bell', f=1568, label='username found (real live check)')
ev(9.0, 'click', label='buy press', big=True)
ev(9.5, 'bell', f=2093, label='real checkout sheet')
ev(9.86, 'whoosh', pan=(0, 0), dur=0.3, peak=0.5, g=0.6, label='to end card')
ev(10.0, 'impact', label='end card', size=0.8)
for k in range(11): ev(10.5 + k * 0.0625, 'click', label='url typing')
ev(11.5, 'pop', f=1318, label='cta')
ev(12.0, 'impact', label='final hit', size=1.1); ev(12.0, 'sparkle', dur=0.6)

for e in EV:
    k, t = e['kind'], e['t']
    if k == 'impact': put_st(impact(e['size']), t, 0, 0.95)
    elif k == 'sparkle': put_st(sparkle(e['dur']), t, (-0.6, 0.6), 0.8)
    elif k == 'pop': put_st(pop(e['f']), t, 0, 0.75)
    elif k == 'whoosh':
        w = whoosh(e['dur'], e.get('peak', 0.55)); put_st(w, t - e['dur'] * e.get('peak', 0.55) + 0.0, e['pan'], e['g'])
    elif k == 'thud':
        x = impact(0.55)[:int(0.35 * SR)] * (0.5 if e.get('soft') else 0.75); put_st(x, t, 0, 0.8)
    elif k == 'riser': put_st(riser(e['dur']), t, 0, 0.5)
    elif k == 'suckback': put_st(suckback(e['dur']), t, 0, 0.9)
    elif k == 'click': put_st(click() * (2.2 if e.get('big') else 1.5), t, rng.uniform(-0.25, 0.25), 0.6)
    elif k == 'bell': put_st(bell(e['f']), t, 0, 0.5)

# ---------- music ----------
def kick():
    n = int(0.32 * SR); t = np.arange(n) / SR
    return np.sin(2 * np.pi * np.cumsum(46 + 110 * np.exp(-t / 0.035)) / SR) * np.exp(-t / 0.14) + click()[:1].sum() * 0


def clap():
    n = int(0.22 * SR); t = np.arange(n) / SR
    x = filt(noise(n), 'band', [900, 3800]) * (np.exp(-t / 0.05) + 0.6 * np.exp(-((t - 0.012) ** 2) / 2e-5))
    return reverb(x * 0.6, wet=0.18, tail=0.3)


def hat(open_=False):
    n = int((0.16 if open_ else 0.045) * SR); t = np.arange(n) / SR
    return filt(noise(n), 'high', 7000) * np.exp(-t / (0.05 if open_ else 0.012)) * 0.35


def saw(f, n):
    ph = np.cumsum(np.full(n, f)) / SR
    return 2 * (ph % 1) - 1


def pluck(f, dur=0.22, bright=2600):
    n = int(dur * SR); t = np.arange(n) / SR
    x = saw(f, n) + saw(f * 1.006, n) + saw(f * 0.994, n)
    return filt(x, 'low', bright, 2) * np.exp(-t / 0.09) * 0.36


def bass(f, dur):
    n = int(dur * SR); t = np.arange(n) / SR
    return (np.sin(2 * np.pi * f * t) + 0.35 * filt(saw(f, n), 'low', 420)) * np.minimum(1, t / 0.005) * np.exp(-t / 0.5) * 0.36


C = 261.63; st = lambda s: C * 2 ** (s / 12)
CH = {  # root (bass), triad
    'Cm': (st(-24), [st(0), st(3), st(7)]), 'Ab': (st(-28), [st(-4), st(0), st(3)]),
    'Eb': (st(-21), [st(3), st(7), st(10)]), 'Bb': (st(-26), [st(-2), st(2), st(5)])}
BARS = ['Cm', 'Ab', 'Cm', 'Ab', 'Eb', 'Bb']
PENT = [st(s) for s in (12, 15, 17, 19, 22, 24)]
kicks = []
for bar, name in enumerate(BARS):
    root, tri = CH[name]; t0 = bar * 4 * B
    full = bar >= 2
    for q in range(4):                      # beats
        tb = t0 + q * B
        if bar >= 1 and not (bar == 1 and q == 3): put(M, kick() * 0.7, tb); kicks.append(tb)
        if full and q % 2 == 1: put(M, clap() * 0.8, tb)
    for e8 in range(8):                     # 8th notes
        te = t0 + e8 * B / 2
        if bar == 1 and e8 >= 7: continue
        if full or bar == 0: put(M, hat(e8 % 2 == 1 and full) * (1.5 if full else 0.8), te)
        if full: put(M, bass(root * 2, B / 2 * 0.95) * (1.0 if e8 % 2 else 0.8), te)
        put(M, pluck(tri[e8 % 3] * (2 if (e8 % 4 == 3) else 1), bright=1500 if bar < 2 else 3200) * (0.7 if bar < 2 else 1.0), te)
    if full and bar != 4:                   # lead arp: leave bar 5 (the UI demo) empty so the UI sounds own that space
        for s16 in range(16):
            put(M, pluck(PENT[(s16 * 5 + bar) % 6] * (1 if s16 % 2 else 0.5), 0.14, 5200) * (0.25 if (bar == 5 and s16 >= 4 and s16 < 12) else 0.5), t0 + s16 * B / 4)  # thin the lead while the URL is typed
# final hit chord with reverb tail
fin = sum(pluck(f, 1.2, 3000) for f in CH['Cm'][1]) + bass(CH['Cm'][0] * 2, 1.2)
put(M, reverb(fin * 1.2, wet=0.45)[:int(1.5 * SR)], 12.0); put(M, kick(), 12.0); kicks.append(12.0)

# sidechain: everything in the music ducks under the kick (kick itself is in M, so duck gently)
side = np.ones(N)
for tk in kicks:
    i = int(tk * SR); n = int(0.22 * SR); j = min(N, i + n)
    side[i:j] = np.minimum(side[i:j], 1 - 0.28 * np.exp(-np.arange(j - i) / SR / 0.07))
# build bar 2 is thin (high-passed) so the drop feels bigger; stop-down = silence right before the drop
a, b = int(4 * B * SR), int(8 * B * SR)
M[a:b] = filt(M[a:b], 'high', 260) * 0.8
sd = np.ones(N); s0, s1 = int(3.74 * SR), int(4.0 * SR)
sd[s0:s1] = 0; sd[s0 - 960:s0] = np.linspace(1, 0, 960)
M *= sd
# duck the music under the big hits so they read (not just "turn it down": short, -4 dB)
duck = np.ones(N)
for e in EV:
    if e['kind'] == 'impact':
        i = int(e['t'] * SR); n = int(0.45 * SR); j = min(N, i + n)
        duck[i:j] = np.minimum(duck[i:j], 1 - 0.37 * np.exp(-np.arange(j - i) / SR / 0.16))
M *= duck
# stereo: music mids centred, a touch of width from a short Haas copy on the highs
Mh = filt(M, 'high', 2500); d = int(0.011 * SR)
ML = M + 0.35 * Mh; MR = M + 0.35 * np.concatenate([np.zeros(d), Mh[:-d]])
mixL = ML * 0.62 + L * 0.9; mixR = MR * 0.62 + R * 0.9
mix = np.stack([mixL, mixR], 1)
mix = sg.sosfilt(sg.butter(2, 30 / (SR / 2), 'high', output='sos'), mix, axis=0)   # no sub rumble
mix[-int(0.6 * SR):] *= np.linspace(1, 0, int(0.6 * SR))[:, None] ** 1.5          # tail out for the loop
mix = np.tanh(mix / np.abs(mix).max() * 1.6) / np.tanh(1.6) * 0.89                 # soft clip, glue
sf.write('out/mix_raw.wav', mix, SR)
sf.write('out/sfx_only.wav', np.stack([L, R], 1) / max(1e-9, np.abs(np.stack([L, R])).max()) * 0.8, SR)
json.dump(dict(bpm=BPM, beat=B, dur=DUR, events=EV), open('public/events.json', 'w'), indent=0)
json.dump(dict(bpm=BPM, beat=B, dur=DUR, events=EV), open('src/events.json', 'w'), indent=0)
print('events', len(EV), 'kicks', len(kicks))
