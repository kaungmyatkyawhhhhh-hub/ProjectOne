#!/bin/bash
set -euo pipefail
# 120 fps render -> blend 4 sub-frames per output frame (real motion blur) -> 30 fps + mastered audio
cd "$(dirname "$0")"; IN=${1:-out/r120.mp4}; OUT=${2:-out/final.mp4}
[ -s "$IN" ] || { echo "FINISH FAILED: $IN missing (the render did not finish)"; exit 1; }
ffmpeg -v error -y -i "$IN" -i public/mix.wav -filter_complex "[0:v]tmix=frames=4:weights='1 1 1 1',select='not(mod(n-3\,4))',setpts=N/30/TB[v]" -map "[v]" -map 1:a -r 30 -c:v libx264 -preset medium -crf 15 -pix_fmt yuv420p -c:a aac -b:a 256k -movflags +faststart -shortest "$OUT"
ffprobe -v error -show_entries stream=codec_type,width,height,r_frame_rate,duration -of csv=p=0 "$OUT"
