#!/bin/bash
# two-pass loudnorm (measured, linear) -> exactly -14 LUFS, true peak <= -1.5
cd "$(dirname "$0")"; IN=${1:-out/mix_raw.wav}; OUT=${2:-public/mix.wav}
J=$(ffmpeg -hide_banner -i "$IN" -af loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json -f null - 2>&1 | sed -n '/^{/,/^}/p')
g(){ echo "$J" | python3 -c "import json,sys;print(json.load(sys.stdin)['$1'])"; }
ffmpeg -v error -y -i "$IN" -af "loudnorm=I=-14:TP=-1.5:LRA=11:measured_I=$(g input_i):measured_TP=$(g input_tp):measured_LRA=$(g input_lra):measured_thresh=$(g input_thresh):offset=$(g target_offset):linear=true,alimiter=limit=0.70:attack=2:release=40:level=false" -ar 48000 "$OUT"
