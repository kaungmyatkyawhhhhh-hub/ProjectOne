"""Cut the boxes out of the owner's three sharp product photos (cut/photo/*.jpg): flat fronts are rectified, the 3D box is masked by its outline."""
import cv2, numpy as np
K = 1932 / 1500
def front(n, quad, w, h, out, r=14):
    im = cv2.imread(f'cut/photo/{n}.jpg'); q = np.float32(quad) * K
    M = cv2.getPerspectiveTransform(q, np.float32([[0, 0], [w, 0], [w, h], [0, h]])); o = cv2.warpPerspective(im, M, (w, h), flags=cv2.INTER_LANCZOS4)
    a = np.zeros((h, w), np.uint8); cv2.rectangle(a, (r, 0), (w - r, h), 255, -1); cv2.rectangle(a, (0, r), (w, h - r), 255, -1)
    for cx, cy in [(r, r), (w - r, r), (w - r, h - r), (r, h - r)]: cv2.circle(a, (cx, cy), r, 255, -1, cv2.LINE_AA)
    cv2.imwrite(f'cut/{out}.png', np.dstack([o, a]))
def poly(n, pts, out):
    im = cv2.imread(f'cut/photo/{n}.jpg'); p = (np.array(pts) * K).astype(np.int32); m = np.zeros(im.shape[:2], np.uint8); cv2.fillPoly(m, [p], 255, cv2.LINE_AA)
    m = cv2.erode(m, np.ones((7, 7), np.uint8)); x, y, w, h = cv2.boundingRect(p); cv2.imwrite(f'cut/{out}.png', np.dstack([im, m])[y:y + h, x:x + w])
front('rob', [(403, 449), (1078, 457), (1056, 1332), (406, 1320)], 760, 990, 'robf')
front('mc', [(288, 698), (1168, 693), (1158, 1557), (313, 1548)], 900, 880, 'mcf')
poly('blox', [(152, 237), (540, 172), (1198, 187), (1203, 888), (850, 1073), (227, 988)], 'blox3d')
def tile(n, x, y, s, name):
    im = cv2.imread(f'cut/photo/{n}.jpg')[y:y + s, x:x + s]; cv2.imwrite('public/dg/' + name + '.jpg', cv2.resize(im, (700, 700), interpolation=cv2.INTER_AREA), [cv2.IMWRITE_JPEG_QUALITY, 93])
tile('rob', 0, 420, 1750, 't_roblox'); tile('mc', 0, 560, 1932, 't_mc'); tile('blox', 0, 150, 1700, 't_blox')
