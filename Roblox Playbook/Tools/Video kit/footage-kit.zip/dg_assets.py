"""Assets for the collage-style ad: clean cut-outs (+ white sticker-outline versions), photo cards, paper textures. Everything comes from the owner's footage or is generated here."""
import cv2, numpy as np, os
rng = np.random.default_rng(7); OUT = 'public/dg/'
MAXD = {'bloxhand': 900, 'mchand': 820, 'bloxstack': 820, 'mcstack': 900, 'robstack': 900, 'sets': 1000, 'sets3': 1000, 'keygreen': 420, 'keymint': 560,
        'pig': 420, 'pig2': 380, 'jeep': 460, 'ladder': 560, 'robcount': 900, 'mccount': 820, 'robf': 800, 'mcf': 860, 'blox3d': 1000}
for n, md in ([] if os.environ.get('TEX') else [(k, v) for k, v in MAXD.items() if not os.environ.get('ONLY') or k in os.environ['ONLY'].split(',')]):
    im = cv2.imread(f'cut/{n}.png', cv2.IMREAD_UNCHANGED); h, w = im.shape[:2]; s = md / max(h, w)
    if s < 1: im = cv2.resize(im, (int(w * s), int(h * s)), interpolation=cv2.INTER_AREA)
    elif s > 1: im = cv2.resize(im, (int(w * s), int(h * s)), interpolation=cv2.INTER_LANCZOS4)
    a = im[..., 3]; a = cv2.erode(a, np.ones((3, 3), np.uint8)); a = cv2.GaussianBlur(a, (0, 0), 1.1); a = np.clip((a.astype(np.float32) - 40) * 255 / 190, 0, 255).astype(np.uint8); im[..., 3] = a
    P = 44; im = cv2.copyMakeBorder(im, P, P, P, P, cv2.BORDER_CONSTANT, value=(0, 0, 0, 0)); cv2.imwrite(OUT + n + '.png', im)
    a = im[..., 3]; r = max(9, int(md * 0.017)); k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1, 2 * r + 1))
    o = cv2.GaussianBlur(cv2.dilate((a > 110).astype(np.uint8) * 255, k), (0, 0), 1.6)            # white sticker outline
    af = a.astype(np.float32)[..., None] / 255; st = np.zeros_like(im); st[..., :3] = (im[..., :3] * af + 255 * (1 - af)).astype(np.uint8); st[..., 3] = np.maximum(o, a)
    cv2.imwrite(OUT + n + '_st.png', st); print(n, im.shape[1], im.shape[0])
for n, w in [('card_price', 620), ('card_stall', 900), ('card_technic', 900), ('card_sets2', 900)]:
    im = cv2.imread(f'cut/{n}.png'); h0, w0 = im.shape[:2]; im = cv2.resize(im, (w, int(h0 * w / w0)), interpolation=cv2.INTER_AREA); cv2.imwrite(OUT + n + '.jpg', im, [cv2.IMWRITE_JPEG_QUALITY, 93]); print(n, im.shape[1], im.shape[0])
# square photo tiles for the stamp cards (real products, centre-cropped)
def tile(src, x, y, s, name):
    im = cv2.imread(f'cut/src/{src}.png')[y:y + s, x:x + s]; cv2.imwrite(OUT + name + '.jpg', cv2.resize(im, (600, 600), interpolation=cv2.INTER_AREA), [cv2.IMWRITE_JPEG_QUALITY, 92])
tile('sets2', 420, 2560, 1000, 't_sets'); tile('keys', 0, 1500, 1500, 't_keys'); tile('cars', 150, 1650, 1250, 't_cars')
# ---- paper ----
H, Wd = 1920, 1080
def fbm(h, w, scales, seed):
    r = np.random.default_rng(seed); out = np.zeros((h, w), np.float32)
    for sc, amp in scales:
        n = r.standard_normal((h // sc + 2, w // sc + 2)).astype(np.float32); out += amp * cv2.resize(n, (w, h), interpolation=cv2.INTER_CUBIC)
    return out
yy, xx = np.mgrid[0:H, 0:Wd].astype(np.float32); rr = np.hypot((xx - Wd / 2) / (Wd * 0.62), (yy - H / 2) / (H * 0.62))
mott = fbm(H, Wd, [(240, 1.0), (90, 0.5), (30, 0.25)], 1); grain = rng.standard_normal((H, Wd)).astype(np.float32)
L = 1.0 - 0.006 * mott - 0.012 * grain - 0.2 * np.clip(rr - 0.45, 0, 1) ** 1.5
base = np.array([249, 224, 236], np.float32)[::-1]                    # pale lilac-pink paper (BGR order below)
paper = np.clip(L[..., None] * base, 0, 255); paper[..., 2] -= 6 * np.clip(rr - 0.5, 0, 1)   # corners drift a touch cooler
fib = np.zeros((H, Wd), np.float32)
for _ in range(260):
    x, y = rng.uniform(0, Wd), rng.uniform(0, H); a = rng.uniform(0, np.pi); l = rng.uniform(8, 34)
    cv2.line(fib, (int(x), int(y)), (int(x + l * np.cos(a)), int(y + l * np.sin(a))), float(rng.uniform(0.3, 1)), 1, cv2.LINE_AA)
paper -= cv2.GaussianBlur(fib, (0, 0), 0.7)[..., None] * 9
cv2.imwrite(OUT + 'paper.jpg', np.clip(paper, 0, 255).astype(np.uint8), [cv2.IMWRITE_JPEG_QUALITY, 94])
# crumpled paper: folded noise -> ridges -> lit from the top-left
f = fbm(H, Wd, [(420, 1.0), (200, 0.55), (90, 0.2)], 5); f = np.abs(f - cv2.GaussianBlur(f, (0, 0), 60)); f = cv2.GaussianBlur(f, (0, 0), 3)
gx = cv2.Sobel(f, cv2.CV_32F, 1, 0, ksize=5); gy = cv2.Sobel(f, cv2.CV_32F, 0, 1, ksize=5); sh = -(gx + gy); sh = sh / (np.abs(sh).max() + 1e-6)
cr = np.clip((1 + 0.14 * np.tanh(sh * 4) - 0.2 * np.clip(rr - 0.45, 0, 1) ** 1.5)[..., None] * base * 0.985 - 3 * grain[..., None], 0, 255)
cv2.imwrite(OUT + 'crumple.jpg', cr.astype(np.uint8), [cv2.IMWRITE_JPEG_QUALITY, 93])
# the real stall, blurred, as the backdrop of the card scenes
st = cv2.imread('cut/src/stall.png'); st = cv2.resize(st, (Wd, H), interpolation=cv2.INTER_AREA); st = cv2.GaussianBlur(st, (0, 0), 16)
g = cv2.cvtColor(st, cv2.COLOR_BGR2GRAY)[..., None].astype(np.float32); st = np.clip((st * 0.5 + g * 0.5) * 1.08 + 26, 0, 255).astype(np.uint8)
cv2.imwrite(OUT + 'stall_blur.jpg', st, [cv2.IMWRITE_JPEG_QUALITY, 90]); print('textures ok')
