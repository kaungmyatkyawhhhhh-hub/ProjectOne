import React, {useEffect, useState} from 'react';
import {AbsoluteFill, Img, staticFile, useCurrentFrame, useVideoConfig, delayRender, continueRender} from 'remotion';

// GYM ARC ad (Roblox game) in the "paper collage trend edit" grammar, section 5c of the pro-video-editing skill. Same building blocks as Dg.tsx.
// Content is the game's own: its recording (clips as 30 fps image sequences inside cards and posters), its UI, its logo and thumbnails, the words on its own screens.
// (header of the shop build follows)
// FlexiToys ad in the "paper collage trend edit" grammar (reference: a luxury-brand trend edit cut to "the kill 2").
// Taken from the reference: the GRAMMAR only (paper intro, cut-outs, big geometric wordmark + glitch serif line, ink scribbles, type scene,
// colour panels, then one collage scene per beat with ribbons, poster, stamp cards, light streaks, blossoms, whips). All content is the shop's own:
// its products cut out of its own footage, its real prices, its own words and colours (purple + yellow).
// Every pixel is a function of t. Beat grid measured on the sound: beat 0.5825 s, first hit 0.086 s, DROP on beat 8 (4.746 s).
export const B = 0.5825, B0 = 0.086, GY_DUR = 12.6;
const bt = (n: number) => B0 + n * B;
const TAU = Math.PI * 2;
const cl = (v: number, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
const seg = (t: number, a: number, b: number) => cl((t - a) / (b - a));
const easeIn = (k: number) => cl(k) ** 3;
const easeOut = (k: number) => 1 - (1 - cl(k)) ** 3;
const sp = (t: number, t0: number, f = 3.4, z = 0.5) => {
  const x = t - t0; if (x <= 0) return 0;
  const w = TAU * f, wd = w * Math.sqrt(1 - z * z);
  return 1 - Math.exp(-z * w * x) * (Math.cos(wd * x) + (z * w / wd) * Math.sin(wd * x));
};
const hit = (t: number, t0: number, d = 0.12) => (t >= t0 ? Math.exp(-(t - t0) / d) : 0);
const rnd = (s: number) => { let a = (s * 2654435761) >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let x = Math.imul(a ^ a >>> 15, 1 | a); x = x + Math.imul(x ^ x >>> 7, 61 | x) ^ x; return ((x ^ x >>> 14) >>> 0) / 4294967296; }; };
const whipE = (x: number) => { const c = cl(x); return c < 0.4 ? 0.5 * (c / 0.4) ** 3 : 1 - 0.5 * ((1 - c) / 0.6) ** 3; };   // fastest ON the beat

// GYM ARC's own colours (read off its logo and UI): ruby red + gold on black. PUR* names are kept from the shop build: PUR = main colour, YEL = accent.
const INK = '#17121a', PUR = '#e8143c', PURD = '#9c0a26', PURK = '#2b0510', YEL = '#ffc21a', YELD = '#ff9a1a', PINK = '#ff2d6f';
const F = (n: string) => staticFile('gy/' + n);
const FONT = [['Sp', 'spartan9.woff2'], ['Jo', 'jost9.woff2'], ['Mo', 'mont9.woff2'], ['M8', 'mont8.woff2'], ['Ab', 'abril.woff2'], ['Al', 'alfa.woff2'], ['Mk', 'marker.woff2'], ['Co', 'corm-i.woff2'], ['Bo', 'bodoni9.woff2'], ['MS', 'mmserif9.woff2']]
  .map(([f, u]) => `@font-face{font-family:${f};src:url(${F(u)})}`).join('') + `@font-face{font-family:MM;src:url(${staticFile('mm-900.woff2')})}`;
const FAMS = ['Sp', 'Jo', 'Mo', 'M8', 'Ab', 'Al', 'Mk', 'Co', 'Bo', 'MS', 'MM'];

// Burmese is animated per SYLLABLE, never per code point
const clusters = (s: string): string[] => {
  const ch = Array.from(s), out: string[] = [], cp = (i: number) => (i >= 0 && i < ch.length ? ch[i].codePointAt(0)! : 0);
  const isCons = (c: number) => (c >= 0x1000 && c <= 0x102a) || c === 0x103f || (c >= 0x104c && c <= 0x104f), isMy = (c: number) => c >= 0x1000 && c <= 0x109f;
  ch.forEach((c, i) => {
    const k = cp(i), n1 = cp(i + 1), n2 = cp(i + 2);
    const killed = n1 === 0x103a || n1 === 0x1039 || (n1 === 0x1037 && n2 === 0x103a);
    const startsNew = !isMy(k) || (isCons(k) && !killed && cp(i - 1) !== 0x1039);
    if (startsNew || out.length === 0 || !isMy(cp(i - 1))) out.push(c); else out[out.length - 1] += c;
  });
  return out;
};
const extrude = (n: number, c: string, dx = 1, dy = 1) => Array.from({length: n}, (_, i) => `${(i + 1) * dx}px ${(i + 1) * dy}px 0 ${c}`).join(',');

// ---------- scene shell: whip / zoom / spin transitions; the incoming scene covers the outgoing one, both move the same way ----------
const DIR: Record<string, [number, number, number]> = {L: [1, 0, 5], R: [-1, 0, -5], U: [0, 1, -4], D: [0, -1, 4], UL: [0.8, 1, 7], DR: [-0.8, -1, -7]};
// Motion blur: the 120 fps blend gives 4 samples per output frame; on a whip those samples are up to ~140 px apart and read as 4 ghost copies.
// So each moving layer also gets a DIRECTIONAL blur (SVG feGaussianBlur with separate x / y radii) sized from its own speed: half the gap between samples.
const MBlur: React.FC<{id: string; sx: number; sy: number}> = ({id, sx, sy}) =>
  <svg width={0} height={0} style={{position: 'absolute'}}><filter id={id} x="-18%" y="-18%" width="136%" height="136%" colorInterpolationFilters="sRGB"><feGaussianBlur stdDeviation={`${Math.min(95, sx).toFixed(1)} ${Math.min(95, sy).toFixed(1)}`}/></filter></svg>;
const Scene: React.FC<{t: number; a: number; b: number; tin?: string; tout?: string; children: React.ReactNode}> = ({t, a, b, tin = 'cut', tout = 'cut', children}) => {
  const wi = tin in DIR, wo = tout in DIR;
  const t0 = wi ? a - 0.10 : tin === 'cut' ? a : a - 0.02, t1 = wo ? b + 0.15 : tout === 'cut' ? b : b + 0.04;
  if (t < t0 || t >= t1) return null;
  const xf = (t: number) => {
    let x = 0, y = 0, r = 0, s = 1, o = 1;
    if (wi) { const k = 1 - whipE(seg(t, a - 0.10, a + 0.15)), d = DIR[tin]; x += d[0] * 1130 * k; y += d[1] * 1980 * k; r += d[2] * k; }
    else if (tin === 'zoom') { const k = 1 - easeOut(seg(t, a - 0.02, a + 0.2)); s *= 1 + 0.2 * k; o = seg(t, a - 0.02, a + 0.015); }
    else if (tin === 'spin') { const k = 1 - easeOut(seg(t, a - 0.02, a + 0.26)); s *= 1 + 0.5 * k; r += -20 * k; o = seg(t, a - 0.02, a + 0.02); }
    if (wo) { const k = whipE(seg(t, b - 0.10, b + 0.15)), d = DIR[tout]; x -= d[0] * 1130 * 0.5 * k; y -= d[1] * 1980 * 0.5 * k; r -= d[2] * 0.6 * k; }
    else if (tout !== 'cut') { s *= 1 + 0.05 * easeIn(seg(t, b - 0.09, b + 0.02)); }
    return {x, y, r, s, o};
  };
  const {x, y, r, s, o} = xf(t), p = xf(t - 1 / 240), q = xf(t + 1 / 240);
  const iso = 0.5 * (Math.abs(q.s - p.s) * 620 + Math.abs(q.r - p.r) * (Math.PI / 180) * 620), sx = 0.5 * Math.abs(q.x - p.x) + iso, sy = 0.5 * Math.abs(q.y - p.y) + iso;
  const id = 'mb' + Math.round((a + 2) * 1000), on = sx > 1.5 || sy > 1.5;
  return <AbsoluteFill style={{transform: `translate(${x.toFixed(1)}px,${y.toFixed(1)}px) rotate(${r.toFixed(2)}deg) scale(${s.toFixed(4)})`, opacity: o, filter: on ? `url(#${id})` : undefined}}>
    {on && <MBlur id={id} sx={sx} sy={sy}/>}
    <AbsoluteFill style={{overflow: 'hidden', background: '#0c0518'}}>{children}</AbsoluteFill>
  </AbsoluteFill>;
};

// ---------- building blocks ----------
const Paper: React.FC<{crumple?: boolean; s?: number; dx?: number; dy?: number}> = ({crumple, s = 1.06, dx = 0, dy = 0}) =>
  <Img src={F(crumple ? 'crumple.jpg' : 'paper.jpg')} style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, transform: `translate(${dx}px,${dy}px) scale(${s})`}}/>;
// a product cut out of the shop's own footage; st = white sticker outline (drop scenes)
const Cut: React.FC<{n: string; x: number; y: number; w: number; rot?: number; st?: boolean; s?: number; glow?: 'ink' | 'white' | 'none'; z?: number; op?: number}> = ({n, x, y, w, rot = 0, st, s = 1, glow = 'ink', z = 0, op = 1}) =>
  <Img src={F(n + (st ? '_st' : '') + '.png')} style={{position: 'absolute', left: x, top: y, width: w, opacity: op,
    transform: `translate(-50%,-50%) translateZ(${z}px) rotate(${rot.toFixed(2)}deg) scale(${s.toFixed(4)})`,
    filter: glow === 'ink' ? 'drop-shadow(0 6px 22px rgba(16,8,24,.6))' : glow === 'white' ? 'drop-shadow(0 0 16px rgba(255,255,255,.8)) drop-shadow(0 22px 26px rgba(28,6,70,.5))' : undefined}}/>;
// scratchy ink zigzag (two passes: a firm line and a hair line), drawn on by k
const zig = (seed: number, x: number, y: number, w: number, h: number, n: number) => {
  const r = rnd(seed), p: string[] = [];
  for (let i = 0; i < n; i++) p.push((x + (i % 2 === 0 ? r() * 0.16 : 0.84 + r() * 0.16) * w).toFixed(1) + ',' + (y + (i / (n - 1)) * h + (r() - 0.5) * h * 0.3).toFixed(1));
  return 'M' + p.join('L');
};
const Scrib: React.FC<{seed: number; x: number; y: number; w: number; h: number; n?: number; k?: number; rot?: number; sw?: number; color?: string}> = ({seed, x, y, w, h, n = 5, k = 1, rot = 0, sw = 3, color = INK}) =>
  <g transform={`rotate(${rot} ${x + w / 2} ${y + h / 2})`} fill="none" stroke={color} strokeLinecap="round" strokeLinejoin="miter">
    <path d={zig(seed, x, y, w, h, n)} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - cl(k)} strokeWidth={sw}/>
    <path d={zig(seed + 7, x - 14, y - 10, w * 1.1, h * 1.15, n + 1)} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - cl(k * 1.2 - 0.2)} strokeWidth={1.3} opacity={0.75}/>
    <path d={zig(seed + 13, x + 20, y + 6, w * 0.9, h * 0.8, n - 1)} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - cl(k * 1.3 - 0.3)} strokeWidth={0.9} opacity={0.6}/>
  </g>;
// tapered brush stroke along a curve (a filled blade, not a stroked line), drawn on by k
const brushD = (x0: number, y0: number, cx: number, cy: number, x1: number, y1: number, w: number, k = 1) => {
  const L: string[] = [], R: string[] = [], N = 26;
  for (let i = 0; i <= N; i++) {
    const s = (i / N) * cl(k), a = 1 - s, x = a * a * x0 + 2 * a * s * cx + s * s * x1, y = a * a * y0 + 2 * a * s * cy + s * s * y1;
    const dx = 2 * a * (cx - x0) + 2 * s * (x1 - cx), dy = 2 * a * (cy - y0) + 2 * s * (y1 - cy), n = Math.hypot(dx, dy) || 1, ww = w * 0.5 * Math.sin(Math.PI * (i / N)) ** 0.7;
    L.push((x - dy / n * ww).toFixed(1) + ',' + (y + dx / n * ww).toFixed(1)); R.unshift((x + dy / n * ww).toFixed(1) + ',' + (y - dx / n * ww).toFixed(1));
  }
  return 'M' + L.join('L') + 'L' + R.join('L') + 'Z';
};
const Svg: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', ...style}}>{children}</svg>;
// a streak of light that travels along a path
const Streak: React.FC<{d: string; t: number; speed?: number; len?: number; w?: number; ph?: number; color?: string}> = ({d, t, speed = 0.9, len = 0.6, w = 13, ph = 0, color = '#ffe45c'}) => {
  const p = ((t * speed + ph) % (1 + len)) - len;
  return <g fill="none" strokeLinecap="round"><path d={d} pathLength={1} stroke={color} strokeWidth={w} strokeDasharray={`${len} 2`} strokeDashoffset={-p} opacity={0.9}/><path d={d} pathLength={1} stroke="#fff" strokeWidth={w * 0.34} strokeDasharray={`${len * 0.8} 2`} strokeDashoffset={-p - len * 0.1}/></g>;
};
const GLOW = 'drop-shadow(0 0 9px rgba(255,226,90,.95)) drop-shadow(0 0 26px rgba(255,170,30,.7))';
const Spark: React.FC<{x: number; y: number; s: number; t: number; ph?: number}> = ({x, y, s, t, ph = 0}) => {
  const k = 0.5 + 0.5 * Math.sin((t * 2.6 + ph) * TAU);
  return <path transform={`translate(${x} ${y}) rotate(${(t * 50 + ph * 90).toFixed(1)}) scale(${(s * (0.45 + 0.55 * k)).toFixed(2)})`} d="M0,-1 Q.09,-.09 1,0 Q.09,.09 0,1 Q-.09,.09 -1,0 Q-.09,-.09 0,-1Z" fill="#fff"/>;
};
// blossom (the stall's own banner is covered in spring flowers); blurred ones sit in the foreground for depth
const Flower: React.FC<{x: number; y: number; s: number; rot?: number; blur?: number; op?: number; c?: string}> = ({x, y, s, rot = 0, blur = 0, op = 1, c = '#ffe1f0'}) =>
  <svg width={2 * s} height={2 * s} viewBox="-1.1 -1.1 2.2 2.2" style={{position: 'absolute', left: x - s, top: y - s, opacity: op, filter: blur ? `blur(${blur}px)` : undefined, overflow: 'visible'}}>
    <g transform={`rotate(${rot.toFixed(1)})`}>{[0, 1, 2, 3, 4].map(i => <ellipse key={i} cx={0} cy={-0.54} rx={0.35} ry={0.5} transform={`rotate(${i * 72})`} fill={c} stroke="#ff86bf" strokeWidth={0.035}/>)}
      {[0, 1, 2, 3, 4].map(i => <line key={'l' + i} x1={0} y1={-0.12} x2={0} y2={-0.5} transform={`rotate(${i * 72})`} stroke="#ff6fb0" strokeWidth={0.03}/>)}<circle r={0.17} fill="#ffc930"/></g>
  </svg>;
const Blossoms: React.FC<{t: number; seed: number; at: [number, number, number][]}> = ({t, seed, at}) => {
  const r = rnd(seed);
  return <>{at.map(([x, y, s], i) => { const ph = r() * TAU, bl = s > 150 ? 9 : s > 100 ? 5 : 2; return <Flower key={i} x={x + Math.sin(t * 1.3 + ph) * 16} y={y + Math.cos(t * 1.1 + ph) * 12} s={s} rot={r() * 72 + t * (20 + r() * 30)} blur={bl} op={s > 150 ? 0.92 : 1}/>; })}</>;
};
const Hazard: React.FC<{y: number; h?: number; t: number}> = ({y, h = 46, t}) =>
  <div style={{position: 'absolute', left: -100, top: y, width: 1280, height: h, background: `repeating-linear-gradient(-45deg, ${YEL} 0 30px, ${PURK} 30px 60px)`, backgroundPosition: `${(t * 120).toFixed(1)}px 0`, boxShadow: '0 -6px 24px rgba(20,5,50,.35)'}}/>;
// glitch serif line: the text + 3 displaced slices + hairlines that change every 2 output frames
const Glitch: React.FC<{parts: string[]; font: string; size: number; color?: string; t: number; seed: number; gap?: number; amt?: number; shadow?: string}> = ({parts, font, size, color = INK, t, seed, gap = 0.16, amt = 1, shadow = '0 3px 10px rgba(16,8,24,.45)'}) => {
  const r = rnd(seed * 977 + Math.floor(t * 15)), on = r() < 0.7;
  const row = (st: React.CSSProperties, key?: string) => <div key={key} style={{display: 'flex', gap: size * gap, justifyContent: 'center', whiteSpace: 'nowrap', ...st}}>{parts.map((p, i) => <span key={i}>{p}</span>)}</div>;
  return <div style={{position: 'relative', fontFamily: font, fontSize: size, lineHeight: 1.25, color, textShadow: shadow}}>
    {row({})}
    {on && [0, 1, 2].map(i => { const y0 = r() * 78, h = 7 + r() * 15, dx = (r() - 0.5) * size * 0.34 * amt; return row({position: 'absolute', left: 0, right: 0, top: 0, clipPath: `inset(${y0}% -20% ${100 - y0 - h}% -20%)`, transform: `translateX(${dx.toFixed(1)}px)`, background: 'transparent'}, 's' + i); })}
    {on && [0, 1].map(i => <div key={'h' + i} style={{position: 'absolute', left: `${-8 + r() * 30}%`, width: `${35 + r() * 55}%`, top: `${12 + r() * 76}%`, height: 2, background: color, opacity: 0.8}}/>)}
  </div>;
};
// the big geometric wordmark: near-black, soft dark halo, a thin top-left highlight (the embossed look), and a light sweep
const Mark: React.FC<{lines: string[]; size: number; t: number; sweep: number; light?: boolean}> = ({lines, size, sweep, light}) => {
  const body = (st: React.CSSProperties) => <div style={{fontFamily: 'Sp', fontSize: size, lineHeight: 0.86, letterSpacing: '-0.01em', textAlign: 'center', whiteSpace: 'nowrap', ...st}}>{lines.map((l, i) => <div key={i}>{l}</div>)}</div>;
  return <div style={{position: 'relative'}}>
    {body(light ? {color: '#fff', textShadow: `${extrude(9, PURD)}, 0 0 46px rgba(170,100,255,.9), 0 0 110px rgba(140,70,255,.6)`}
      : {color: INK, textShadow: `-1.5px -2px 0 rgba(255,255,255,.55), 2px 3px 0 rgba(0,0,0,.55), 0 0 ${size * 0.09}px rgba(18,8,24,.55), 0 ${size * 0.05}px ${size * 0.12}px rgba(18,8,24,.4)`})}
    {sweep > 0 && sweep < 1 && <div style={{position: 'absolute', inset: 0}}>{body({color: 'transparent', backgroundImage: `linear-gradient(105deg, rgba(255,255,255,0) 42%, rgba(255,255,255,${light ? 0.95 : 0.6}) 50%, rgba(255,255,255,0) 58%)`, backgroundSize: '300% 100%', backgroundPosition: `${lerp(100, 0, sweep).toFixed(1)}% 0`, WebkitBackgroundClip: 'text', backgroundClip: 'text'})}</div>}
  </div>;
};
const At: React.FC<{x: number; y: number; children: React.ReactNode; tf?: string; z?: number}> = ({x, y, children, tf = '', z}) =>
  <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) ${tf}`, zIndex: z}}>{children}</div>;
// postage-stamp card: white card, perforated purple edge, a real photo, a big label over it
const SHINE = 'linear-gradient(110deg, rgba(255,255,255,0) 40%, rgba(255,255,255,.8) 50%, rgba(255,255,255,0) 60%)';
const Shine: React.FC<{k: number}> = ({k}) => (k > 0 && k < 1 ? <div style={{position: 'absolute', inset: 0, backgroundImage: SHINE, backgroundSize: '300% 100%', backgroundPosition: `${lerp(100, 0, k).toFixed(1)}% 0`, pointerEvents: 'none'}}/> : null);
const Stamp: React.FC<{w: number; h: number; img: string; label?: string; ls?: number; sub?: string; fit?: string; shine?: number}> = ({w, h, img, label, ls = 56, sub, fit = 'cover', shine = 0}) =>
  <div style={{width: w, height: h, borderRadius: 22, background: `radial-gradient(circle, ${PUR} 7px, rgba(0,0,0,0) 7.7px) -12px -12px / 24px 24px, #fff`, boxShadow: '0 34px 50px rgba(20,5,50,.5), 0 0 30px rgba(255,255,255,.35)', position: 'relative'}}>
    <div style={{position: 'absolute', inset: 14, borderRadius: 10, background: '#fff', overflow: 'hidden'}}>
      <Img src={F(img)} style={{position: 'absolute', left: 0, top: 0, width: '100%', height: sub ? '82%' : '100%', objectFit: fit as any}}/>
      {label && <div style={{position: 'absolute', left: 14, right: 8, bottom: sub ? '21%' : 10, fontFamily: 'Mo', fontSize: ls, lineHeight: 0.95, color: '#fff', letterSpacing: '-0.01em', whiteSpace: 'pre-line', textShadow: `${extrude(4, PURD)}, 0 6px 16px rgba(10,0,30,.75)`}}>{label}</div>}
      {sub && <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: '18%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'M8', fontSize: Math.round(w * 0.066), color: PURK, letterSpacing: '0.04em', background: '#fff'}}>{sub}</div>}
      <Shine k={shine}/>
    </div>
  </div>;

// ================= GYM ARC scenes =================
// a gameplay clip = 30 jpg frames (1 s, already speed-ramped in gy_assets.py); lt = seconds since the scene's beat
const clipF = (n: string, lt: number) => `${n}/${String(Math.round(cl(Math.floor((lt + 0.12) * 30) + 1, 1, 30))).padStart(2, '0')}.jpg`;
// a photo print on the paper: white border, soft shadow
const Print: React.FC<{img: string; w: number; h: number}> = ({img, w, h}) =>
  <div style={{width: w, height: h, padding: 16, background: '#fff', boxSizing: 'border-box', boxShadow: '0 10px 34px rgba(16,8,24,.55), 0 0 0 1px rgba(0,0,0,.08)'}}><Img src={F(img)} style={{width: '100%', height: '100%', objectFit: 'cover', display: 'block'}}/></div>;
// ruby shards (the logo is covered in them); blurred ones sit in the foreground for depth
const Shard: React.FC<{x: number; y: number; s: number; rot?: number; blur?: number; c?: string}> = ({x, y, s, rot = 0, blur = 0, c = PINK}) =>
  <svg width={2 * s} height={2 * s} viewBox="-1.1 -1.1 2.2 2.2" style={{position: 'absolute', left: x - s, top: y - s, filter: blur ? `blur(${blur}px)` : undefined, overflow: 'visible'}}>
    <g transform={`rotate(${rot.toFixed(1)})`}><polygon points="0,-1 .62,-.36 .62,.36 0,1 -.62,.36 -.62,-.36" fill={c} stroke="#fff" strokeWidth={0.04}/>
      <polygon points="0,-1 .62,-.36 0,-.1 -.62,-.36" fill="rgba(255,255,255,.55)"/><polygon points="0,1 .62,.36 0,.1" fill="rgba(60,0,20,.35)"/><polygon points="-.62,-.36 0,-.1 0,.1 -.62,.36" fill="rgba(255,255,255,.18)"/></g>
  </svg>;
const Shards: React.FC<{t: number; seed: number; at: [number, number, number][]}> = ({t, seed, at}) => {
  const r = rnd(seed);
  return <>{at.map(([x, y, s], i) => { const ph = r() * TAU, bl = s > 150 ? 9 : s > 100 ? 5 : 2; return <Shard key={i} x={x + Math.sin(t * 1.3 + ph) * 16} y={y + Math.cos(t * 1.1 + ph) * 12} s={s} rot={r() * 60 - 30 + t * (16 + r() * 26)} blur={bl} c={i % 3 === 1 ? YEL : PINK}/>; })}</>;
};
const Logo: React.FC<{w: number; glow?: boolean}> = ({w, glow}) =>
  <Img src={F('logo.png')} style={{width: w, display: 'block', filter: glow ? 'drop-shadow(0 0 40px rgba(255,60,110,.85)) drop-shadow(0 0 110px rgba(255,40,90,.5))' : 'drop-shadow(0 10px 26px rgba(16,8,24,.55))'}}/>;
const Arrow: React.FC = () => <svg viewBox="0 0 1 1" style={{width: '0.8em', height: '0.8em', verticalAlign: '-0.08em', margin: '0 0.14em'}} fill="none" stroke="currentColor" strokeWidth={0.15} strokeLinecap="round" strokeLinejoin="round"><path d="M.06,.5 H.9 M.56,.2 L.9,.5 L.56,.8"/></svg>;
const GRAD = (deg: number) => `linear-gradient(${deg}deg, #fff0a0 0%, ${YEL} 15%, #ff7a3c 33%, ${PINK} 52%, ${PUR} 72%, ${PURD} 100%)`;
const BAND = 'linear-gradient(180deg, #5e0719, #a30d2c 50%, #5e0719)';

// 0 · hook: the payoff on frame 1 - the growth flash at 7'0"
const Hook: React.FC<{t: number}> = ({t}) => {
  const k = sp(t, -0.14, 3.2, 0.5), d = seg(t, -0.05, 0.3);
  return <>
    <Paper dx={-10 + t * 30}/>
    <Svg><path d={brushD(170, 760, 470, 250, 930, 600, 40, 0.6 + 0.4 * d)} fill={INK}/><path d={brushD(250, 1210, 400, 1280, 610, 1220, 16, d)} fill={INK}/>
      <Scrib seed={3} x={660} y={1130} w={360} h={130} k={d} rot={-8}/><Scrib seed={5} x={50} y={230} w={420} h={170} n={6} k={d} rot={-14}/><Scrib seed={9} x={600} y={1590} w={420} h={200} n={6} k={d} rot={-10} sw={2.4}/></Svg>
    <Cut n="lifter" x={540} y={770} w={1000} rot={lerp(-10, -2, k) + t * 4} s={lerp(0.8, 1, k) * (1 + t * 0.07)}/>
    <At x={540} y={1380}><Glitch parts={['GET', 'HUGE']} font="Ab" size={150} t={t} seed={1} gap={0.3}/></At>
    <At x={540} y={1520}><div style={{fontFamily: 'M8', fontSize: 50, letterSpacing: '0.1em', color: INK, opacity: 0.85 * seg(t, -0.1, 0.02), whiteSpace: 'nowrap'}}>5'8"<Arrow/>7'0"</div></At>
  </>;
};
// 1 / 4 · the game's own logo on paper
const MarkScene: React.FC<{t: number; a: number; v: number}> = ({t, a, v}) => {
  const lt = t - a, k = sp(t, a - 0.06, 3.4, 0.48), z = 1 + lt * 0.07, cuts = v === 0
    ? [['rep', 260, 400, 400, -10], ['hero', 840, 420, 320, 10], ['p455', 850, 1500, 330, 6]] as const
    : [['growpop', 300, 410, 500, -8], ['goldarms', 870, 420, 230, 8], ['rep', 840, 1500, 360, -6]] as const;
  return <>
    <Paper dx={v ? 14 : -6} dy={lt * -20}/>
    <div style={{position: 'absolute', inset: 0, transform: `scale(${z.toFixed(4)}) rotate(${(v ? 0.6 : -0.6) * lt * 2}deg)`}}>
      <Svg><Scrib seed={11 + v} x={30} y={150} w={470} h={250} n={6} k={seg(lt, -0.02, 0.22)} rot={-14}/><Scrib seed={21 + v} x={60} y={1420} w={470} h={270} n={6} k={seg(lt, 0.04, 0.3)} rot={-12}/><Scrib seed={25 + v} x={640} y={1210} w={360} h={120} n={5} k={seg(lt, 0.06, 0.3)} rot={8} sw={2.2}/>
        <path d={brushD(60, 1560, 300, 1480, 520, 1620, 12, seg(lt, 0.05, 0.3))} fill={INK}/></Svg>
      {cuts.map(([n, x, y, w, rot], i) => { const kk = sp(t, a - 0.04 + i * 0.05, 3.6, 0.5); return <Cut key={n} n={n} x={x} y={y + (1 - kk) * -40} w={w} rot={rot + (1 - kk) * 20} s={kk}/>; })}
      <At x={550} y={880} tf={`scale(${lerp(1.3, 1, k).toFixed(4)}) rotate(${(v ? 2 : -2)}deg)`}><Logo w={900}/></At>
      <At x={540} y={1300}><Glitch parts={v ? ['NO', 'DAYS', 'OFF'] : ['PLAY', 'ON', 'ROBLOX']} font="Ab" size={86} t={t} seed={4 + v} gap={0.34}/></At>
      <At x={52} y={900} tf="rotate(-90deg)"><Glitch parts={v ? ['PLAY', 'ON', 'ROBLOX'] : ['NO', 'DAYS', 'OFF']} font="Ab" size={38} t={t} seed={8 + v} gap={0.4}/></At>
    </div>
  </>;
};
// 2-3 · what you do, one thing per half beat
const CutScene: React.FC<{t: number; a: number; i: number}> = ({t, a, i}) => {
  const lt = t - a, k = sp(t, a - 0.05, 3.8, 0.5), sgn = i % 2 ? 1 : -1, cap = ['LIFT', 'GROW', 'EVOLVE', 'COMPETE'][i];
  return <>
    <Paper dx={sgn * 12} dy={i * -8} s={1.08}/>
    <Svg><Scrib seed={30 + i} x={sgn > 0 ? 80 : 620} y={300 + i * 30} w={380} h={170} k={seg(lt, -0.02, 0.16)} rot={sgn * 12}/>
      <path d={brushD(sgn > 0 ? 880 : 200, 1210, 540, 1290, sgn > 0 ? 260 : 820, 1190, 20, seg(lt, 0, 0.18))} fill={INK}/></Svg>
    <div style={{position: 'absolute', inset: 0, transform: `scale(${(lerp(0.86, 1, k) * (1 + lt * 0.1)).toFixed(4)}) rotate(${(sgn * lerp(9, 3, k)).toFixed(2)}deg)`, transformOrigin: '540px 800px'}}>
      {i === 0 && <At x={540} y={780}><Print img={clipF('bench', lt)} w={860} h={620}/></At>}
      {i === 1 && <At x={540} y={780}><Print img={clipF('grow', lt)} w={860} h={620}/></At>}
      {i === 2 && <Cut n="volta" x={540} y={780} w={960}/>}
      {i === 3 && <At x={540} y={780}><Print img={clipF('stone', lt)} w={860} h={620}/></At>}
    </div>
    <At x={540} y={1400}><Glitch parts={[cap]} font="Ab" size={132} t={t} seed={40 + i} gap={0.3} amt={1.3}/></At>
  </>;
};
// 5-6 · type scene, in the game's own words
const TypeScene: React.FC<{t: number; a: number}> = ({t, a}) => {
  const lt = t - a, words = ['NO', 'DAYS', 'OFF.'], t2 = a + B;
  return <>
    <Paper dx={-lt * 26} s={1.1}/>
    <Svg style={{filter: 'blur(1.2px)'}}><path d={brushD(-80, 1500, 380, 1050, 1180, 760, 30, seg(lt, 0, 0.3))} fill={INK}/><path d={brushD(-60, 1150, 300, 1330, 1200, 1500, 22, seg(lt, 0.06, 0.4))} fill={INK} opacity={0.9}/></Svg>
    <Svg><path d={brushD(60, 430, 300, 760, 420, 1700, 8, seg(lt, 0.02, 0.36))} fill={INK}/><path d={brushD(20, 620, 420, 900, 1100, 1010, 5, seg(lt, 0.1, 0.5))} fill={INK}/>
      <Scrib seed={51} x={640} y={1260} w={380} h={220} k={seg(lt, 0.1, 0.4)} rot={-10} sw={2.4}/></Svg>
    <div style={{position: 'absolute', left: 110 - lt * 14, top: 690, display: 'flex', gap: 14}}>{[PUR, YEL].map((c, i) => { const kk = sp(t, a + 0.04 + i * 0.06, 4, 0.45); return <div key={c} style={{width: 40, height: 40, borderRadius: 9, background: c, transform: `scale(${kk.toFixed(3)}) rotate(${((1 - kk) * 40).toFixed(1)}deg)`, boxShadow: '0 6px 12px rgba(16,8,24,.35)'}}/>; })}</div>
    <div style={{position: 'absolute', left: 96 - lt * 14, top: 746, display: 'flex', gap: 34, fontFamily: 'Mo', fontSize: 114, lineHeight: 1.2, color: INK, whiteSpace: 'nowrap', textShadow: '-1px -2px 0 rgba(255,255,255,.5), 0 14px 22px rgba(16,8,24,.5), 0 30px 46px rgba(16,8,24,.28)'}}>
      {words.map((p, i) => { const kk = sp(t, a - 0.04 + i * 0.07, 3.6, 0.52); return <span key={i} style={{display: 'inline-block', transform: `translate(${((1 - kk) * 90).toFixed(1)}px,0) skewX(${((1 - kk) * -14).toFixed(1)}deg)`, opacity: cl(kk * 3)}}>{p}</span>; })}
    </div>
    <div style={{position: 'absolute', left: 296 - lt * 14, top: 896, width: 330 * easeOut(seg(lt, 0.2, 0.4)), height: 11, borderRadius: 5, background: PUR, boxShadow: '0 4px 10px rgba(150,10,40,.4)'}}/>
    <div style={{position: 'absolute', right: 100 + lt * 10, top: 940, fontFamily: 'Al', fontSize: 62, color: PUR, whiteSpace: 'nowrap', opacity: seg(t, t2 - 0.03, t2 + 0.03), transform: `translate(${((1 - sp(t, t2 - 0.05, 3.6, 0.5)) * -120).toFixed(1)}px,0)`, textShadow: '0 8px 16px rgba(110,8,30,.45), -1px -1px 0 rgba(255,255,255,.5)'}}>EVERYONE STARTS TINY</div>
  </>;
};
// 7 · panels: the REP button's word in marker, then the real weight on the bar
const Panels: React.FC<{t: number; a: number}> = ({t, a}) => {
  const k1 = whipE(seg(t, a - 0.10, a + 0.15)), a2 = a + B / 2, k2 = whipE(seg(t, a2 - 0.10, a2 + 0.15));
  if (t < a - 0.10) return null;
  const h = 1 / 240, b1 = 0.5 * 420 * Math.abs(whipE(seg(t + h, a - 0.10, a + 0.15)) - whipE(seg(t - h, a - 0.10, a + 0.15))), b2 = 0.5 * 1960 * Math.abs(whipE(seg(t + h, a2 - 0.10, a2 + 0.15)) - whipE(seg(t - h, a2 - 0.10, a2 + 0.15)));
  return <>
    {b1 > 1.5 && <MBlur id="mbp1" sx={b1} sy={0}/>}{b2 > 1.5 && <MBlur id="mbp2" sx={0} sy={b2}/>}
    <div style={{position: 'absolute', left: 0, top: 0, width: 400, height: 1920, transform: `translate(${((k1 - 1) * 420).toFixed(1)}px,0)`, filter: b1 > 1.5 ? 'url(#mbp1)' : undefined, background: `linear-gradient(180deg, #b90f31, ${PUR} 55%, #ff3d63)`, boxShadow: '18px 0 40px rgba(40,4,14,.45)', overflow: 'hidden'}}>
      {['R', 'E', 'P'].map((c, i) => { const kk = sp(t, a - 0.02 + i * 0.09, 3.6, 0.45); return <div key={c} style={{position: 'absolute', left: 0, width: 400, top: 250 + i * 440, textAlign: 'center', fontFamily: 'Mk', fontSize: 400, lineHeight: 1, color: PURK, transform: `scale(${kk.toFixed(3)}) rotate(${(i - 1) * -7 + (1 - kk) * 30}deg)`, textShadow: '7px 9px 0 rgba(255,194,26,.95), 0 20px 30px rgba(30,0,10,.4)'}}>{c}</div>; })}
    </div>
    <div style={{position: 'absolute', left: 400, top: 0, width: 372, height: 1920, transform: `translate(0,${((k2 - 1) * 1960).toFixed(1)}px)`, filter: b2 > 1.5 ? 'url(#mbp2)' : undefined, background: `linear-gradient(180deg, #ffe36a, ${YEL} 50%, ${YELD})`, boxShadow: '18px 0 40px rgba(40,4,14,.4)', overflow: 'hidden'}}>
      {['455', 'LB'].map((c, i) => { const kk = sp(t, a2 - 0.06 + i * 0.06, 4.2, 0.55); return <div key={c} style={{position: 'absolute', left: 0, width: 372, top: 470 + i * 360, textAlign: 'center', fontFamily: 'Co', fontSize: i ? 250 : 236, lineHeight: 1, color: PURD, transform: `translate(0,${((1 - kk) * 80).toFixed(1)}px)`, opacity: cl(kk * 2)}}>{c}</div>; })}
      <svg width={372} height={1920} style={{position: 'absolute', left: 0, top: 0}} fill="none" stroke={PURD} strokeWidth={2.2} strokeLinecap="round">
        <path d="M60,320 q40,-70 90,-10 q-60,10 -90,10 M150,310 q30,-60 80,-30 q-40,30 -80,30 M72,1300 q60,40 120,-6 M300,370 l0,60 M270,400 l60,0 M70,1420 l0,50 M45,1445 l50,0 M290,1380 q-40,-50 -8,-90 q40,40 8,90"/></svg>
      <div style={{position: 'absolute', left: 0, width: 372, top: 1560, textAlign: 'center', fontFamily: 'M8', fontSize: 28, letterSpacing: '0.22em', color: PURD}}>PRO FLAT BENCH</div>
    </div>
  </>;
};
// drop · diagonal ribbon collage
const Ribbon: React.FC<{t: number; a: number; v: number}> = ({t, a, v}) => {
  const lt = t - a, flip = v ? -1 : 1, ry = lerp(-9, 7, seg(lt, -0.1, B + 0.15)) * flip, word = v ? 'Strongman' : 'GYM ARC';
  const pop = (i: number) => sp(t, a - 0.06 + i * 0.05, 3.4, 0.5);
  const cuts = v === 0 ? [['giant', 720, 1270, 760, 6, 160], ['hero', 290, 500, 480, -10, 60], ['rep', 270, 1090, 400, 8, 110]] as const
    : [['hero', 780, 470, 500, 10, 60], ['goldarms', 850, 1160, 330, 6, 120]] as const;
  return <div style={{position: 'absolute', inset: 0, perspective: 1500, background: PURD}}>
    <div style={{position: 'absolute', inset: -140, transformStyle: 'preserve-3d', transform: `rotateY(${ry.toFixed(2)}deg) rotateX(${(3 - lt * 4).toFixed(2)}deg) scale(${(1.02 + lt * 0.07).toFixed(4)})`}}>
      <div style={{position: 'absolute', inset: -300, transform: 'translateZ(-260px)', background: GRAD(v ? 215 : 145)}}/>
      <div style={{position: 'absolute', left: 140, top: 140, width: 1080, height: 1920, transformStyle: 'preserve-3d'}}>
        <div style={{position: 'absolute', left: 540, top: 1010, width: 3000, height: 340, marginLeft: -1500, marginTop: -170, transform: `translateZ(-60px) rotate(${-38 * flip}deg)`, background: BAND, borderTop: `10px solid ${YEL}`, borderBottom: '10px solid rgba(255,255,255,.75)', boxShadow: '0 30px 60px rgba(50,2,14,.5)', overflow: 'hidden'}}>
          <div style={{position: 'absolute', left: 0, top: 16, whiteSpace: 'nowrap', fontFamily: 'Ab', fontSize: 270, lineHeight: 1, color: PURK, opacity: 0.86, filter: 'blur(1.6px)', transform: `translate(${(-420 - lt * 330 * flip).toFixed(1)}px,0)`}}>{(word + '  ·  ').repeat(7)}</div>
        </div>
        <div style={{position: 'absolute', left: 540, top: 1010, width: 3000, height: 36, marginLeft: -1500, marginTop: 250, transform: `translateZ(-30px) rotate(${-38 * flip}deg)`, background: 'rgba(255,255,255,.55)'}}/>
        <Svg style={{filter: GLOW, transform: 'translateZ(40px)'}}>
          <Streak d="M-60,700 C200,300 620,260 700,560 C760,820 300,900 180,640 C100,440 420,300 600,420" t={t} ph={0.1 + v * 0.3}/>
          <Streak d="M1160,900 C900,1000 420,1180 120,1700 C60,1800 200,1880 420,1790" t={t} ph={0.6} speed={1.1} w={7}/>
          <Streak d="M380,1500 C600,1280 1040,1300 1000,1560 C960,1760 620,1760 560,1600" t={t} ph={0.3} speed={1.3} w={6} color="#fff"/>
        </Svg>
        {v === 1 && <div style={{position: 'absolute', left: 350, top: 960, transform: `translate(-50%,-50%) translateZ(150px) rotateY(14deg) rotateZ(${(-7 + (1 - pop(0)) * 20).toFixed(2)}deg) scale(${lerp(0.6, 1, pop(0)).toFixed(3)})`}}>
          <Stamp w={600} h={560} img={clipF('stone', lt)} label={'ATLAS\nSTONES'} ls={70} sub="New record · 540 LB" shine={seg(lt, 0.1, 0.46)}/></div>}
        {cuts.map(([n, x, y, w, rot, z], i) => { const kk = pop(i + (v ? 1 : 0)); return <Cut key={n} n={n} st glow="white" x={x} y={y} w={w} z={z} rot={rot + (1 - kk) * 16 + lt * 5 * (i % 2 ? -1 : 1)} s={lerp(0.6, 1, kk)}/>; })}
        <Svg style={{transform: 'translateZ(180px)'}}><Spark x={860} y={420} s={34} t={t}/><Spark x={170} y={900} s={24} t={t} ph={0.4}/><Spark x={620} y={1640} s={30} t={t} ph={0.7}/><Spark x={960} y={980} s={18} t={t} ph={0.2}/><Spark x={420} y={300} s={16} t={t} ph={0.55}/></Svg>
      </div>
    </div>
    <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(circle at 14% 10%, rgba(255,250,210,.6), rgba(255,250,210,0) 46%), radial-gradient(circle at 92% 88%, rgba(255,170,200,.35), rgba(255,170,200,0) 40%)', mixBlendMode: 'screen', pointerEvents: 'none'}}/>
    <Hazard y={1856} t={t}/>
    {v === 1 && <At x={540} y={1560}><div style={{fontFamily: 'Mo', fontSize: 84, lineHeight: 1.05, color: '#fff', textAlign: 'center', whiteSpace: 'nowrap', textShadow: `${extrude(7, PURK)}, 0 14px 26px rgba(40,0,10,.6)`, transform: `scale(${sp(t, a - 0.02, 3.4, 0.5).toFixed(3)}) rotate(-3deg)`}}>STRONGMAN<br/><span style={{color: YEL}}>SHOWDOWN</span></div></At>}
    <Shards t={t} seed={60 + v} at={v ? [[990, 150, 180], [880, 70, 100], [1040, 330, 80], [60, 1730, 160], [190, 1840, 90]] : [[80, 140, 180], [220, 60, 100], [40, 330, 80], [1010, 1700, 160], [900, 1830, 90]]}/>
  </div>;
};
// drop · poster with a gameplay window and a real number from the screen
const Poster: React.FC<{t: number; a: number; v: number}> = ({t, a, v}) => {
  const lt = t - a, k = sp(t, a - 0.06, 3.2, 0.5), ry = lerp(15, -7, seg(lt, -0.1, B + 0.15)) * (v ? -1 : 1);
  const title = v ? 'GROWTH SPURT' : 'FLAT BENCH', clip = v ? 'grow' : 'bench', bar = v ? <>5'8"<Arrow/>7'0"</> : '455 LB', sub = v ? 'TAP TO GROW' : 'REP · REP · REP';
  return <div style={{position: 'absolute', inset: 0, perspective: 1500, background: 'linear-gradient(180deg,#f0e6e8,#d8c9cd)'}}>
    {[[-80, 300, 0.75], [900, 300, 0.7], [-160, 160, 0.5], [1050, 140, 0.5]].map(([x, w, o], i) => <div key={i} style={{position: 'absolute', left: x + (i % 2 ? -1 : 1) * lt * 60, top: -100, width: w, height: 2120, background: `rgba(40,14,22,${o})`, filter: 'blur(26px)'}}/>)}
    <div style={{position: 'absolute', left: 150, top: 300, width: 780, height: 1290, transformStyle: 'preserve-3d', transform: `rotateY(${ry.toFixed(2)}deg) rotateX(${(4 - lt * 5).toFixed(2)}deg) scale(${(lerp(0.8, 1, k) * (1 + lt * 0.06)).toFixed(4)})`}}>
      <div style={{position: 'absolute', inset: 0, background: `linear-gradient(180deg,#fff0a0, ${YEL} 45%, ${YELD})`, boxShadow: '0 50px 80px rgba(40,8,16,.5), 0 0 60px rgba(255,210,90,.5)', overflow: 'hidden'}}>
        <svg width={780} height={1290} style={{position: 'absolute', left: 0, top: 0}}><polygon transform={`translate(390 640) rotate(${(lt * 30).toFixed(1)}) scale(470)`} points={Array.from({length: 10}, (_, i) => { const r = i % 2 ? 0.42 : 1, an = i * TAU / 10 - TAU / 4; return `${(r * Math.cos(an)).toFixed(3)},${(r * Math.sin(an)).toFixed(3)}`; }).join(' ')} fill="rgba(255,255,255,.42)"/></svg>
        <div style={{position: 'absolute', left: 0, right: 0, top: 54, textAlign: 'center', fontFamily: 'Bo', fontSize: v ? 74 : 92, letterSpacing: '0.1em', color: PURK, whiteSpace: 'nowrap', textShadow: '0 4px 10px rgba(60,20,0,.3)'}}>{title}</div>
        <div style={{position: 'absolute', left: 60, right: 60, top: 176, height: 5, background: PURK}}/>
        <div style={{position: 'absolute', left: 0, right: 0, top: 196, textAlign: 'center', fontFamily: 'M8', fontSize: 30, letterSpacing: '0.5em', color: PURK}}>{sub}</div>
        <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 210, background: `linear-gradient(180deg, ${PUR}, ${PURD})`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Al', fontSize: v ? 104 : 132, color: '#fff', textShadow: `${extrude(6, PURK)}, 0 10px 20px rgba(40,0,10,.5)`, whiteSpace: 'nowrap'}}>
          <span style={{transform: `scale(${sp(t, a + 0.06, 3.6, 0.45).toFixed(3)})`, display: 'inline-block'}}>{bar}</span></div>
        <Shine k={seg(lt, 0.1, 0.5)}/>
      </div>
      <svg width={780} height={1290} viewBox="0 0 780 1290" style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', filter: GLOW, transform: 'translateZ(70px)'}}>
        <Streak d="M390,300 C800,300 840,960 390,1000 C-60,960 -20,300 390,300" t={t} speed={1.5} len={0.5} ph={v * 0.4}/>
        <Streak d="M90,760 C170,380 630,340 720,640 C790,940 280,1060 130,840" t={t} speed={1.2} len={0.4} ph={0.5} w={6} color="#fff"/></svg>
      <div style={{position: 'absolute', left: 390, top: 655, transform: `translate(-50%,-50%) translateZ(140px) rotate(${(lerp(-10, 3, k) + lt * 6).toFixed(2)}deg) scale(${lerp(0.5, 1, k).toFixed(3)})`, filter: 'drop-shadow(0 0 18px rgba(255,255,255,.85)) drop-shadow(0 30px 30px rgba(60,10,20,.5))'}}>
        <div style={{width: 700, height: 500, border: '12px solid #fff', borderRadius: 26, overflow: 'hidden', boxSizing: 'border-box', background: '#000'}}><Img src={F(clipF(clip, lt))} style={{width: '100%', height: '100%', objectFit: 'cover', display: 'block'}}/></div></div>
      <svg width={780} height={1290} viewBox="0 0 780 1290" style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', transform: 'translateZ(200px)'}}><Spark x={690} y={360} s={30} t={t}/><Spark x={90} y={930} s={24} t={t} ph={0.5}/><Spark x={700} y={960} s={18} t={t} ph={0.25}/></svg>
    </div>
    <Shards t={t} seed={70 + v} at={v ? [[980, 210, 190], [1040, 420, 100], [870, 90, 80], [90, 1700, 170], [230, 1830, 90]] : [[90, 210, 190], [40, 420, 100], [210, 90, 80], [990, 1700, 170], [850, 1830, 90]]}/>
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 44, background: PUR}}/>
  </div>;
};
// drop · four stamp cards with live gameplay, tilted around a turning sticker, over the gym (blurred)
const Cards: React.FC<{t: number; a: number; v: number}> = ({t, a, v}) => {
  const lt = t - a, dir = v ? -1 : 1;
  const cards = v === 0
    ? [['bench', 'BENCH', 'Pro Flat Bench · 455 LB', 78], ['dead', 'DEAD\nLIFT', 'Pro Deadlift', 76], ['stone', 'ATLAS\nSTONES', 'Strongman yard', 66], ['hall', 'HALL OF\nFAME', 'Hall of Fame', 66]]
    : [['alter', 'ALTER 15', 'Gold · Gains x3.25', 70], ['voltar', 'VOLTA', 'Legendary · 0.6%', 84], ['record', 'NEW\nRECORD', '540 LB · Atlas Stones', 70], ['city', 'THE CITY', 'Pump Shop · Hall of Fame', 68]];
  const pos = [[270, 440, -9, 18], [815, 410, 7, -16], [260, 1430, 6, 14], [820, 1460, -7, -18]];
  return <div style={{position: 'absolute', inset: 0, perspective: 1400, background: '#1a0a10'}}>
    <Img src={F('gym_blur.jpg')} style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, transform: `scale(${(1.14 + lt * 0.05).toFixed(4)}) translate(${(dir * lt * -20).toFixed(1)}px,0)`}}/>
    <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 46%, rgba(255,255,255,.35), rgba(255,255,255,0) 55%), linear-gradient(180deg, rgba(232,20,60,.22), rgba(255,194,26,.16))'}}/>
    <div style={{position: 'absolute', inset: 0, transformStyle: 'preserve-3d', transform: `rotateZ(${(dir * lerp(-4, 3, seg(lt, -0.1, B + 0.15))).toFixed(2)}deg) rotateY(${(dir * lerp(-8, 6, seg(lt, -0.1, B + 0.15))).toFixed(2)}deg) scale(${(1 + lt * 0.07).toFixed(4)})`}}>
      {cards.map(([n, label, sub, ls], i) => { const [x, y, rz, ryy] = pos[i], kk = sp(t, a - 0.08 + i * 0.035, 3.0, 0.55), ox = (x - 540) * 1.3, oy = (y - 960) * 1.1;
        return <div key={i} style={{position: 'absolute', left: x + ox * (1 - kk), top: y + oy * (1 - kk), transform: `translate(-50%,-50%) translateZ(${40 + i * 20}px) rotateY(${ryy + lt * dir * 14}deg) rotateZ(${rz + (1 - kk) * 30 * (i % 2 ? 1 : -1)}deg)`}}>
          <Stamp w={500} h={500} img={clipF(n as string, lt)} label={label as string} ls={ls as number} sub={sub as string} shine={seg(lt, 0.1 + i * 0.05, 0.46 + i * 0.05)}/></div>; })}
      <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', filter: GLOW, transform: 'translateZ(120px)'}}>
        <Streak d="M540,620 C900,640 900,1260 540,1290 C180,1260 180,640 540,620" t={t} speed={1.5} len={0.5}/>
        <Streak d="M100,1000 C300,700 800,760 960,1000 C800,1240 300,1200 100,1000" t={t} speed={1.2} ph={0.4} w={6} color="#fff"/></svg>
      <Cut n={v ? 'rep' : 'hero'} st glow="white" x={540} y={945} w={v ? 470 : 400} z={200} rot={dir * (-18 + lt * 60)} s={lerp(0.4, 1, sp(t, a - 0.05, 3.2, 0.5))}/>
      <Svg style={{transform: 'translateZ(240px)'}}><Spark x={760} y={760} s={30} t={t}/><Spark x={330} y={1150} s={24} t={t} ph={0.5}/><Spark x={560} y={1320} s={16} t={t} ph={0.3}/></Svg>
    </div>
  </div>;
};
// drop · alters: the real legendary card under one glossy word
const Emblem: React.FC<{t: number; a: number}> = ({t, a}) => {
  const lt = t - a, k = sp(t, a - 0.06, 3.2, 0.48);
  const cuts = [['goldarms', 190, 1500, 300, -8, 150], ['giant', 890, 1470, 380, 8, 110]] as const;
  return <div style={{position: 'absolute', inset: 0, perspective: 1300, background: GRAD(160)}}>
    <div style={{position: 'absolute', inset: 0, transformStyle: 'preserve-3d', transform: `rotateY(${lerp(8, -8, seg(lt, -0.1, B + 0.15)).toFixed(2)}deg) rotateX(${(lt * 6 - 2).toFixed(2)}deg) scale(${(1 + lt * 0.08).toFixed(4)})`}}>
      {[[900, 1400, 0, 'rgba(255,255,255,.5)', -8, -140], [780, 1220, 1, YEL, 6, -80], [660, 1040, 2, 'rgba(255,255,255,.85)', -3, -30]].map(([w, h, i, c, r, z]) =>
        <div key={i as number} style={{position: 'absolute', left: 540, top: 900, width: w as number, height: h as number, marginLeft: -(w as number) / 2, marginTop: -(h as number) / 2, border: `${i === 1 ? 26 : 12}px solid ${c}`, borderRadius: 40, transform: `translateZ(${z}px) rotate(${(r as number) + lt * (i === 1 ? -14 : 10)}deg)`, boxShadow: '0 20px 50px rgba(80,5,20,.35)'}}/>)}
      <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', filter: GLOW, transform: 'translateZ(20px)'}}>
        <Streak d="M-40,1300 C200,900 880,1040 1120,620" t={t} speed={1.4} len={0.5}/><Streak d="M1120,1500 C760,1400 320,560 -40,520" t={t} speed={1.1} ph={0.5} w={6} color="#fff"/></svg>
      <Cut n="volta" st glow="white" x={540} y={640} w={1000} z={110} rot={lerp(-12, -4, k)} s={lerp(0.5, 1, k)}/>
      <At x={540} y={1070} tf={`translateZ(140px) scale(${lerp(1.6, 1, k).toFixed(3)}) rotate(-4deg)`}><div style={{fontFamily: 'Mo', fontSize: 196, lineHeight: 1, color: '#fff', whiteSpace: 'nowrap', textShadow: `${extrude(12, PURD)}, 0 0 50px rgba(255,255,255,.7), 0 26px 40px rgba(60,0,16,.55)`}}>ALTERS</div></At>
      <At x={540} y={1240} tf="translateZ(150px) rotate(-4deg)"><div style={{fontFamily: 'Al', fontSize: 62, color: YEL, whiteSpace: 'nowrap', textShadow: `${extrude(4, PURK)}, 0 8px 16px rgba(40,0,10,.5)`, opacity: seg(lt, 0.04, 0.12)}}>LEGENDARY · 0.6%</div></At>
      {cuts.map(([n, x, y, w, rot, z], i) => { const kk = sp(t, a - 0.06 + i * 0.04, 3.4, 0.5); return <Cut key={n} n={n} st glow="white" x={x + (x - 540) * (1 - kk)} y={y + (y - 960) * 0.6 * (1 - kk)} w={w} z={z} rot={rot + lt * 14 * (i % 2 ? -1 : 1)} s={lerp(0.5, 1, kk)}/>; })}
      <Svg style={{transform: 'translateZ(220px)'}}><Spark x={860} y={360} s={34} t={t}/><Spark x={200} y={980} s={24} t={t} ph={0.45}/><Spark x={610} y={300} s={20} t={t} ph={0.7}/><Spark x={540} y={1440} s={18} t={t} ph={0.2}/></Svg>
    </div>
    <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(circle at 14% 10%, rgba(255,250,210,.6), rgba(255,250,210,0) 46%)', mixBlendMode: 'screen', pointerEvents: 'none'}}/>
    <Hazard y={0} h={40} t={-t}/>
  </div>;
};
// the question, on crumpled paper
const Where: React.FC<{t: number; a: number}> = ({t, a}) => {
  const lt = t - a, l1 = ['HOW', 'BIG'], l2 = ['CAN', 'YOU', 'GET?'];
  const row = (ws: string[], size: number, d0: number) => <div style={{display: 'flex', gap: size * 0.24, justifyContent: 'center', fontFamily: 'Mo', fontSize: size, lineHeight: 1.08, color: INK, whiteSpace: 'nowrap', textShadow: '-1px -2px 0 rgba(255,255,255,.5), 0 16px 24px rgba(16,8,24,.5), 0 34px 50px rgba(16,8,24,.28)'}}>
    {ws.map((p, i) => { const kk = sp(t, a - 0.05 + d0 + i * 0.05, 3.6, 0.5); return <span key={i} style={{display: 'inline-block', transform: `translate(0,${((1 - kk) * 110).toFixed(1)}px) rotate(${((1 - kk) * 10).toFixed(1)}deg)`, opacity: cl(kk * 3)}}>{p}</span>; })}</div>;
  return <>
    <Paper crumple s={1.12} dx={lt * 30}/>
    <Svg style={{filter: 'blur(1.4px)'}}><path d={brushD(-80, 520, 500, 800, 1180, 560, 30, seg(lt, -0.05, 0.25))} fill={INK}/><path d={brushD(1160, 1400, 600, 1210, -80, 1500, 24, seg(lt, 0, 0.3))} fill={INK}/></Svg>
    <Svg><Scrib seed={91} x={80} y={250} w={420} h={200} n={6} k={seg(lt, 0, 0.25)} rot={-12}/><Scrib seed={95} x={600} y={1500} w={400} h={200} n={6} k={seg(lt, 0.05, 0.3)} rot={-10}/></Svg>
    <div style={{position: 'absolute', left: 150, top: 690, display: 'flex', gap: 14}}>{[YEL, PUR].map((c, i) => { const kk = sp(t, a + 0.02 + i * 0.06, 4, 0.45); return <div key={c} style={{width: 44, height: 44, borderRadius: 10, background: c, transform: `scale(${kk.toFixed(3)})`, boxShadow: '0 6px 12px rgba(16,8,24,.35)'}}/>; })}</div>
    <At x={540} y={920} tf={`rotate(-3deg) scale(${(1 + lt * 0.08).toFixed(4)})`}><div>{row(l1, 178, 0)}{row(l2, 110, 0.1)}</div></At>
    <div style={{position: 'absolute', left: 250, top: 1130, width: 580 * easeOut(seg(lt, 0.14, 0.34)), height: 12, borderRadius: 6, background: PUR, transform: 'rotate(-3deg)'}}/>
  </>;
};
// the goal: the Hall of Fame, as a big stamp card with live footage
const Hall: React.FC<{t: number; a: number}> = ({t, a}) => {
  const lt = t - a, k = sp(t, a - 0.07, 3.0, 0.52);
  return <div style={{position: 'absolute', inset: 0, perspective: 1500, background: GRAD(200)}}>
    <div style={{position: 'absolute', left: 540, top: 820, width: 3000, height: 300, marginLeft: -1500, marginTop: -150, transform: 'rotate(32deg)', background: BAND, borderTop: `10px solid ${YEL}`, borderBottom: '10px solid rgba(255,255,255,.75)', overflow: 'hidden'}}>
      <div style={{position: 'absolute', left: 0, top: 22, whiteSpace: 'nowrap', fontFamily: 'Ab', fontSize: 230, lineHeight: 1, color: PURK, opacity: 0.85, filter: 'blur(1.6px)', transform: `translate(${(-600 + lt * 300).toFixed(1)}px,0)`}}>{'Hall of Fame  ·  '.repeat(5)}</div></div>
    <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', filter: GLOW}}><Streak d="M-40,500 C300,200 900,300 1120,760" t={t} speed={1.4} len={0.5}/><Streak d="M1120,1250 C800,1500 300,1300 -40,1650" t={t} speed={1.1} ph={0.5} w={6} color="#fff"/></svg>
    <div style={{position: 'absolute', left: 540, top: 740, transformStyle: 'preserve-3d', transform: `translate(-50%,-50%) rotateY(${lerp(-22, -8, seg(lt, -0.1, B + 0.2)).toFixed(2)}deg) rotateZ(${lerp(-10, -3, k).toFixed(2)}deg) scale(${(lerp(0.7, 1, k) * (1 + lt * 0.05)).toFixed(4)})`}}>
      <Stamp w={840} h={640} img={clipF('hall', lt)} shine={seg(lt, 0.12, 0.5)}/></div>
    <At x={540} y={1340} tf={`rotate(-3deg) scale(${sp(t, a + 0.02, 3.4, 0.5).toFixed(3)})`}><div style={{fontFamily: 'Al', fontSize: 112, color: '#fff', whiteSpace: 'nowrap', textShadow: `${extrude(7, PURK)}, 0 14px 26px rgba(40,0,10,.6)`}}>HALL OF FAME</div></At>
    <At x={540} y={1490} tf={`rotate(-3deg) scale(${sp(t, a + 0.12, 3.4, 0.5).toFixed(3)})`}><div style={{fontFamily: 'Mo', fontSize: 76, color: YEL, whiteSpace: 'nowrap', textShadow: `${extrude(6, PURK)}, 0 14px 26px rgba(40,0,10,.6)`}}>WILL YOU MAKE IT?</div></At>
    <Svg><Spark x={900} y={380} s={34} t={t}/><Spark x={160} y={1180} s={24} t={t} ph={0.45}/><Spark x={930} y={1300} s={20} t={t} ph={0.7}/></Svg>
    <Shards t={t} seed={77} at={[[70, 150, 180], [200, 60, 90], [1000, 1760, 160], [880, 1850, 90]]}/>
    <Hazard y={1860} t={t}/>
  </div>;
};
// end card: dark, flares, the real logo in light, how to find the game, the call to action
const End: React.FC<{t: number; a: number}> = ({t, a}) => {
  const lt = t - a, tA = a + B, tC = a + 2 * B, line = 'Search GYM ARC on Roblox', nH = Math.floor(cl((t - (tA + 0.02)) / 0.03, 0, line.length)), fl = 0.75 + 0.25 * Math.sin(lt * 5);
  const msc = (tt: number) => { const kk = sp(tt, a - 0.05, 3.0, 0.5); return lerp(2.6, 1, cl(kk)) * (kk > 1 ? 1 - 0.3 * (kk - 1) : 1) * (1 + (tt - a) * 0.012); };
  const mb = 0.5 * Math.abs(msc(t + 1 / 240) - msc(t - 1 / 240)) * 520, cta = ['PLAY', 'NOW'];
  return <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 38%, #8a1030 0%, #2e0612 42%, #080104 100%)'}}>
    <div style={{position: 'absolute', left: -200, top: 716, width: 1480, height: 10, background: 'linear-gradient(90deg, rgba(0,0,0,0), #ff7aa0 30%, #fff 50%, #ff7aa0 70%, rgba(0,0,0,0))', filter: 'blur(5px)', opacity: fl, transform: `scaleX(${(0.3 + 0.7 * easeOut(seg(lt, 0, 0.5))).toFixed(3)})`}}/>
    <div style={{position: 'absolute', left: 540 - 560, top: 720 - 560, width: 1120, height: 1120, background: 'radial-gradient(circle, rgba(255,120,160,.5) 0%, rgba(255,60,110,.16) 30%, rgba(0,0,0,0) 62%)', opacity: fl}}/>
    {[[160, 300, 150, YEL], [930, 1250, 110, '#ff7aa0'], [860, 250, 70, '#fff']].map(([x, y, r, c], i) => <div key={i} style={{position: 'absolute', left: (x as number) - (r as number) + Math.sin(lt * 1.2 + i) * 24, top: (y as number) - (r as number), width: 2 * (r as number), height: 2 * (r as number), borderRadius: '50%', background: `radial-gradient(circle, ${c} 0%, rgba(0,0,0,0) 65%)`, opacity: 0.4 * seg(lt, 0, 0.3)}}/>)}
    <Cut n="lifter" st glow="white" x={215} y={310 + Math.sin(lt * 2) * 12} w={400} rot={-10 + lt * 3} s={sp(t, a + 0.05, 3.2, 0.5)}/>
    <Cut n="hero" st glow="white" x={885} y={320 + Math.cos(lt * 2) * 12} w={300} rot={10 - lt * 3} s={sp(t, a + 0.1, 3.2, 0.5)}/>
    <At x={540} y={740} tf={`scale(${msc(t).toFixed(4)})`}><div style={{filter: mb > 1 ? `blur(${Math.min(40, mb).toFixed(1)}px)` : undefined}}><Logo w={1020} glow/></div></At>
    <At x={540} y={1090}><div style={{opacity: seg(lt, 0.1, 0.2)}}><Glitch parts={['NO', 'DAYS', 'OFF']} font="Ab" size={84} color={YEL} t={t} seed={99} gap={0.34} shadow="0 4px 18px rgba(255,170,30,.55)"/></div></At>
    <At x={540} y={1250} tf={`translate(0,${((1 - sp(t, tA - 0.05, 3.4, 0.55)) * 70).toFixed(1)}px)`}><div style={{opacity: seg(t, tA - 0.04, tA + 0.03), width: 860, textAlign: 'center', padding: '20px 0 18px', borderTop: '3px solid rgba(255,255,255,.7)', borderBottom: '3px solid rgba(255,255,255,.7)', fontFamily: 'M8', fontSize: 58, color: '#fff', whiteSpace: 'pre', textShadow: '0 0 22px rgba(255,90,130,.9)', height: 72}}>{line.slice(0, nH)}</div></At>
    <At x={540} y={1480} tf="rotate(-3deg)"><div style={{display: 'flex', gap: 44, fontFamily: 'Mo', fontSize: 168, lineHeight: 1, color: YEL, whiteSpace: 'nowrap', textShadow: `${extrude(9, PURD)}, 0 0 40px rgba(255,190,60,.55), 0 18px 30px rgba(0,0,0,.6)`}}>
      {cta.map((p, i) => { const kk = sp(t, tC - 0.05 + i * 0.09, 3.6, 0.46); return <span key={i} style={{display: 'inline-block', transform: `scale(${kk.toFixed(3)}) translate(0,${((1 - kk) * 40).toFixed(1)}px)`, opacity: cl(kk * 3)}}>{p}</span>; })}</div></At>
    <Svg><Spark x={300} y={560} s={30} t={t}/><Spark x={820} y={960} s={22} t={t} ph={0.4}/><Spark x={170} y={1560} s={18} t={t} ph={0.7}/><Spark x={940} y={1600} s={26} t={t} ph={0.15}/><Spark x={560} y={250} s={16} t={t} ph={0.55}/></Svg>
  </div>;
};

export const Gy: React.FC = () => {
  const frame = useCurrentFrame(), {fps} = useVideoConfig(), t = frame / fps;
  const [h] = useState(() => delayRender('fonts'));
  useEffect(() => { Promise.all(FAMS.map(f => (document as any).fonts.load(`40px ${f}`, f === 'MS' || f === 'MM' ? 'အ' : 'A'))).then(() => continueRender(h), () => continueRender(h)); }, [h]);
  const DROP = bt(8), tq = Math.floor(t * 30) / 30;
  const beats = [9, 10, 11, 12, 13, 14, 15, 16, 17];
  const punch = 0.09 * hit(t, DROP, 0.16) + beats.reduce((s, n) => s + 0.035 * hit(t, bt(n), 0.1), 0);
  const sh = hit(tq, DROP, 0.17) * 26 + hit(tq, bt(17), 0.14) * 14, sx = Math.sin(tq * 97) * sh, sy = Math.cos(tq * 83) * sh;
  const inv = t >= bt(12) - 0.005 && t < bt(12) + 0.062;
  return <AbsoluteFill style={{background: '#12060a'}}>
    <style>{FONT}</style>
    <AbsoluteFill style={{transform: `translate(${sx.toFixed(1)}px,${sy.toFixed(1)}px) scale(${(1 + punch).toFixed(4)})`, filter: inv ? 'invert(1) hue-rotate(180deg)' : undefined}}>
      <Scene t={t} a={-1} b={bt(1)} tout="zoom"><Hook t={t}/></Scene>
      <Scene t={t} a={bt(1)} b={bt(2)} tin="zoom" tout="zoom"><MarkScene t={t} a={bt(1)} v={0}/></Scene>
      {[0, 1, 2, 3].map(i => <Scene key={i} t={t} a={bt(2 + i / 2)} b={bt(2.5 + i / 2)} tin="zoom" tout={i === 3 ? 'spin' : 'zoom'}><CutScene t={t} a={bt(2 + i / 2)} i={i}/></Scene>)}
      <Scene t={t} a={bt(4)} b={bt(5)} tin="spin" tout="L"><MarkScene t={t} a={bt(4)} v={1}/></Scene>
      <Scene t={t} a={bt(5)} b={bt(8)} tin="L" tout="cut"><TypeScene t={t} a={bt(5)}/>{t < bt(8) && <Panels t={t} a={bt(7)}/>}</Scene>
      <Scene t={t} a={bt(8)} b={bt(9)} tin="cut" tout="U"><Ribbon t={t} a={bt(8)} v={0}/></Scene>
      <Scene t={t} a={bt(9)} b={bt(10)} tin="U" tout="L"><Poster t={t} a={bt(9)} v={0}/></Scene>
      <Scene t={t} a={bt(10)} b={bt(11)} tin="L" tout="spin"><Cards t={t} a={bt(10)} v={0}/></Scene>
      <Scene t={t} a={bt(11)} b={bt(12)} tin="spin" tout="DR"><Emblem t={t} a={bt(11)}/></Scene>
      <Scene t={t} a={bt(12)} b={bt(13)} tin="DR" tout="D"><Ribbon t={t} a={bt(12)} v={1}/></Scene>
      <Scene t={t} a={bt(13)} b={bt(14)} tin="D" tout="R"><Poster t={t} a={bt(13)} v={1}/></Scene>
      <Scene t={t} a={bt(14)} b={bt(15)} tin="R" tout="UL"><Cards t={t} a={bt(14)} v={1}/></Scene>
      <Scene t={t} a={bt(15)} b={bt(16)} tin="UL" tout="L"><Where t={t} a={bt(15)}/></Scene>
      <Scene t={t} a={bt(16)} b={bt(17)} tin="L" tout="zoom"><Hall t={t} a={bt(16)}/></Scene>
      <Scene t={t} a={bt(17)} b={99} tin="zoom"><End t={t} a={bt(17)}/></Scene>
    </AbsoluteFill>
    <AbsoluteFill style={{background: '#fff', opacity: 0.8 * hit(t, DROP, 0.07) + 0.45 * hit(t, bt(17), 0.06), pointerEvents: 'none'}}/>
  </AbsoluteFill>;
};
