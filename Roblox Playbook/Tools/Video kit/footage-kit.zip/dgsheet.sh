#!/bin/bash
# usage: dgsheet.sh <video> <out.jpg> <cols> t1 t2 ...   -> tiles the frames at those times
V=$1; O=$2; C=$3; shift 3; D=$(mktemp -d); i=0
for t in "$@"; do ffmpeg -v error -y -ss $t -i $V -frames:v 1 -vf "scale=432:-1,drawtext=text='$t':x=6:y=6:fontsize=22:fontcolor=lime:box=1:boxcolor=black@0.6" $D/$(printf %03d $i).png; i=$((i+1)); done
R=$(( (i + C - 1) / C )); ffmpeg -v error -y -pattern_type glob -i "$D/*.png" -vf "tile=${C}x${R}" -frames:v 1 -q:v 3 $O; rm -rf $D
