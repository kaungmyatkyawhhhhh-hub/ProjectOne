import React, {useEffect, useState} from 'react';
import {AbsoluteFill, Img, staticFile, useCurrentFrame, useVideoConfig, delayRender, continueRender} from 'remotion';

// FlexiToys ad in the "paper collage trend edit" grammar (reference: a luxury-brand trend edit cut to "the kill 2").
// Taken from the reference: the GRAMMAR only (paper intro, cut-outs, big geometric wordmark + glitch serif line, ink scribbles, type scene,
// colour panels, then one collage scene per beat with ribbons, poster, stamp cards, light streaks, blossoms, whips). All content is the shop's own:
// its products cut out of its own footage, its real prices, its own words and colours (purple + yellow).
// Every pixel is a function of t. Beat grid measured on the sound: beat 0.5825 s, first hit 0.086 s, DROP on beat 8 (4.746 s).
export const B = 0.5825, B0 = 0.086, DG_DUR = 12.6;
const bt = (n: number) => B0 + n * B;
const TAU = Math.PI * 2;
const cl = (v: number, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
const seg = (t: number, a: number, b: number) => cl((t - a) / (b - a));
const easeIn = (k: number) => cl(k) ** 3;
const easeOut = (k: number) => 1 - (1 - cl(k)) ** 3;
const sp = (t: number, t0: number, f = 3.4, z = 0.5) => {
  const x = t - t0; if (x <= 0) return 0;
  const w = TAU * f, wd = w * Math.sqrt(1 - z * z);
  return 1 - Math.exp(-z * w * x) * (Math.cos(wd * x) + (z * w / wd) * Math.sin(wd * x));
};
const hit = (t: number, t0: number, d = 0.12) => (t >= t0 ? Math.exp(-(t - t0) / d) : 0);
const rnd = (s: number) => { let a = (s * 2654435761) >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let x = Math.imul(a ^ a >>> 15, 1 | a); x = x + Math.imul(x ^ x >>> 7, 61 | x) ^ x; return ((x ^ x >>> 14) >>> 0) / 4294967296; }; };
const whipE = (x: number) => { const c = cl(x); return c < 0.4 ? 0.5 * (c / 0.4) ** 3 : 1 - 0.5 * ((1 - c) / 0.6) ** 3; };   // fastest ON the beat

const INK = '#17121a', PUR = '#7426e6', PURD = '#3d0f96', PURK = '#1c0a45', YEL = '#ffd23a', YELD = '#ffb21f';
const F = (n: string) => staticFile('dg/' + n);
const FONT = [['Sp', 'spartan9.woff2'], ['Jo', 'jost9.woff2'], ['Mo', 'mont9.woff2'], ['M8', 'mont8.woff2'], ['Ab', 'abril.woff2'], ['Al', 'alfa.woff2'], ['Mk', 'marker.woff2'], ['Co', 'corm-i.woff2'], ['Bo', 'bodoni9.woff2'], ['MS', 'mmserif9.woff2']]
  .map(([f, u]) => `@font-face{font-family:${f};src:url(${F(u)})}`).join('') + `@font-face{font-family:MM;src:url(${staticFile('mm-900.woff2')})}`;
const FAMS = ['Sp', 'Jo', 'Mo', 'M8', 'Ab', 'Al', 'Mk', 'Co', 'Bo', 'MS', 'MM'];

// Burmese is animated per SYLLABLE, never per code point
const clusters = (s: string): string[] => {
  const ch = Array.from(s), out: string[] = [], cp = (i: number) => (i >= 0 && i < ch.length ? ch[i].codePointAt(0)! : 0);
  const isCons = (c: number) => (c >= 0x1000 && c <= 0x102a) || c === 0x103f || (c >= 0x104c && c <= 0x104f), isMy = (c: number) => c >= 0x1000 && c <= 0x109f;
  ch.forEach((c, i) => {
    const k = cp(i), n1 = cp(i + 1), n2 = cp(i + 2);
    const killed = n1 === 0x103a || n1 === 0x1039 || (n1 === 0x1037 && n2 === 0x103a);
    const startsNew = !isMy(k) || (isCons(k) && !killed && cp(i - 1) !== 0x1039);
    if (startsNew || out.length === 0 || !isMy(cp(i - 1))) out.push(c); else out[out.length - 1] += c;
  });
  return out;
};
const extrude = (n: number, c: string, dx = 1, dy = 1) => Array.from({length: n}, (_, i) => `${(i + 1) * dx}px ${(i + 1) * dy}px 0 ${c}`).join(',');

// ---------- scene shell: whip / zoom / spin transitions; the incoming scene covers the outgoing one, both move the same way ----------
const DIR: Record<string, [number, number, number]> = {L: [1, 0, 5], R: [-1, 0, -5], U: [0, 1, -4], D: [0, -1, 4], UL: [0.8, 1, 7], DR: [-0.8, -1, -7]};
// Motion blur: the 120 fps blend gives 4 samples per output frame; on a whip those samples are up to ~140 px apart and read as 4 ghost copies.
// So each moving layer also gets a DIRECTIONAL blur (SVG feGaussianBlur with separate x / y radii) sized from its own speed: half the gap between samples.
const MBlur: React.FC<{id: string; sx: number; sy: number}> = ({id, sx, sy}) =>
  <svg width={0} height={0} style={{position: 'absolute'}}><filter id={id} x="-18%" y="-18%" width="136%" height="136%" colorInterpolationFilters="sRGB"><feGaussianBlur stdDeviation={`${Math.min(95, sx).toFixed(1)} ${Math.min(95, sy).toFixed(1)}`}/></filter></svg>;
const Scene: React.FC<{t: number; a: number; b: number; tin?: string; tout?: string; children: React.ReactNode}> = ({t, a, b, tin = 'cut', tout = 'cut', children}) => {
  const wi = tin in DIR, wo = tout in DIR;
  const t0 = wi ? a - 0.10 : tin === 'cut' ? a : a - 0.02, t1 = wo ? b + 0.15 : tout === 'cut' ? b : b + 0.04;
  if (t < t0 || t >= t1) return null;
  const xf = (t: number) => {
    let x = 0, y = 0, r = 0, s = 1, o = 1;
    if (wi) { const k = 1 - whipE(seg(t, a - 0.10, a + 0.15)), d = DIR[tin]; x += d[0] * 1130 * k; y += d[1] * 1980 * k; r += d[2] * k; }
    else if (tin === 'zoom') { const k = 1 - easeOut(seg(t, a - 0.02, a + 0.2)); s *= 1 + 0.2 * k; o = seg(t, a - 0.02, a + 0.015); }
    else if (tin === 'spin') { const k = 1 - easeOut(seg(t, a - 0.02, a + 0.26)); s *= 1 + 0.5 * k; r += -20 * k; o = seg(t, a - 0.02, a + 0.02); }
    if (wo) { const k = whipE(seg(t, b - 0.10, b + 0.15)), d = DIR[tout]; x -= d[0] * 1130 * 0.5 * k; y -= d[1] * 1980 * 0.5 * k; r -= d[2] * 0.6 * k; }
    else if (tout !== 'cut') { s *= 1 + 0.05 * easeIn(seg(t, b - 0.09, b + 0.02)); }
    return {x, y, r, s, o};
  };
  const {x, y, r, s, o} = xf(t), p = xf(t - 1 / 240), q = xf(t + 1 / 240);
  const iso = 0.5 * (Math.abs(q.s - p.s) * 620 + Math.abs(q.r - p.r) * (Math.PI / 180) * 620), sx = 0.5 * Math.abs(q.x - p.x) + iso, sy = 0.5 * Math.abs(q.y - p.y) + iso;
  const id = 'mb' + Math.round((a + 2) * 1000), on = sx > 1.5 || sy > 1.5;
  return <AbsoluteFill style={{transform: `translate(${x.toFixed(1)}px,${y.toFixed(1)}px) rotate(${r.toFixed(2)}deg) scale(${s.toFixed(4)})`, opacity: o, filter: on ? `url(#${id})` : undefined}}>
    {on && <MBlur id={id} sx={sx} sy={sy}/>}
    <AbsoluteFill style={{overflow: 'hidden', background: '#0c0518'}}>{children}</AbsoluteFill>
  </AbsoluteFill>;
};

// ---------- building blocks ----------
const Paper: React.FC<{crumple?: boolean; s?: number; dx?: number; dy?: number}> = ({crumple, s = 1.06, dx = 0, dy = 0}) =>
  <Img src={F(crumple ? 'crumple.jpg' : 'paper.jpg')} style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, transform: `translate(${dx}px,${dy}px) scale(${s})`}}/>;
// a product cut out of the shop's own footage; st = white sticker outline (drop scenes)
const Cut: React.FC<{n: string; x: number; y: number; w: number; rot?: number; st?: boolean; s?: number; glow?: 'ink' | 'white' | 'none'; z?: number; op?: number}> = ({n, x, y, w, rot = 0, st, s = 1, glow = 'ink', z = 0, op = 1}) =>
  <Img src={F(n + (st ? '_st' : '') + '.png')} style={{position: 'absolute', left: x, top: y, width: w, opacity: op,
    transform: `translate(-50%,-50%) translateZ(${z}px) rotate(${rot.toFixed(2)}deg) scale(${s.toFixed(4)})`,
    filter: glow === 'ink' ? 'drop-shadow(0 6px 22px rgba(16,8,24,.6))' : glow === 'white' ? 'drop-shadow(0 0 16px rgba(255,255,255,.8)) drop-shadow(0 22px 26px rgba(28,6,70,.5))' : undefined}}/>;
// scratchy ink zigzag (two passes: a firm line and a hair line), drawn on by k
const zig = (seed: number, x: number, y: number, w: number, h: number, n: number) => {
  const r = rnd(seed), p: string[] = [];
  for (let i = 0; i < n; i++) p.push((x + (i % 2 === 0 ? r() * 0.16 : 0.84 + r() * 0.16) * w).toFixed(1) + ',' + (y + (i / (n - 1)) * h + (r() - 0.5) * h * 0.3).toFixed(1));
  return 'M' + p.join('L');
};
const Scrib: React.FC<{seed: number; x: number; y: number; w: number; h: number; n?: number; k?: number; rot?: number; sw?: number; color?: string}> = ({seed, x, y, w, h, n = 5, k = 1, rot = 0, sw = 3, color = INK}) =>
  <g transform={`rotate(${rot} ${x + w / 2} ${y + h / 2})`} fill="none" stroke={color} strokeLinecap="round" strokeLinejoin="miter">
    <path d={zig(seed, x, y, w, h, n)} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - cl(k)} strokeWidth={sw}/>
    <path d={zig(seed + 7, x - 14, y - 10, w * 1.1, h * 1.15, n + 1)} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - cl(k * 1.2 - 0.2)} strokeWidth={1.3} opacity={0.75}/>
    <path d={zig(seed + 13, x + 20, y + 6, w * 0.9, h * 0.8, n - 1)} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - cl(k * 1.3 - 0.3)} strokeWidth={0.9} opacity={0.6}/>
  </g>;
// tapered brush stroke along a curve (a filled blade, not a stroked line), drawn on by k
const brushD = (x0: number, y0: number, cx: number, cy: number, x1: number, y1: number, w: number, k = 1) => {
  const L: string[] = [], R: string[] = [], N = 26;
  for (let i = 0; i <= N; i++) {
    const s = (i / N) * cl(k), a = 1 - s, x = a * a * x0 + 2 * a * s * cx + s * s * x1, y = a * a * y0 + 2 * a * s * cy + s * s * y1;
    const dx = 2 * a * (cx - x0) + 2 * s * (x1 - cx), dy = 2 * a * (cy - y0) + 2 * s * (y1 - cy), n = Math.hypot(dx, dy) || 1, ww = w * 0.5 * Math.sin(Math.PI * (i / N)) ** 0.7;
    L.push((x - dy / n * ww).toFixed(1) + ',' + (y + dx / n * ww).toFixed(1)); R.unshift((x + dy / n * ww).toFixed(1) + ',' + (y - dx / n * ww).toFixed(1));
  }
  return 'M' + L.join('L') + 'L' + R.join('L') + 'Z';
};
const Svg: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', ...style}}>{children}</svg>;
// a streak of light that travels along a path
const Streak: React.FC<{d: string; t: number; speed?: number; len?: number; w?: number; ph?: number; color?: string}> = ({d, t, speed = 0.9, len = 0.6, w = 13, ph = 0, color = '#ffe45c'}) => {
  const p = ((t * speed + ph) % (1 + len)) - len;
  return <g fill="none" strokeLinecap="round"><path d={d} pathLength={1} stroke={color} strokeWidth={w} strokeDasharray={`${len} 2`} strokeDashoffset={-p} opacity={0.9}/><path d={d} pathLength={1} stroke="#fff" strokeWidth={w * 0.34} strokeDasharray={`${len * 0.8} 2`} strokeDashoffset={-p - len * 0.1}/></g>;
};
const GLOW = 'drop-shadow(0 0 9px rgba(255,226,90,.95)) drop-shadow(0 0 26px rgba(255,170,30,.7))';
const Spark: React.FC<{x: number; y: number; s: number; t: number; ph?: number}> = ({x, y, s, t, ph = 0}) => {
  const k = 0.5 + 0.5 * Math.sin((t * 2.6 + ph) * TAU);
  return <path transform={`translate(${x} ${y}) rotate(${(t * 50 + ph * 90).toFixed(1)}) scale(${(s * (0.45 + 0.55 * k)).toFixed(2)})`} d="M0,-1 Q.09,-.09 1,0 Q.09,.09 0,1 Q-.09,.09 -1,0 Q-.09,-.09 0,-1Z" fill="#fff"/>;
};
// blossom (the stall's own banner is covered in spring flowers); blurred ones sit in the foreground for depth
const Flower: React.FC<{x: number; y: number; s: number; rot?: number; blur?: number; op?: number; c?: string}> = ({x, y, s, rot = 0, blur = 0, op = 1, c = '#ffe1f0'}) =>
  <svg width={2 * s} height={2 * s} viewBox="-1.1 -1.1 2.2 2.2" style={{position: 'absolute', left: x - s, top: y - s, opacity: op, filter: blur ? `blur(${blur}px)` : undefined, overflow: 'visible'}}>
    <g transform={`rotate(${rot.toFixed(1)})`}>{[0, 1, 2, 3, 4].map(i => <ellipse key={i} cx={0} cy={-0.54} rx={0.35} ry={0.5} transform={`rotate(${i * 72})`} fill={c} stroke="#ff86bf" strokeWidth={0.035}/>)}
      {[0, 1, 2, 3, 4].map(i => <line key={'l' + i} x1={0} y1={-0.12} x2={0} y2={-0.5} transform={`rotate(${i * 72})`} stroke="#ff6fb0" strokeWidth={0.03}/>)}<circle r={0.17} fill="#ffc930"/></g>
  </svg>;
const Blossoms: React.FC<{t: number; seed: number; at: [number, number, number][]}> = ({t, seed, at}) => {
  const r = rnd(seed);
  return <>{at.map(([x, y, s], i) => { const ph = r() * TAU, bl = s > 150 ? 9 : s > 100 ? 5 : 2; return <Flower key={i} x={x + Math.sin(t * 1.3 + ph) * 16} y={y + Math.cos(t * 1.1 + ph) * 12} s={s} rot={r() * 72 + t * (20 + r() * 30)} blur={bl} op={s > 150 ? 0.92 : 1}/>; })}</>;
};
const Hazard: React.FC<{y: number; h?: number; t: number}> = ({y, h = 46, t}) =>
  <div style={{position: 'absolute', left: -100, top: y, width: 1280, height: h, background: `repeating-linear-gradient(-45deg, ${YEL} 0 30px, ${PURK} 30px 60px)`, backgroundPosition: `${(t * 120).toFixed(1)}px 0`, boxShadow: '0 -6px 24px rgba(20,5,50,.35)'}}/>;
// glitch serif line: the text + 3 displaced slices + hairlines that change every 2 output frames
const Glitch: React.FC<{parts: string[]; font: string; size: number; color?: string; t: number; seed: number; gap?: number; amt?: number; shadow?: string}> = ({parts, font, size, color = INK, t, seed, gap = 0.16, amt = 1, shadow = '0 3px 10px rgba(16,8,24,.45)'}) => {
  const r = rnd(seed * 977 + Math.floor(t * 15)), on = r() < 0.7;
  const row = (st: React.CSSProperties, key?: string) => <div key={key} style={{display: 'flex', gap: size * gap, justifyContent: 'center', whiteSpace: 'nowrap', ...st}}>{parts.map((p, i) => <span key={i}>{p}</span>)}</div>;
  return <div style={{position: 'relative', fontFamily: font, fontSize: size, lineHeight: 1.25, color, textShadow: shadow}}>
    {row({})}
    {on && [0, 1, 2].map(i => { const y0 = r() * 78, h = 7 + r() * 15, dx = (r() - 0.5) * size * 0.34 * amt; return row({position: 'absolute', left: 0, right: 0, top: 0, clipPath: `inset(${y0}% -20% ${100 - y0 - h}% -20%)`, transform: `translateX(${dx.toFixed(1)}px)`, background: 'transparent'}, 's' + i); })}
    {on && [0, 1].map(i => <div key={'h' + i} style={{position: 'absolute', left: `${-8 + r() * 30}%`, width: `${35 + r() * 55}%`, top: `${12 + r() * 76}%`, height: 2, background: color, opacity: 0.8}}/>)}
  </div>;
};
// the big geometric wordmark: near-black, soft dark halo, a thin top-left highlight (the embossed look), and a light sweep
const Mark: React.FC<{lines: string[]; size: number; t: number; sweep: number; light?: boolean}> = ({lines, size, sweep, light}) => {
  const body = (st: React.CSSProperties) => <div style={{fontFamily: 'Sp', fontSize: size, lineHeight: 0.86, letterSpacing: '-0.01em', textAlign: 'center', whiteSpace: 'nowrap', ...st}}>{lines.map((l, i) => <div key={i}>{l}</div>)}</div>;
  return <div style={{position: 'relative'}}>
    {body(light ? {color: '#fff', textShadow: `${extrude(9, PURD)}, 0 0 46px rgba(170,100,255,.9), 0 0 110px rgba(140,70,255,.6)`}
      : {color: INK, textShadow: `-1.5px -2px 0 rgba(255,255,255,.55), 2px 3px 0 rgba(0,0,0,.55), 0 0 ${size * 0.09}px rgba(18,8,24,.55), 0 ${size * 0.05}px ${size * 0.12}px rgba(18,8,24,.4)`})}
    {sweep > 0 && sweep < 1 && <div style={{position: 'absolute', inset: 0}}>{body({color: 'transparent', backgroundImage: `linear-gradient(105deg, rgba(255,255,255,0) 42%, rgba(255,255,255,${light ? 0.95 : 0.6}) 50%, rgba(255,255,255,0) 58%)`, backgroundSize: '300% 100%', backgroundPosition: `${lerp(100, 0, sweep).toFixed(1)}% 0`, WebkitBackgroundClip: 'text', backgroundClip: 'text'})}</div>}
  </div>;
};
const At: React.FC<{x: number; y: number; children: React.ReactNode; tf?: string; z?: number}> = ({x, y, children, tf = '', z}) =>
  <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) ${tf}`, zIndex: z}}>{children}</div>;
// postage-stamp card: white card, perforated purple edge, a real photo, a big label over it
const SHINE = 'linear-gradient(110deg, rgba(255,255,255,0) 40%, rgba(255,255,255,.8) 50%, rgba(255,255,255,0) 60%)';
const Shine: React.FC<{k: number}> = ({k}) => (k > 0 && k < 1 ? <div style={{position: 'absolute', inset: 0, backgroundImage: SHINE, backgroundSize: '300% 100%', backgroundPosition: `${lerp(100, 0, k).toFixed(1)}% 0`, pointerEvents: 'none'}}/> : null);
const Stamp: React.FC<{w: number; h: number; img: string; label?: string; ls?: number; sub?: string; fit?: string; shine?: number}> = ({w, h, img, label, ls = 56, sub, fit = 'cover', shine = 0}) =>
  <div style={{width: w, height: h, borderRadius: 22, background: `radial-gradient(circle, ${PUR} 7px, rgba(0,0,0,0) 7.7px) -12px -12px / 24px 24px, #fff`, boxShadow: '0 34px 50px rgba(20,5,50,.5), 0 0 30px rgba(255,255,255,.35)', position: 'relative'}}>
    <div style={{position: 'absolute', inset: 14, borderRadius: 10, background: '#fff', overflow: 'hidden'}}>
      <Img src={F(img)} style={{position: 'absolute', left: 0, top: 0, width: '100%', height: sub ? '82%' : '100%', objectFit: fit as any}}/>
      {label && <div style={{position: 'absolute', left: 14, right: 8, bottom: sub ? '21%' : 10, fontFamily: 'Mo', fontSize: ls, lineHeight: 0.95, color: '#fff', letterSpacing: '-0.01em', textShadow: `${extrude(4, PURD)}, 0 6px 16px rgba(10,0,30,.75)`}}>{label}</div>}
      {sub && <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: '18%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'M8', fontSize: Math.round(w * 0.066), color: PURK, letterSpacing: '0.04em', background: '#fff'}}>{sub}</div>}
      <Shine k={shine}/>
    </div>
  </div>;

// ================= scenes =================
// 0 · hook: the product itself on paper, on frame 1
const Hook: React.FC<{t: number}> = ({t}) => {
  const k = sp(t, -0.14, 3.2, 0.5), d = seg(t, -0.05, 0.3);
  return <>
    <Paper dx={-10 + t * 30}/>
    <Svg><path d={brushD(210, 700, 470, 300, 900, 560, 40, 0.6 + 0.4 * d)} fill={INK}/><path d={brushD(250, 1150, 400, 1230, 610, 1170, 16, d)} fill={INK}/>
      <Scrib seed={3} x={640} y={1100} w={360} h={130} k={d} rot={-8}/><Scrib seed={5} x={60} y={250} w={420} h={170} n={6} k={d} rot={-14}/><Scrib seed={9} x={600} y={1560} w={420} h={200} n={6} k={d} rot={-10} sw={2.4}/></Svg>
    <Cut n="blox3d" x={540} y={790} w={880} rot={lerp(-15, -5, k) + t * 6} s={lerp(0.8, 1, k) * (1 + t * 0.06)}/>
    <At x={540} y={1370}><Glitch parts={['BLIND', 'BOX']} font="Ab" size={128} t={t} seed={1} gap={0.3}/></At>
    <At x={540} y={1500}><div style={{fontFamily: 'M8', fontSize: 38, letterSpacing: '0.42em', color: INK, opacity: 0.8 * seg(t, 0.0, 0.12), whiteSpace: 'nowrap'}}>BLOX FRUITS</div></At>
  </>;
};
// 1 / 3 · the wordmark scene
const MarkScene: React.FC<{t: number; a: number; v: number}> = ({t, a, v}) => {
  const lt = t - a, k = sp(t, a - 0.06, 3.4, 0.48), z = 1 + lt * 0.07, cuts = v === 0
    ? [['mchand', 250, 400, 380, -14], ['jeep', 830, 420, 330, 12], ['pig', 880, 1500, 230, 8]] as const
    : [['robf', 230, 400, 270, -10], ['keygreen', 830, 410, 330, 14], ['ladder', 880, 1500, 200, 7]] as const;
  return <>
    <Paper dx={v ? 14 : -6} dy={lt * -20}/>
    <div style={{position: 'absolute', inset: 0, transform: `scale(${z.toFixed(4)}) rotate(${(v ? 0.6 : -0.6) * lt * 2}deg)`}}>
      <Svg><Scrib seed={11 + v} x={30} y={150} w={470} h={250} n={6} k={seg(lt, -0.02, 0.22)} rot={-14}/><Scrib seed={21 + v} x={60} y={1420} w={470} h={270} n={6} k={seg(lt, 0.04, 0.3)} rot={-12}/><Scrib seed={25 + v} x={640} y={1180} w={360} h={120} n={5} k={seg(lt, 0.06, 0.3)} rot={8} sw={2.2}/>
        <path d={brushD(60, 1560, 300, 1480, 520, 1620, 12, seg(lt, 0.05, 0.3))} fill={INK}/></Svg>
      {cuts.map(([n, x, y, w, rot], i) => { const kk = sp(t, a - 0.04 + i * 0.05, 3.6, 0.5); return <Cut key={n} n={n} x={x} y={y + (1 - kk) * -40} w={w} rot={rot + (1 - kk) * 20} s={kk}/>; })}
      <At x={540} y={900} tf={`scale(${lerp(1.3, 1, k).toFixed(4)})`}><Mark lines={['FLEXI', 'TOYS']} size={300} t={t} sweep={seg(lt, 0.08, 0.5)}/></At>
      <At x={540} y={1300}><Glitch parts={clusters('အရုပ်ဆိုင်')} font="MS" size={104} t={t} seed={4 + v} gap={0.03} amt={0.6}/></At>
      <At x={80} y={900} tf="rotate(-90deg)"><Glitch parts={['NAY', 'PYI', 'TAW']} font="Ab" size={40} t={t} seed={8 + v} gap={0.4}/></At>
    </div>
  </>;
};
// 2 · one product per half beat
const CutScene: React.FC<{t: number; a: number; i: number}> = ({t, a, i}) => {
  const lt = t - a, k = sp(t, a - 0.05, 3.8, 0.5), sgn = i % 2 ? 1 : -1;
  const cap = [['MINECRAFT'], ['ROBLOX'], ['BUILDING', 'SETS'], ['KEYCHAINS']][i];
  return <>
    <Paper dx={sgn * 12} dy={i * -8} s={1.08}/>
    <Svg><Scrib seed={30 + i} x={sgn > 0 ? 80 : 620} y={300 + i * 30} w={380} h={170} k={seg(lt, -0.02, 0.16)} rot={sgn * 12}/>
      <path d={brushD(sgn > 0 ? 880 : 200, 1210, 540, 1290, sgn > 0 ? 260 : 820, 1190, 20, seg(lt, 0, 0.18))} fill={INK}/></Svg>
    <div style={{position: 'absolute', inset: 0, transform: `scale(${(lerp(0.86, 1, k) * (1 + lt * 0.1)).toFixed(4)}) rotate(${(sgn * lerp(9, 2, k)).toFixed(2)}deg)`, transformOrigin: '540px 800px'}}>
      {i === 0 && <Cut n="mcf" x={540} y={770} w={680}/>}
      {i === 1 && <Cut n="robf" x={540} y={770} w={600}/>}
      {i === 2 && <Cut n="sets3" x={540} y={770} w={820}/>}
      {i === 3 && <><Cut n="pig" x={330} y={640} w={400} rot={-10}/><Cut n="keygreen" x={745} y={720} w={430} rot={12}/><Cut n="keymint" x={500} y={990} w={520} rot={-4}/></>}
    </div>
    <At x={540} y={1400}><Glitch parts={cap} font="Ab" size={cap.length > 1 ? 96 : 112} t={t} seed={40 + i} gap={0.3} amt={1.3}/></At>
  </>;
};
// 4 · the type scene: one bold line, an underline, two little squares, a second coloured line, long ink blades
const TypeScene: React.FC<{t: number; a: number}> = ({t, a}) => {
  const lt = t - a, parts = clusters('ဘာထွက်မလဲ?'), t2 = a + B;
  return <>
    <Paper dx={-lt * 26} s={1.1}/>
    <Svg style={{filter: 'blur(1.2px)'}}><path d={brushD(-80, 1500, 380, 1050, 1180, 760, 30, seg(lt, 0, 0.3))} fill={INK}/><path d={brushD(-60, 1150, 300, 1330, 1200, 1500, 22, seg(lt, 0.06, 0.4))} fill={INK} opacity={0.9}/></Svg>
    <Svg><path d={brushD(60, 430, 300, 760, 420, 1700, 8, seg(lt, 0.02, 0.36))} fill={INK}/><path d={brushD(20, 620, 420, 900, 1100, 1010, 5, seg(lt, 0.1, 0.5))} fill={INK}/>
      <Scrib seed={51} x={640} y={1260} w={380} h={220} k={seg(lt, 0.1, 0.4)} rot={-10} sw={2.4}/></Svg>
    <div style={{position: 'absolute', left: 150 - lt * 14, top: 660, display: 'flex', gap: 14}}>{[PUR, YEL].map((c, i) => { const kk = sp(t, a + 0.04 + i * 0.06, 4, 0.45); return <div key={c} style={{width: 40, height: 40, borderRadius: 9, background: c, transform: `scale(${kk.toFixed(3)}) rotate(${((1 - kk) * 40).toFixed(1)}deg)`, boxShadow: '0 6px 12px rgba(16,8,24,.35)'}}/>; })}</div>
    <div style={{position: 'absolute', left: 96 - lt * 14, top: 700, display: 'flex', fontFamily: 'MM, Mo', fontSize: 150, lineHeight: 1.5, color: INK, whiteSpace: 'nowrap', textShadow: '-1px -2px 0 rgba(255,255,255,.5), 0 14px 22px rgba(16,8,24,.5), 0 30px 46px rgba(16,8,24,.28)'}}>
      {parts.map((p, i) => { const kk = sp(t, a - 0.04 + i * 0.055, 3.6, 0.52); return <span key={i} style={{display: 'inline-block', transform: `translate(${((1 - kk) * 90).toFixed(1)}px,0) skewX(${((1 - kk) * -14).toFixed(1)}deg)`, opacity: cl(kk * 3)}}>{p}</span>; })}
    </div>
    <div style={{position: 'absolute', left: 300 - lt * 14, top: 926, width: 250 * easeOut(seg(lt, 0.16, 0.36)), height: 10, borderRadius: 5, background: PUR, boxShadow: '0 4px 10px rgba(60,10,150,.4)'}}/>
    <div style={{position: 'absolute', right: 110 + lt * 10, top: 968, fontFamily: 'Al', fontSize: 104, color: PUR, whiteSpace: 'nowrap', opacity: seg(t, t2 - 0.03, t2 + 0.03), transform: `translate(${((1 - sp(t, t2 - 0.05, 3.6, 0.5)) * -120).toFixed(1)}px,0)`, textShadow: '0 8px 16px rgba(40,8,110,.45), -1px -1px 0 rgba(255,255,255,.5)'}}>BLIND BOX</div>
  </>;
};
// 5 · colour panels close over the type scene: marker letters, then the real price in a thin serif
const Panels: React.FC<{t: number; a: number}> = ({t, a}) => {
  const k1 = whipE(seg(t, a - 0.10, a + 0.15)), a2 = a + B / 2, k2 = whipE(seg(t, a2 - 0.10, a2 + 0.15));
  if (t < a - 0.10) return null;
  const h = 1 / 240, b1 = 0.5 * 420 * Math.abs(whipE(seg(t + h, a - 0.10, a + 0.15)) - whipE(seg(t - h, a - 0.10, a + 0.15))), b2 = 0.5 * 1960 * Math.abs(whipE(seg(t + h, a2 - 0.10, a2 + 0.15)) - whipE(seg(t - h, a2 - 0.10, a2 + 0.15)));
  return <>
    {b1 > 1.5 && <MBlur id="mbp1" sx={b1} sy={0}/>}{b2 > 1.5 && <MBlur id="mbp2" sx={0} sy={b2}/>}
    <div style={{position: 'absolute', left: 0, top: 0, width: 400, height: 1920, transform: `translate(${((k1 - 1) * 420).toFixed(1)}px,0)`, filter: b1 > 1.5 ? 'url(#mbp1)' : undefined, background: `linear-gradient(180deg, #5a17c4, ${PUR} 55%, #8a3bf2)`, boxShadow: '18px 0 40px rgba(16,4,40,.45)', overflow: 'hidden'}}>
      {['B', 'O', 'X'].map((c, i) => { const kk = sp(t, a - 0.02 + i * 0.09, 3.6, 0.45); return <div key={c} style={{position: 'absolute', left: 0, width: 400, top: 250 + i * 440, textAlign: 'center', fontFamily: 'Mk', fontSize: 400, lineHeight: 1, color: PURK, transform: `scale(${kk.toFixed(3)}) rotate(${(i - 1) * -7 + (1 - kk) * 30}deg)`, textShadow: '7px 9px 0 rgba(255,210,58,.9), 0 20px 30px rgba(10,0,30,.4)'}}>{c}</div>; })}
    </div>
    <div style={{position: 'absolute', left: 400, top: 0, width: 372, height: 1920, transform: `translate(0,${((k2 - 1) * 1960).toFixed(1)}px)`, filter: b2 > 1.5 ? 'url(#mbp2)' : undefined, background: `linear-gradient(180deg, #ffe36a, ${YEL} 50%, ${YELD})`, boxShadow: '18px 0 40px rgba(16,4,40,.4)', overflow: 'hidden'}}>
      {['29,', '500', 'Ks'].map((c, i) => { const kk = sp(t, a2 - 0.06 + i * 0.045, 4.2, 0.55); return <div key={c} style={{position: 'absolute', left: 0, width: 372, top: 330 + i * 330, textAlign: 'center', fontFamily: 'Co', fontSize: i === 2 ? 220 : 228, lineHeight: 1, color: PURD, transform: `translate(0,${((1 - kk) * 80).toFixed(1)}px)`, opacity: cl(kk * 2)}}>{c}</div>; })}
      <svg width={372} height={1920} style={{position: 'absolute', left: 0, top: 0}} fill="none" stroke={PURD} strokeWidth={2.2} strokeLinecap="round">
        <path d="M60,250 q40,-70 90,-10 q-60,10 -90,10 M150,240 q30,-60 80,-30 q-40,30 -80,30 M72,1380 q60,40 120,-6 M300,300 l0,60 M270,330 l60,0 M70,1500 l0,50 M45,1525 l50,0 M290,1440 q-40,-50 -8,-90 q40,40 8,90"/></svg>
      <div style={{position: 'absolute', left: 0, width: 372, top: 1610, textAlign: 'center', fontFamily: 'M8', fontSize: 30, letterSpacing: '0.3em', color: PURD}}>BLOX FRUITS</div>
    </div>
  </>;
};
// drop · diagonal ribbon collage
const Ribbon: React.FC<{t: number; a: number; v: number}> = ({t, a, v}) => {
  const lt = t - a, flip = v ? -1 : 1, ry = lerp(-9, 7, seg(lt, -0.1, B + 0.15)) * flip, word = v ? 'New In' : 'FlexiToys';
  const pop = (i: number) => sp(t, a - 0.06 + i * 0.05, 3.4, 0.5);
  const cuts = v === 0 ? [['blox3d', 730, 1290, 760, -7, 160], ['mchand', 280, 520, 500, -12, 60], ['robf', 235, 1120, 330, 8, 110]] as const
    : [['sets3', 730, 1100, 680, 6, 160], ['sets', 330, 480, 640, -10, 60], ['mccount', 230, 1010, 320, -8, 110]] as const;
  return <div style={{position: 'absolute', inset: 0, perspective: 1500, background: PURD}}>
    <div style={{position: 'absolute', inset: -140, transformStyle: 'preserve-3d', transform: `rotateY(${ry.toFixed(2)}deg) rotateX(${(3 - lt * 4).toFixed(2)}deg) scale(${(1.02 + lt * 0.07).toFixed(4)})`}}>
      <div style={{position: 'absolute', inset: -300, transform: 'translateZ(-260px)', background: `linear-gradient(${v ? 215 : 145}deg, #fff0a0 0%, ${YEL} 16%, #ff9d5c 34%, #c453f0 52%, ${PUR} 72%, ${PURD} 100%)`}}/>
      <div style={{position: 'absolute', left: 140, top: 140, width: 1080, height: 1920, transformStyle: 'preserve-3d'}}>
        <div style={{position: 'absolute', left: 540, top: 1010, width: 3000, height: 340, marginLeft: -1500, marginTop: -170, transform: `translateZ(-60px) rotate(${-38 * flip}deg)`, background: `linear-gradient(180deg, #4a12a8, #6a1fd0 50%, #4a12a8)`, borderTop: `10px solid ${YEL}`, borderBottom: '10px solid rgba(255,255,255,.75)', boxShadow: '0 30px 60px rgba(16,2,50,.5)', overflow: 'hidden'}}>
          <div style={{position: 'absolute', left: 0, top: 16, whiteSpace: 'nowrap', fontFamily: 'Ab', fontSize: 270, lineHeight: 1, color: PURK, opacity: 0.86, filter: 'blur(1.6px)', transform: `translate(${(-420 - lt * 330 * flip).toFixed(1)}px,0)`}}>{(word + '  ·  ').repeat(7)}</div>
        </div>
        <div style={{position: 'absolute', left: 540, top: 1010, width: 3000, height: 36, marginLeft: -1500, marginTop: 250, transform: `translateZ(-30px) rotate(${-38 * flip}deg)`, background: 'rgba(255,255,255,.55)'}}/>
        <Svg style={{filter: GLOW, transform: 'translateZ(40px)'}}>
          <Streak d="M-60,700 C200,300 620,260 700,560 C760,820 300,900 180,640 C100,440 420,300 600,420" t={t} ph={0.1 + v * 0.3}/>
          <Streak d="M1160,900 C900,1000 420,1180 120,1700 C60,1800 200,1880 420,1790" t={t} ph={0.6} speed={1.1} w={7}/>
          <Streak d="M380,1500 C600,1280 1040,1300 1000,1560 C960,1760 620,1760 560,1600" t={t} ph={0.3} speed={1.3} w={6} color="#fff"/>
        </Svg>
        {cuts.map(([n, x, y, w, rot, z], i) => { const kk = pop(i); return <Cut key={n} n={n} st glow="white" x={x * flip + (flip < 0 ? 1080 : 0)} y={y} w={w} z={z} rot={rot * flip + (1 - kk) * 16 + lt * 5 * (i % 2 ? -1 : 1)} s={lerp(0.6, 1, kk)}/>; })}
        <Svg style={{transform: 'translateZ(180px)'}}><Spark x={860} y={420} s={34} t={t}/><Spark x={170} y={900} s={24} t={t} ph={0.4}/><Spark x={620} y={1640} s={30} t={t} ph={0.7}/><Spark x={960} y={980} s={18} t={t} ph={0.2}/><Spark x={420} y={300} s={16} t={t} ph={0.55}/></Svg>
      </div>
    </div>
    <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(circle at 14% 10%, rgba(255,250,210,.6), rgba(255,250,210,0) 46%), radial-gradient(circle at 92% 88%, rgba(255,170,255,.35), rgba(255,170,255,0) 40%)', mixBlendMode: 'screen', pointerEvents: 'none'}}/>
    <Hazard y={1856} t={t}/>
    {v === 1 && <At x={540} y={1585}><div style={{fontFamily: 'MM, Mo', fontSize: 104, lineHeight: 1.5, color: '#fff', whiteSpace: 'nowrap', textShadow: `${extrude(7, PURK)}, 0 14px 26px rgba(10,0,40,.6)`, transform: `scale(${sp(t, a - 0.02, 3.4, 0.5).toFixed(3)}) rotate(-3deg)`}}>အသစ်တွေ <span style={{color: YEL}}>ရောက်ပြီ!</span></div></At>}
    <Blossoms t={t} seed={60 + v} at={v ? [[990, 150, 190], [880, 70, 110], [1040, 330, 90], [60, 1730, 170], [190, 1840, 100]] : [[80, 140, 190], [220, 60, 110], [40, 330, 90], [1010, 1700, 170], [900, 1830, 100]]}/>
  </div>;
};
// drop · poster with the real price
const Poster: React.FC<{t: number; a: number; v: number}> = ({t, a, v}) => {
  const lt = t - a, k = sp(t, a - 0.06, 3.2, 0.5), ry = lerp(15, -7, seg(lt, -0.1, B + 0.15)) * (v ? -1 : 1);
  const title = v ? 'MINECRAFT' : 'BLOX FRUITS', cut = v ? 'mcf' : 'blox3d', price = v ? '19,500 Ks' : '29,500 Ks';
  return <div style={{position: 'absolute', inset: 0, perspective: 1500, background: 'linear-gradient(180deg,#e9e4ee,#cfc8d8)'}}>
    {[[-80, 300, 0.75], [900, 300, 0.7], [-160, 160, 0.5], [1050, 140, 0.5]].map(([x, w, o], i) => <div key={i} style={{position: 'absolute', left: x + (i % 2 ? -1 : 1) * lt * 60, top: -100, width: w, height: 2120, background: `rgba(30,20,48,${o})`, filter: 'blur(26px)'}}/>)}
    <div style={{position: 'absolute', left: 150, top: 300, width: 780, height: 1290, transformStyle: 'preserve-3d', transform: `rotateY(${ry.toFixed(2)}deg) rotateX(${(4 - lt * 5).toFixed(2)}deg) scale(${(lerp(0.8, 1, k) * (1 + lt * 0.06)).toFixed(4)})`}}>
      <div style={{position: 'absolute', inset: 0, background: `linear-gradient(180deg,#fff0a0, ${YEL} 45%, ${YELD})`, boxShadow: '0 50px 80px rgba(20,8,40,.5), 0 0 60px rgba(255,220,90,.5)', overflow: 'hidden'}}>
        <svg width={780} height={1290} style={{position: 'absolute', left: 0, top: 0}}><polygon transform={`translate(390 640) rotate(${(lt * 30).toFixed(1)}) scale(420)`} points={Array.from({length: 10}, (_, i) => { const r = i % 2 ? 0.42 : 1, an = i * TAU / 10 - TAU / 4; return `${(r * Math.cos(an)).toFixed(3)},${(r * Math.sin(an)).toFixed(3)}`; }).join(' ')} fill="rgba(255,255,255,.42)"/></svg>
        <div style={{position: 'absolute', left: 0, right: 0, top: 54, textAlign: 'center', fontFamily: 'Bo', fontSize: v ? 96 : 88, letterSpacing: '0.1em', color: PURK, whiteSpace: 'nowrap', textShadow: '0 4px 10px rgba(60,20,0,.3)'}}>{title}</div>
        <div style={{position: 'absolute', left: 60, right: 60, top: 176, height: 5, background: PURK}}/>
        <div style={{position: 'absolute', left: 0, right: 0, top: 196, textAlign: 'center', fontFamily: 'M8', fontSize: 30, letterSpacing: '0.5em', color: PURK}}>BLIND BOX</div>
        <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 210, background: `linear-gradient(180deg, ${PUR}, ${PURD})`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Al', fontSize: 124, color: '#fff', textShadow: `${extrude(6, PURK)}, 0 10px 20px rgba(10,0,40,.5)`, whiteSpace: 'nowrap'}}>
          <span style={{transform: `scale(${sp(t, a + 0.06, 3.6, 0.45).toFixed(3)})`, display: 'inline-block'}}>{price}</span></div>
        <Shine k={seg(lt, 0.1, 0.5)}/>
      </div>
      <svg width={780} height={1290} viewBox="0 0 780 1290" style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', filter: GLOW, transform: 'translateZ(70px)'}}>
        <Streak d="M390,330 C760,330 800,900 390,940 C-20,900 20,330 390,330" t={t} speed={1.5} len={0.5} ph={v * 0.4}/>
        <Streak d="M120,760 C200,420 600,380 690,640 C760,900 300,1020 160,820" t={t} speed={1.2} len={0.4} ph={0.5} w={6} color="#fff"/></svg>
      <Img src={F(cut + '_st.png')} style={{position: 'absolute', left: 390, top: 660, width: v ? 560 : 620, transform: `translate(-50%,-50%) translateZ(140px) rotate(${(lerp(-14, 4, k) + lt * 8).toFixed(2)}deg) scale(${lerp(0.5, 1, k).toFixed(3)})`, filter: 'drop-shadow(0 0 18px rgba(255,255,255,.85)) drop-shadow(0 30px 30px rgba(40,10,80,.5))'}}/>
      <svg width={780} height={1290} viewBox="0 0 780 1290" style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', transform: 'translateZ(200px)'}}><Spark x={640} y={380} s={30} t={t}/><Spark x={130} y={900} s={24} t={t} ph={0.5}/><Spark x={660} y={980} s={18} t={t} ph={0.25}/></svg>
    </div>
    <Blossoms t={t} seed={70 + v} at={v ? [[980, 210, 200], [1040, 420, 110], [870, 90, 90], [90, 1700, 180], [230, 1830, 100]] : [[90, 210, 200], [40, 420, 110], [210, 90, 90], [990, 1700, 180], [850, 1830, 100]]}/>
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 44, background: PUR}}/>
  </div>;
};
// drop · four stamp cards tilted in space around a turning cut-out, over the real stall (blurred)
const Cards: React.FC<{t: number; a: number; v: number}> = ({t, a, v}) => {
  const lt = t - a, dir = v ? -1 : 1;
  const cards = v === 0
    ? [['t_blox.jpg', 'BLOX\nFRUITS', 'Blind Box · 29,500 Ks', 58], ['t_mc.jpg', 'MINE\nCRAFT', 'Blind Box · 19,500 Ks', 62], ['t_roblox.jpg', 'ROBLOX', 'Mystery Box', 62], ['t_sets.jpg', 'SETS', 'Building Blocks', 92]]
    : [['t_keys.jpg', 'KEY\nCHAINS', 'Keychains', 64], ['t_cars.jpg', 'MINI\nCARS', 'Mini Cars', 72], ['t_sets.jpg', 'BLOCKS', 'Building Blocks', 64], ['t_roblox.jpg', 'ROBLOX', 'Mystery Box', 62]];
  const pos = [[255, 450, -10, 20], [830, 420, 8, -18], [245, 1440, 7, 16], [835, 1470, -8, -20]];
  return <div style={{position: 'absolute', inset: 0, perspective: 1400, background: '#bfb8c8'}}>
    <Img src={F('stall_blur.jpg')} style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, transform: `scale(${(1.14 + lt * 0.05).toFixed(4)}) translate(${(dir * lt * -20).toFixed(1)}px,0)`}}/>
    <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 46%, rgba(255,255,255,.55), rgba(255,255,255,0) 55%), linear-gradient(180deg, rgba(90,30,200,.18), rgba(255,210,58,.14))'}}/>
    <div style={{position: 'absolute', inset: 0, transformStyle: 'preserve-3d', transform: `rotateZ(${(dir * lerp(-4, 3, seg(lt, -0.1, B + 0.15))).toFixed(2)}deg) rotateY(${(dir * lerp(-8, 6, seg(lt, -0.1, B + 0.15))).toFixed(2)}deg) scale(${(1 + lt * 0.07).toFixed(4)})`}}>
      {cards.map(([img, label, sub, ls], i) => { const [x, y, rz, ryy] = pos[i], kk = sp(t, a - 0.08 + i * 0.035, 3.0, 0.55), ox = (x - 540) * 1.3, oy = (y - 960) * 1.1;
        return <div key={i} style={{position: 'absolute', left: x + ox * (1 - kk), top: y + oy * (1 - kk), transform: `translate(-50%,-50%) translateZ(${40 + i * 20}px) rotateY(${ryy + lt * dir * 14}deg) rotateZ(${rz + (1 - kk) * 30 * (i % 2 ? 1 : -1)}deg)`}}>
          <Stamp w={410} h={540} img={img as string} label={label as string} ls={ls as number} sub={sub as string} shine={seg(lt, 0.1 + i * 0.05, 0.46 + i * 0.05)}/></div>; })}
      <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', filter: GLOW, transform: 'translateZ(120px)'}}>
        <Streak d="M540,620 C900,640 900,1260 540,1290 C180,1260 180,640 540,620" t={t} speed={1.5} len={0.5}/>
        <Streak d="M100,1000 C300,700 800,760 960,1000 C800,1240 300,1200 100,1000" t={t} speed={1.2} ph={0.4} w={6} color="#fff"/></svg>
      <Cut n={v ? 'mcf' : 'robf'} st glow="white" x={540} y={950} w={v ? 430 : 380} z={200} rot={dir * (-24 + lt * 90)} s={lerp(0.4, 1, sp(t, a - 0.05, 3.2, 0.5))}/>
      <Svg style={{transform: 'translateZ(240px)'}}><Spark x={760} y={760} s={30} t={t}/><Spark x={330} y={1150} s={24} t={t} ph={0.5}/><Spark x={560} y={1320} s={16} t={t} ph={0.3}/></Svg>
    </div>
    <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}} fill="none" stroke={INK} strokeLinecap="round"><g transform={`translate(0 ${(lt * -30).toFixed(1)})`}><Scrib seed={81 + v} x={360} y={90} w={360} h={90} k={1} rot={-4} sw={2.6}/><Scrib seed={85 + v} x={380} y={1760} w={340} h={80} k={1} rot={5} sw={2.6}/></g></svg>
  </div>;
};
// drop · everything else the shop sells: keychains and mini cars around one glossy word
const Emblem: React.FC<{t: number; a: number}> = ({t, a}) => {
  const lt = t - a, k = sp(t, a - 0.06, 3.2, 0.48);
  const cuts = [['pig', 215, 450, 370, -12, 140], ['keygreen', 850, 480, 400, 14, 90], ['jeep', 245, 1450, 440, 10, 160], ['ladder', 860, 1400, 330, -6, 110], ['keymint', 560, 1700, 420, 4, 60]] as const;
  return <div style={{position: 'absolute', inset: 0, perspective: 1300, background: `linear-gradient(160deg, #fff0a0, ${YEL} 18%, #ff9d5c 40%, #a23bf0 66%, ${PURD})`}}>
    <div style={{position: 'absolute', inset: 0, transformStyle: 'preserve-3d', transform: `rotateY(${lerp(8, -8, seg(lt, -0.1, B + 0.15)).toFixed(2)}deg) rotateX(${(lt * 6 - 2).toFixed(2)}deg) scale(${(1 + lt * 0.08).toFixed(4)})`}}>
      {[[820, 1320, 0, 'rgba(255,255,255,.5)', -8, -140], [700, 1140, 1, YEL, 6, -80], [580, 960, 2, 'rgba(255,255,255,.85)', -3, -30]].map(([w, h, i, c, r, z]) =>
        <div key={i as number} style={{position: 'absolute', left: 540, top: 960, width: w as number, height: h as number, marginLeft: -(w as number) / 2, marginTop: -(h as number) / 2, border: `${i === 1 ? 26 : 12}px solid ${c}`, borderRadius: 40, transform: `translateZ(${z}px) rotate(${(r as number) + lt * (i === 1 ? -14 : 10)}deg)`, boxShadow: '0 20px 50px rgba(30,5,80,.35)'}}/>)}
      <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', filter: GLOW, transform: 'translateZ(20px)'}}>
        <Streak d="M-40,1300 C200,900 880,1040 1120,620" t={t} speed={1.4} len={0.5}/><Streak d="M1120,1500 C760,1400 320,560 -40,520" t={t} speed={1.1} ph={0.5} w={6} color="#fff"/></svg>
      <At x={540} y={900} tf={`translateZ(120px) scale(${lerp(1.6, 1, k).toFixed(3)}) rotate(-4deg)`}><div style={{fontFamily: 'MM, Mo', fontSize: 330, lineHeight: 1.45, color: '#fff', whiteSpace: 'nowrap', textShadow: `${extrude(12, PURD)}, 0 0 50px rgba(255,255,255,.7), 0 26px 40px rgba(20,0,60,.55)`}}>အစုံ</div></At>
      <At x={540} y={1150} tf="translateZ(130px) rotate(-4deg)"><div style={{fontFamily: 'Al', fontSize: 58, color: YEL, whiteSpace: 'nowrap', textShadow: `${extrude(4, PURK)}, 0 8px 16px rgba(10,0,40,.5)`, opacity: seg(lt, 0.04, 0.12)}}>KEYCHAINS · MINI CARS</div></At>
      {cuts.map(([n, x, y, w, rot, z], i) => { const kk = sp(t, a - 0.06 + i * 0.04, 3.4, 0.5); return <Cut key={n} n={n} st glow="white" x={x + (x - 540) * (1 - kk)} y={y + (y - 960) * 0.6 * (1 - kk)} w={w} z={z} rot={rot + lt * 14 * (i % 2 ? -1 : 1)} s={lerp(0.5, 1, kk)}/>; })}
      <Svg style={{transform: 'translateZ(220px)'}}><Spark x={800} y={820} s={34} t={t}/><Spark x={250} y={1060} s={24} t={t} ph={0.45}/><Spark x={610} y={420} s={20} t={t} ph={0.7}/><Spark x={470} y={1420} s={18} t={t} ph={0.2}/></Svg>
    </div>
    <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(circle at 14% 10%, rgba(255,250,210,.6), rgba(255,250,210,0) 46%), radial-gradient(circle at 92% 88%, rgba(255,170,255,.35), rgba(255,170,255,0) 40%)', mixBlendMode: 'screen', pointerEvents: 'none'}}/>
    <Hazard y={0} h={40} t={-t}/>
  </div>;
};
// where? on crumpled paper
const Where: React.FC<{t: number; a: number}> = ({t, a}) => {
  const lt = t - a, parts = clusters('ဘယ်မှာလဲ?');
  return <>
    <Paper crumple s={1.12} dx={lt * 30}/>
    <Svg style={{filter: 'blur(1.4px)'}}><path d={brushD(-80, 520, 500, 900, 1180, 600, 30, seg(lt, -0.05, 0.25))} fill={INK}/><path d={brushD(1160, 1400, 600, 1150, -80, 1500, 24, seg(lt, 0, 0.3))} fill={INK}/></Svg>
    <Svg><Scrib seed={91} x={80} y={250} w={420} h={200} n={6} k={seg(lt, 0, 0.25)} rot={-12}/><Scrib seed={95} x={600} y={1500} w={400} h={200} n={6} k={seg(lt, 0.05, 0.3)} rot={-10}/></Svg>
    <div style={{position: 'absolute', left: 200, top: 640, display: 'flex', gap: 14}}>{[YEL, PUR].map((c, i) => { const kk = sp(t, a + 0.02 + i * 0.06, 4, 0.45); return <div key={c} style={{width: 44, height: 44, borderRadius: 10, background: c, transform: `scale(${kk.toFixed(3)})`, boxShadow: '0 6px 12px rgba(16,8,24,.35)'}}/>; })}</div>
    <At x={540} y={900} tf={`rotate(-3deg) scale(${(1 + lt * 0.08).toFixed(4)})`}><div style={{display: 'flex', fontFamily: 'MM, Mo', fontSize: 212, lineHeight: 1.5, color: INK, whiteSpace: 'nowrap', textShadow: '-1px -2px 0 rgba(255,255,255,.5), 0 16px 24px rgba(16,8,24,.5), 0 34px 50px rgba(16,8,24,.28)'}}>
      {parts.map((p, i) => { const kk = sp(t, a - 0.05 + i * 0.05, 3.6, 0.5); return <span key={i} style={{display: 'inline-block', transform: `translate(0,${((1 - kk) * 110).toFixed(1)}px) rotate(${((1 - kk) * 10).toFixed(1)}deg)`, opacity: cl(kk * 3)}}>{p}</span>; })}</div></At>
    <div style={{position: 'absolute', left: 300, top: 1090, width: 480 * easeOut(seg(lt, 0.1, 0.3)), height: 12, borderRadius: 6, background: PUR, transform: 'rotate(-3deg)'}}/>
  </>;
};
// the stall itself, as a big stamp card
const Stall: React.FC<{t: number; a: number}> = ({t, a}) => {
  const lt = t - a, k = sp(t, a - 0.07, 3.0, 0.52);
  return <div style={{position: 'absolute', inset: 0, perspective: 1500, background: `linear-gradient(200deg, #fff0a0, ${YEL} 22%, #ff9d5c 44%, #a23bf0 70%, ${PURD})`}}>
    <div style={{position: 'absolute', left: 540, top: 820, width: 3000, height: 300, marginLeft: -1500, marginTop: -150, transform: 'rotate(32deg)', background: 'linear-gradient(180deg,#4a12a8,#6a1fd0 50%,#4a12a8)', borderTop: `10px solid ${YEL}`, borderBottom: '10px solid rgba(255,255,255,.75)', overflow: 'hidden'}}>
      <div style={{position: 'absolute', left: 0, top: 22, whiteSpace: 'nowrap', fontFamily: 'Ab', fontSize: 230, lineHeight: 1, color: PURK, opacity: 0.85, filter: 'blur(1.6px)', transform: `translate(${(-600 + lt * 300).toFixed(1)}px,0)`}}>{'Junction Centre  ·  '.repeat(5)}</div></div>
    <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', filter: GLOW}}><Streak d="M-40,500 C300,200 900,300 1120,760" t={t} speed={1.4} len={0.5}/><Streak d="M1120,1250 C800,1500 300,1300 -40,1650" t={t} speed={1.1} ph={0.5} w={6} color="#fff"/></svg>
    <div style={{position: 'absolute', left: 540, top: 700, transformStyle: 'preserve-3d', transform: `translate(-50%,-50%) rotateY(${lerp(-22, -8, seg(lt, -0.1, B + 0.2)).toFixed(2)}deg) rotateZ(${lerp(-10, -3, k).toFixed(2)}deg) scale(${(lerp(0.7, 1, k) * (1 + lt * 0.05)).toFixed(4)})`}}>
      <Stamp w={700} h={930} img="card_stall.jpg" shine={seg(lt, 0.12, 0.5)}/></div>
    <At x={540} y={1360} tf={`rotate(-3deg) scale(${sp(t, a + 0.02, 3.4, 0.5).toFixed(3)})`}><div style={{fontFamily: 'Al', fontSize: 100, color: '#fff', whiteSpace: 'nowrap', textShadow: `${extrude(7, PURK)}, 0 14px 26px rgba(10,0,40,.6)`}}>Junction Centre</div></At>
    <At x={540} y={1510} tf={`rotate(-3deg) scale(${sp(t, a + 0.12, 3.4, 0.5).toFixed(3)})`}><div style={{fontFamily: 'MM, Mo', fontSize: 112, lineHeight: 1.5, color: YEL, whiteSpace: 'nowrap', textShadow: `${extrude(7, PURK)}, 0 14px 26px rgba(10,0,40,.6)`}}>နေပြည်တော်</div></At>
    <Svg><Spark x={900} y={380} s={34} t={t}/><Spark x={160} y={1180} s={24} t={t} ph={0.45}/><Spark x={930} y={1300} s={20} t={t} ph={0.7}/></Svg>
    <Blossoms t={t} seed={77} at={[[70, 150, 190], [200, 60, 100], [1000, 1760, 170], [880, 1850, 100]]}/>
    <Hazard y={1860} t={t}/>
  </div>;
};
// end card: dark, flares, the wordmark in light, where to find the shop, the call to action
const End: React.FC<{t: number; a: number}> = ({t, a}) => {
  const lt = t - a, k = sp(t, a - 0.05, 3.0, 0.5), tA = a + B, tC = a + 2 * B, handle = '@flexitoysmm', nH = Math.floor(cl((t - (tA + 0.3)) / 0.032, 0, handle.length));
  const cta = [...clusters('ဒီနေ့ပဲ'), ' ', ...clusters('လာခဲ့နော်!')], fl = 0.75 + 0.25 * Math.sin(lt * 5);
  // the wordmark slams in from 2.6x: blur it by its own speed so the 4 blended samples read as one smear, not 4 copies
  const msc = (tt: number) => { const kk = sp(tt, a - 0.05, 3.0, 0.5); return lerp(2.6, 1, cl(kk)) * (kk > 1 ? 1 - 0.3 * (kk - 1) : 1) * (1 + (tt - a) * 0.012); };
  const mb = 0.5 * Math.abs(msc(t + 1 / 240) - msc(t - 1 / 240)) * 520;
  return <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 36%, #45148f 0%, #1d0840 40%, #07020f 100%)'}}>
    <div style={{position: 'absolute', left: -200, top: 628, width: 1480, height: 10, background: 'linear-gradient(90deg, rgba(0,0,0,0), #a877ff 30%, #fff 50%, #a877ff 70%, rgba(0,0,0,0))', filter: 'blur(5px)', opacity: fl, transform: `scaleX(${(0.3 + 0.7 * easeOut(seg(lt, 0, 0.5))).toFixed(3)})`}}/>
    <div style={{position: 'absolute', left: 540 - 520, top: 632 - 520, width: 1040, height: 1040, background: 'radial-gradient(circle, rgba(190,140,255,.5) 0%, rgba(140,80,255,.16) 30%, rgba(0,0,0,0) 62%)', opacity: fl}}/>
    {[[160, 300, 150, '#ffd23a'], [930, 1250, 110, '#b98cff'], [860, 250, 70, '#fff']].map(([x, y, r, c], i) => <div key={i} style={{position: 'absolute', left: (x as number) - (r as number) + Math.sin(lt * 1.2 + i) * 24, top: (y as number) - (r as number), width: 2 * (r as number), height: 2 * (r as number), borderRadius: '50%', background: `radial-gradient(circle, ${c} 0%, rgba(0,0,0,0) 65%)`, opacity: 0.4 * seg(lt, 0, 0.3)}}/>)}
    <Cut n="blox3d" st glow="white" x={205} y={330 + Math.sin(lt * 2) * 12} w={340} rot={-12 + lt * 3} s={sp(t, a + 0.05, 3.2, 0.5)}/>
    <Cut n="mchand" st glow="white" x={880} y={345 + Math.cos(lt * 2) * 12} w={300} rot={12 - lt * 3} s={sp(t, a + 0.1, 3.2, 0.5)}/>
    <At x={540} y={720} tf={`scale(${msc(t).toFixed(4)})`}><div style={{filter: mb > 1 ? `blur(${Math.min(40, mb).toFixed(1)}px)` : undefined}}><Mark lines={['FLEXI', 'TOYS']} size={270} t={t} sweep={seg(lt, 0.25, 0.95)} light/></div></At>
    <At x={540} y={1058}><div style={{opacity: seg(lt, 0.1, 0.2)}}><Glitch parts={clusters('အရုပ်ဆိုင်')} font="MS" size={104} color={YEL} t={t} seed={99} gap={0.03} amt={0.6} shadow="0 4px 18px rgba(255,190,40,.55)"/></div></At>
    <At x={540} y={1232} tf={`translate(0,${((1 - sp(t, tA - 0.05, 3.4, 0.55)) * 70).toFixed(1)}px)`}><div style={{opacity: seg(t, tA - 0.04, tA + 0.03), padding: '14px 40px 6px', borderTop: '3px solid rgba(255,255,255,.7)', borderBottom: '3px solid rgba(255,255,255,.7)', fontFamily: 'MM, Mo', fontSize: 60, lineHeight: 1.6, color: '#fff', whiteSpace: 'nowrap', textShadow: '0 0 22px rgba(170,110,255,.9)'}}><span style={{fontFamily: 'M8'}}>Junction Centre · </span>နေပြည်တော်</div></At>
    <At x={540} y={1352}><div style={{fontFamily: 'M8', fontSize: 50, color: '#d9c6ff', letterSpacing: '0.04em', whiteSpace: 'nowrap', height: 60}}><span style={{opacity: nH > 0 ? 0.75 : 0, fontSize: 34, marginRight: 14}}>TikTok</span>{handle.slice(0, nH)}</div></At>
    <At x={540} y={1516} tf="rotate(-3deg)"><div style={{display: 'flex', fontFamily: 'MM, Mo', fontSize: 118, lineHeight: 1.5, color: YEL, whiteSpace: 'pre', textShadow: `${extrude(8, PURD)}, 0 0 40px rgba(255,200,60,.55), 0 18px 30px rgba(0,0,0,.6)`}}>
      {cta.map((p, i) => { const kk = sp(t, tC - 0.05 + i * 0.045, 3.6, 0.46); return <span key={i} style={{display: 'inline-block', transform: `scale(${kk.toFixed(3)}) translate(0,${((1 - kk) * 40).toFixed(1)}px)`, opacity: cl(kk * 3)}}>{p}</span>; })}</div></At>
    <Svg><Spark x={300} y={640} s={30} t={t}/><Spark x={820} y={900} s={22} t={t} ph={0.4}/><Spark x={170} y={1500} s={18} t={t} ph={0.7}/><Spark x={940} y={1520} s={26} t={t} ph={0.15}/><Spark x={560} y={300} s={16} t={t} ph={0.55}/></Svg>
  </div>;
};

export const Dg: React.FC = () => {
  const frame = useCurrentFrame(), {fps} = useVideoConfig(), t = frame / fps;
  const [h] = useState(() => delayRender('fonts'));
  useEffect(() => { Promise.all(FAMS.map(f => (document as any).fonts.load(`40px ${f}`, f === 'MS' || f === 'MM' ? 'အ' : 'A'))).then(() => continueRender(h), () => continueRender(h)); }, [h]);
  const DROP = bt(8), tq = Math.floor(t * 30) / 30;                                    // shake is sampled once per OUTPUT frame
  const beats = [9, 10, 11, 12, 13, 14, 15, 16, 17];
  const punch = 0.09 * hit(t, DROP, 0.16) + beats.reduce((s, n) => s + 0.035 * hit(t, bt(n), 0.1), 0);
  const sh = hit(tq, DROP, 0.17) * 26 + hit(tq, bt(17), 0.14) * 14, sx = Math.sin(tq * 97) * sh, sy = Math.cos(tq * 83) * sh;
  const inv = t >= bt(12) - 0.005 && t < bt(12) + 0.062;                                // two-frame negative flash, as in the reference
  return <AbsoluteFill style={{background: '#0c0518'}}>
    <style>{FONT}</style>
    <AbsoluteFill style={{transform: `translate(${sx.toFixed(1)}px,${sy.toFixed(1)}px) scale(${(1 + punch).toFixed(4)})`, filter: inv ? 'invert(1) hue-rotate(180deg)' : undefined}}>
      <Scene t={t} a={-1} b={bt(1)} tout="zoom"><Hook t={t}/></Scene>
      <Scene t={t} a={bt(1)} b={bt(2)} tin="zoom" tout="zoom"><MarkScene t={t} a={bt(1)} v={0}/></Scene>
      {[0, 1, 2, 3].map(i => <Scene key={i} t={t} a={bt(2 + i / 2)} b={bt(2.5 + i / 2)} tin="zoom" tout={i === 3 ? 'spin' : 'zoom'}><CutScene t={t} a={bt(2 + i / 2)} i={i}/></Scene>)}
      <Scene t={t} a={bt(4)} b={bt(5)} tin="spin" tout="L"><MarkScene t={t} a={bt(4)} v={1}/></Scene>
      <Scene t={t} a={bt(5)} b={bt(8)} tin="L" tout="cut"><TypeScene t={t} a={bt(5)}/>{t < bt(8) && <Panels t={t} a={bt(7)}/>}</Scene>
      <Scene t={t} a={bt(8)} b={bt(9)} tin="cut" tout="U"><Ribbon t={t} a={bt(8)} v={0}/></Scene>
      <Scene t={t} a={bt(9)} b={bt(10)} tin="U" tout="L"><Poster t={t} a={bt(9)} v={0}/></Scene>
      <Scene t={t} a={bt(10)} b={bt(11)} tin="L" tout="spin"><Cards t={t} a={bt(10)} v={0}/></Scene>
      <Scene t={t} a={bt(11)} b={bt(12)} tin="spin" tout="DR"><Emblem t={t} a={bt(11)}/></Scene>
      <Scene t={t} a={bt(12)} b={bt(13)} tin="DR" tout="D"><Ribbon t={t} a={bt(12)} v={1}/></Scene>
      <Scene t={t} a={bt(13)} b={bt(14)} tin="D" tout="R"><Poster t={t} a={bt(13)} v={1}/></Scene>
      <Scene t={t} a={bt(14)} b={bt(15)} tin="R" tout="UL"><Cards t={t} a={bt(14)} v={1}/></Scene>
      <Scene t={t} a={bt(15)} b={bt(16)} tin="UL" tout="L"><Where t={t} a={bt(15)}/></Scene>
      <Scene t={t} a={bt(16)} b={bt(17)} tin="L" tout="zoom"><Stall t={t} a={bt(16)}/></Scene>
      <Scene t={t} a={bt(17)} b={99} tin="zoom"><End t={t} a={bt(17)}/></Scene>
    </AbsoluteFill>
    <AbsoluteFill style={{background: '#fff', opacity: 0.8 * hit(t, DROP, 0.07) + 0.45 * hit(t, bt(17), 0.06), pointerEvents: 'none'}}/>
  </AbsoluteFill>;
};
