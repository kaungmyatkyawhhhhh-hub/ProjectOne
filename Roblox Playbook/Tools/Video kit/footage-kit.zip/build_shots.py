"""Time-remap every shot (speed ramp: fast in, slow on the beat) with real frame blending, 30 fps, with handles for transitions."""
import json, subprocess, sys, numpy as np, cv2
SRC = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1].endswith('.json') else 'src/shots.json'; OUT = sys.argv[2] if SRC != 'src/shots.json' else 'public/shots'
J = json.load(open(SRC)); H = J['handle']; FPS = 30
only = set()
def g(u, k, p):                      # eased progress; slope k + (1-k)p at the start, k at the end
    if u < 0: return (k + (1 - k) * p) * u
    if u > 1: return 1 + k * (u - 1)
    return k * u + (1 - k) * (1 - (1 - u) ** p)
for s in J['shots']:
    if only and s['id'] not in only: continue
    cap = cv2.VideoCapture(f"sdr/IMG_{s['clip']}.mp4"); nsrc = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)); sf = cap.get(cv2.CAP_PROP_FPS)
    k, p = s.get('k', 0.35), s.get('p', 2.4); n = int(round((s['d'] + 2 * H) * FPS))
    src = lambda x: (s['a'] + (s['b'] - s['a']) * g(x / s['d'], k, p)) * sf
    out = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'bgr24', '-s', '1080x1920', '-r', str(FPS), '-i', '-', '-c:v', 'libx264', '-preset', 'fast', '-crf', '13', '-g', '5', '-pix_fmt', 'yuv420p', f"{OUT}/{s['id']}.mp4"], stdin=subprocess.PIPE)
    cur = -1; frame = None; cache = {}
    def get(i):
        global cur, frame
        i = int(min(max(i, 0), nsrc - 1))
        if i in cache: return cache[i]
        if i < cur: cap.set(cv2.CAP_PROP_POS_FRAMES, i); cur = i - 1
        while cur < i:
            ok, f = cap.read(); cur += 1
            if ok: frame = f
        cache[i] = frame
        for kk in [q for q in cache if q < i - 12]: del cache[kk]
        return frame
    for i in range(n):
        x0 = -H + i / FPS; s0, s1 = src(x0), src(x0 + 0.7 / FPS)       # 0.7 shutter
        idx = sorted(set(int(round(v)) for v in np.linspace(s0, s1, int(min(8, max(1, round(abs(s1 - s0)) + 1))))))
        acc = np.zeros((1920, 1080, 3), np.float32)
        for q in idx: acc += get(q)
        fr = (acc / len(idx)).astype(np.uint8)
        if s.get('crop'):
            cx, cy, cw, ch = s['crop']; fr = cv2.resize(fr[cy:cy + ch, cx:cx + cw], (1080, 1920), interpolation=cv2.INTER_LANCZOS4)
        out.stdin.write(fr.tobytes())
    out.stdin.close(); out.wait(); cap.release()
    print(s['id'], s['clip'], n, 'frames; src speed start %.1fx end %.1fx' % ((s['b'] - s['a']) / s['d'] * (k + (1 - k) * p), (s['b'] - s['a']) / s['d'] * k), flush=True)
