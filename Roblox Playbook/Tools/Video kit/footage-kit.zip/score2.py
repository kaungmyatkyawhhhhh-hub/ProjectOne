"""FlexiToys ad v2, cut to the measured hits of a trending sound (Wyw my sweetie #JerseyClub (Slowed), 107.43 BPM, drop at 6.10 s).
Writes: public/sfx2.wav (sound effects only: the owner adds the trending sound in the TikTok app)
        out/mix2_raw.wav (our OWN music on the same grid + the sound effects) and src/events2.json."""
import json, numpy as np, scipy.signal as sg, soundfile as sf
import synth as S
J = json.load(open('src/shots2.json')); DUR = J['dur']; B = J['beat']; DROP = J['drop']; HITS = J['hits']
S.init(DUR); SR = S.SR; N = S.N; rng = S.rng
T = lambda k: DROP + (k - 11) * B          # beat k (the drop is beat 11)
EV = []
def ev(t, kind, **kw): EV.append(dict(t=round(t, 3), kind=kind, **kw))
def whip(t, pan, lab, g=0.6, lead=0.04): ev(t - lead, 'whoosh', pan=pan, dur=0.36, peak=0.5, g=g, label=lab)

ev(0.0, 'impact', size=0.9, label='hook: box in hand'); ev(0.02, 'sparkle', dur=0.6)
ev(0.54, 'pop', f=784, label='product name')
whip(1.36, (0.8, -0.8), 'whip to price', 0.35, 0.09); ev(1.36, 'thud', label='price pops in')
for k in range(5): ev(1.42 + k * 0.055, 'click', label='typing: price counts up')
ev(1.70, 'thud', label='price lands'); ev(1.70, 'bell', f=1568, label='price lands (bell)')
ev(2.50, 'thud', label='cut Minecraft / Roblox'); ev(2.50, 'pop', f=988); ev(2.78, 'pop', f=1175, label='Roblox'); ev(3.06, 'click', big=True, label='label plate')
whip(3.60, (0, 0), 'whip to the counter', 0.35, 0.09); ev(3.60, 'pop', f=880, label='Blind Box')
ev(4.13, 'thud', soft=True, label='jump zoom 1'); ev(4.13, 'pop', f=1046, label='all kinds')
ev(4.35, 'click', big=True, label='jump zoom 2'); ev(4.44, 'thud', soft=True, label='jump zoom 3')
ev(4.6, 'riser', dur=1.2); ev(5.4, 'suckback', dur=0.42)
ev(DROP, 'impact', size=1.25, label='DROP: shop name'); ev(DROP + 0.03, 'sparkle', dur=0.7)
ev(6.38, 'pop', f=1046, label='toy shop')
whip(7.22, (-0.8, 0.8), 'whip to sets', 0.45, 0.09); ev(7.24, 'pop', f=880, label='new arrivals'); ev(7.50, 'pop', f=1046, label='arrived')
for x, lab in [(8.33, 'build'), (9.46, 'mini cars'), (10.57, 'keychains')]:
    ev(x, 'thud', label='cut ' + lab); ev(x + 0.12, 'click', big=True, label='stutter'); ev(x + 0.285, 'thud', soft=True, label='stutter')
ev(8.62, 'pop', f=988, label='build word 2'); ev(10.84, 'pop', f=1175, label='keychain word 2')
whip(9.45, (0.8, -0.8), 'whip to mini cars', 0.4, 0.1)
ev(11.58, 'whoosh', pan=(0, 0), dur=0.6, peak=0.45, g=0.6, label='zoom into the mall'); ev(11.70, 'pop', f=660, label='where?')
ev(11.8, 'riser', dur=2.0)
ev(12.80, 'pop', f=784, label='Junction'); ev(12.92, 'pop', f=880, label='Centre'); ev(13.09, 'pop', f=1046, label='Nay Pyi Taw')
ev(13.92, 'impact', size=1.05, label='END CARD: shop name'); ev(13.95, 'sparkle', dur=0.6)
ev(14.47, 'pop', f=988, label='address plate')
for k in range(12): ev(14.75 + k * 0.032, 'click', label='typing: handle')
ev(15.29, 'impact', size=0.9, label='CTA'); ev(15.63, 'pop', f=1318, label='CTA word 2')

def render(neutral):
    """neutral=True: NO pitched sounds (no bells, no tonal pops, no tonal riser), so the effects can sit under ANY song without clashing with its key."""
    for e in EV:
        k, t = e['kind'], e['t']
        if k == 'impact': S.put_st(S.impact(e['size']), t, 0, 0.95)
        elif k == 'sparkle':
            if not neutral: S.put_st(S.sparkle(e['dur']), t, (-0.6, 0.6), 0.8)
        elif k == 'pop':
            if neutral: S.put_st(S.click() * 1.9, t, 0, 0.6); S.put_st(S.impact(0.4)[:int(0.16 * SR)] * 0.35, t, 0, 0.8)
            else: S.put_st(S.pop(e['f']), t, 0, 0.75)
        elif k == 'whoosh': S.put_st(S.whoosh(e['dur'], e.get('peak', 0.55)), t - e['dur'] * e.get('peak', 0.55), tuple(e['pan']), e['g'])
        elif k == 'thud': S.put_st(S.impact(0.55)[:int(0.35 * SR)] * (0.5 if e.get('soft') else 0.75), t, 0, 0.8)
        elif k == 'riser':
            if neutral: S.put_st(S.whoosh(e['dur'], 0.96, 1.3), t, 0, 0.45)
            else: S.put_st(S.riser(e['dur']), t, 0, 0.5)
        elif k == 'suckback': S.put_st(S.suckback(e['dur']), t, 0, 0.9)
        elif k == 'click': S.put_st(S.click() * (2.2 if e.get('big') else 1.5), t, rng.uniform(-0.25, 0.25), 0.6)
        elif k == 'bell':
            if neutral: S.put_st(S.click() * 2.4, t, 0, 0.6)
            else: S.put_st(S.bell(e['f']), t, 0, 0.5)

hp = sg.butter(2, 30 / (SR / 2), 'high', output='sos'); tail = int(0.35 * SR); fade = np.linspace(1, 0, tail)[:, None] ** 1.5
render(True)
sfx = sg.sosfilt(hp, np.stack([S.L, S.R], 1), axis=0); sfx[-tail:] *= fade
sf.write('public/sfx2.wav', sfx / np.abs(sfx).max() * 0.5, SR)       # quiet (peak -6 dBFS): it sits UNDER the trending sound
S.init(DUR); rng = S.rng
render(False)

# ---------- our own music on the same grid (bouncy club beat: a kick on every beat + the triple kick of each 2-beat cell) ----------
M = S.M; put = S.put
st = lambda s: 261.63 * 2 ** (s / 12)
CH = [('Am', st(-27), [st(-3), st(0), st(4)]), ('F', st(-31), [st(-7), st(-3), st(0)]), ('C', st(-24), [st(0), st(4), st(7)]), ('G', st(-29), [st(-5), st(-1), st(2)])]
PENT = [st(s) for s in (12, 14, 16, 19, 21, 24)]
kicks = []
def pad(tri, dur, g):                       # soft chord for the quiet intro
    n = int(dur * SR); t = np.arange(n) / SR
    x = sum(np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 2 * f * t) for f in tri)
    return x * np.minimum(1, t / 0.25) * np.minimum(1, (dur - t) / 0.4) * g
for k in range(0, 11):                      # intro: pads, a pluck on every beat, soft hats; plucked accents on the measured intro hits
    name, root, tri = CH[(k // 4) % 4]; t = max(0, T(k))
    if k % 4 == 0: put(M, pad(tri, 4 * B + 0.3, 0.06), t)
    put(M, S.pluck(tri[k % 3] * 2, 0.3, 1900) * 0.6, t); put(M, S.hat() * 0.7, t + B / 2)
for h in [0.06, 0.54, 1.36, 2.50, 3.60]: put(M, S.pluck(PENT[2], 0.35, 4200) * 0.6, h); put(M, S.kick() * 0.45, h); kicks.append(h)
for h in [4.13, 4.35, 4.44]: put(M, S.kick() * 0.6, h); put(M, S.clap() * 0.5, h); kicks.append(h)
for k in range(11, 30):                     # after the drop
    t = T(k)
    if t > DUR - 0.9: break
    name, root, tri = CH[((k - 11) // 4 + 2) % 4]
    put(M, S.kick() * 0.7, t); kicks.append(t)
    if k % 2 == 1 and k >= 15 and k not in (21, 25, 27):
        for dx in (0.12, 0.285): put(M, S.kick() * 0.6, t + dx); kicks.append(t + dx)
    if k % 2 == 0: put(M, S.clap() * 0.8, t)
    for e in range(2):
        te = t + e * B / 2
        put(M, S.hat(e == 1) * 1.4, te); put(M, S.bass(root * 2, B / 2 * 0.95) * (1.0 if e else 0.8), te)
        put(M, S.pluck(tri[(2 * k + e) % 3] * (2 if e else 1), bright=3400), te)
        put(M, S.pluck(PENT[(3 * k + 2 * e) % 6], 0.2, 5200) * 0.45, te)
fin = sum(S.pluck(f, 1.0, 3000) for f in CH[2][2]) + S.bass(CH[2][1] * 2, 1.0)
put(M, S.reverb(fin * 1.1, wet=0.45)[:int(1.0 * SR)], 15.29)
side = np.ones(N)
for tk in kicks:
    i = int(tk * SR); n = int(0.2 * SR); j = min(N, i + n)
    if i < N: side[i:j] = np.minimum(side[i:j], 1 - 0.28 * np.exp(-np.arange(j - i) / SR / 0.07))
M *= side
i, j = 0, int(5.83 * SR); M[i:j] = S.filt(M[i:j], 'high', 180) * 0.75          # thin intro so the drop feels bigger
sd = np.ones(N); i, j = int(5.84 * SR), int(DROP * SR); sd[i:j] = 0; sd[i - 960:i] = np.linspace(1, 0, 960); M *= sd   # stop-down
duck = np.ones(N)
for e in EV:
    if e['kind'] == 'impact':
        i = int(e['t'] * SR); n = int(0.45 * SR); j = min(N, i + n)
        duck[i:j] = np.minimum(duck[i:j], 1 - 0.37 * np.exp(-np.arange(j - i) / SR / 0.16))
M *= duck
Mh = S.filt(M, 'high', 2500); d = int(0.011 * SR)
ML = M + 0.35 * Mh; MR = M + 0.35 * np.concatenate([np.zeros(d), Mh[:-d]])
L, R = S.L, S.R
mix = sg.sosfilt(hp, np.stack([ML * 0.62 + L * 0.9, MR * 0.62 + R * 0.9], 1), axis=0); mix[-tail:] *= fade
mix = np.tanh(mix / np.abs(mix).max() * 1.6) / np.tanh(1.6) * 0.89
sf.write('out/mix2_raw.wav', mix, SR)
json.dump(dict(bpm=J['bpm'], beat=B, dur=DUR, events=EV), open('src/events2.json', 'w'), indent=0)
print('events', len(EV), 'kicks', len(kicks))
