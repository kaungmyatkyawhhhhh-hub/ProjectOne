"""Score + sound design in code. One timeline (events.json) drives BOTH the sound and the picture.
Layers: music (kick, clap, hats, bass, plucks, lead) + SFX (each built from low/mid/high layers) -> mix -> master.
"""
import json, numpy as np, scipy.signal as sg, soundfile as sf
SR = 48000; BPM = 120; B = 60 / BPM; DUR = 13.5  # overwritten by init()
N = int(SR * DUR); rng = np.random.default_rng(7)
L = np.zeros(N); R = np.zeros(N)            # sfx bus (stereo)
M = np.zeros(N)                             # music bus (mono core, widened later)


def env(n, a=0.002, d=0.2, curve=1.0):
    t = np.arange(n) / SR
    return np.minimum(1, t / a) * np.exp(-t / d) ** curve


def filt(x, kind, f, order=2):
    sos = sg.butter(order, np.array(f) / (SR / 2), kind, output='sos')
    return sg.sosfilt(sos, x)


def noise(n):
    return rng.standard_normal(n)


def put(bus, x, t):
    i = int(round(t * SR))
    if i < 0: x = x[-i:]; i = 0
    j = min(N, i + len(x))
    if j > i: bus[i:j] += x[:j - i]


def put_st(x, t, pan=0.0, g=1.0):           # pan -1..1 (equal power); x may be (n,) or pan sweep via tuple
    if isinstance(pan, tuple):
        p = np.linspace(pan[0], pan[1], len(x))
    else:
        p = np.full(len(x), pan)
    a = (p + 1) * np.pi / 4
    put(L, x * np.cos(a) * g, t); put(R, x * np.sin(a) * g, t)


IR = noise(int(1.6 * SR)) * np.exp(-np.arange(int(1.6 * SR)) / SR / 0.45)
IR = filt(IR, 'low', 6000); IR /= np.abs(IR).max()


def reverb(x, wet=0.25, tail=1.6):
    y = sg.fftconvolve(np.concatenate([x, np.zeros(int(tail * SR))]), IR)[:len(x) + int(tail * SR)]
    y /= max(1e-9, np.abs(y).max()) / max(1e-9, np.abs(x).max())
    out = np.concatenate([x, np.zeros(int(tail * SR))]) * (1 - wet * 0.3) + y * wet
    return out


# ---------- SFX: every sound = low + mid + high layer (a "layer cake") ----------
def impact(size=1.0):
    n = int(0.9 * SR); t = np.arange(n) / SR
    sub = np.sin(2 * np.pi * np.cumsum(30 + 70 * np.exp(-t / 0.06)) / SR) * np.exp(-t / 0.28)      # low: sub drop
    mid = filt(noise(n), 'low', 500, 4) * np.exp(-t / 0.09) * 1.4                                   # mid: thud
    hi = filt(noise(n), 'high', 3500) * np.exp(-t / 0.035) * 0.5                                    # high: crack
    return reverb((sub * 0.7 + mid * 0.8 + hi * 0.7) * size, wet=0.22)


def whoosh(dur=0.42, peak=0.55, bright=1.0):
    """Peak (loudest point) sits at `peak` of the sound: line it up with the fastest frame of the move."""
    n = int(dur * SR); t = np.arange(n) / n
    e = np.where(t < peak, (t / peak) ** 2.2, ((1 - t) / (1 - peak)) ** 1.6)
    out = np.zeros(n)
    for lo, hi, g in [(90, 260, 0.9), (500, 1800, 0.8), (3500, 9000, 0.45 * bright)]:               # low / mid / high
        out += filt(noise(n), 'band', [lo, hi]) * g
    # doppler-ish sweep: amplitude-modulated comb shimmer
    out *= e
    return out / np.abs(out).max()


def riser(dur):
    n = int(dur * SR); t = np.arange(n) / n
    f = 200 * (2 ** (t * 3.3))
    tone = np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.25 + np.sin(2 * np.pi * np.cumsum(f * 1.5) / SR) * 0.12
    air = np.zeros(n); x = noise(n)
    for k in range(8):                                                                               # opening filter in 8 steps
        a, b = int(n * k / 8), int(n * (k + 1) / 8)
        air[a:b] = filt(x, 'band', [300 + 500 * k, 1500 + 1300 * k])[a:b]
    return (tone + air * 0.5) * t ** 2.0


def suckback(dur=0.5):
    x = impact(0.8)[:int(dur * SR)][::-1]                                                            # a reversed hit = suck-back
    return x * np.linspace(0, 1, len(x)) ** 1.5


def pop(f=880.0):
    n = int(0.09 * SR); t = np.arange(n) / SR
    return (np.sin(2 * np.pi * np.cumsum(f * (1 + 1.2 * np.exp(-t / 0.012))) / SR) * np.exp(-t / 0.03)
            + filt(noise(n), 'high', 5000) * np.exp(-t / 0.006) * 0.3)


def click():
    n = int(0.03 * SR); t = np.arange(n) / SR
    return filt(noise(n), 'band', [1800, 6500]) * np.exp(-t / 0.004) + np.sin(2 * np.pi * 240 * t) * np.exp(-t / 0.008) * 0.5


def bell(f=1318.5, d=0.5):
    n = int(1.0 * SR); t = np.arange(n) / SR
    x = sum(np.sin(2 * np.pi * f * r * t) * a * np.exp(-t / (d / r ** 0.5)) for r, a in [(1, 1), (2.76, 0.45), (5.4, 0.25), (8.9, 0.12)])
    return reverb(x * 0.5, wet=0.2, tail=0.8)


def sparkle(dur=0.8, n_notes=14):
    out = np.zeros(int((dur + 0.5) * SR))
    for k in range(n_notes):
        f = rng.choice([2093, 2349, 2637, 3136, 3520, 4186]); t0 = rng.uniform(0, dur)
        b = bell(f, 0.12)[:int(0.3 * SR)] * rng.uniform(0.15, 0.4)
        i = int(t0 * SR); out[i:i + len(b)] += b[:len(out) - i]
    return out


# ---------- music ----------
def kick():
    n = int(0.32 * SR); t = np.arange(n) / SR
    return np.sin(2 * np.pi * np.cumsum(46 + 110 * np.exp(-t / 0.035)) / SR) * np.exp(-t / 0.14) + click()[:1].sum() * 0


def clap():
    n = int(0.22 * SR); t = np.arange(n) / SR
    x = filt(noise(n), 'band', [900, 3800]) * (np.exp(-t / 0.05) + 0.6 * np.exp(-((t - 0.012) ** 2) / 2e-5))
    return reverb(x * 0.6, wet=0.18, tail=0.3)


def hat(open_=False):
    n = int((0.16 if open_ else 0.045) * SR); t = np.arange(n) / SR
    return filt(noise(n), 'high', 7000) * np.exp(-t / (0.05 if open_ else 0.012)) * 0.35


def saw(f, n):
    ph = np.cumsum(np.full(n, f)) / SR
    return 2 * (ph % 1) - 1


def pluck(f, dur=0.22, bright=2600):
    n = int(dur * SR); t = np.arange(n) / SR
    x = saw(f, n) + saw(f * 1.006, n) + saw(f * 0.994, n)
    return filt(x, 'low', bright, 2) * np.exp(-t / 0.09) * 0.36


def bass(f, dur):
    n = int(dur * SR); t = np.arange(n) / SR
    return (np.sin(2 * np.pi * f * t) + 0.35 * filt(saw(f, n), 'low', 420)) * np.minimum(1, t / 0.005) * np.exp(-t / 0.5) * 0.36



def init(dur, seed=7):
    """(re)allocate the buses for a film of this length"""
    global DUR, N, L, R, M, rng
    DUR = dur; N = int(SR * dur); L = np.zeros(N); R = np.zeros(N); M = np.zeros(N)
