"""Picture QA on the FINAL file: every hit event has a visible change on its frame, no dead time, hook frame is not empty."""
import json,sys,cv2,numpy as np
f=sys.argv[1] if len(sys.argv)>1 else 'out/final.mp4'; E=json.load(open(sys.argv[2] if len(sys.argv)>2 else 'src/events.json'))
cap=cv2.VideoCapture(f);fps=cap.get(5);prev=None;d=[];lum=[];F=[]
while True:
    ok,fr=cap.read()
    if not ok:break
    g=cv2.resize(cv2.cvtColor(fr,cv2.COLOR_BGR2GRAY),(108,192)).astype(np.float32);lum.append(g.mean());F.append(g)
    d.append(0 if prev is None else float(np.abs(g-prev).mean()));prev=g
d=np.array(d);n=len(d);print(f'frames {n} fps {fps:.0f} dur {n/fps:.2f}s | hook frame brightness {lum[0]:.0f} (must be > 40: the payoff is on frame 1)')
miss=[]
for e in E['events']:
    if e['kind'] not in('impact','thud','pop','bell') and not e.get('big'):continue
    i=int(round(e['t']*fps))
    if i>=n:continue
    # "something new is on screen": compare 2 frames before the hit with 3 frames after it
    ch=float(np.abs(F[min(n-1,i+3)]-F[max(0,i-2)]).mean()) if i>0 else float(lum[0]/10)
    if ch<2.5:miss.append((e['t'],e.get('label',e['kind']),round(ch,1)))
print('SYNC  hit events with a visible change on screen:',('all' if not miss else f'MISSING {miss}'))
still=d<0.35;run=0;worst=0;wt=0
for i,s in enumerate(still):
    run=run+1 if s else 0
    if run>worst:worst=run;wt=i/fps
print(f'DEAD  longest stretch with almost no motion: {worst/fps:.2f}s (ending {wt:.1f}s) — must be < 1.0s')
win=int(fps*2);ev=[e['t'] for e in E['events'] if e['kind'] in('impact','thud','pop','bell')]
gaps=np.diff(sorted(set(ev)));print(f'PACE  longest gap between visual beats: {gaps.max():.2f}s (rule: something new every 2-4s at most); mean motion {d.mean():.1f}')
