import React from 'react';
import {AbsoluteFill, OffthreadVideo, Sequence, staticFile, useCurrentFrame, useVideoConfig, Audio} from 'remotion';
import SH from './shots2.json';
// FlexiToys shop ad. Real footage only (the owner's 28 clips), speed-ramped in build_shots.py. This file = cuts, camera, transitions, Burmese text, motion VFX.
// Every pixel is a function of t. Every effect is caused by a cut, a hit or a word landing (src/events.json drives the sound on the same times).
type Shot = {id: string; t: number; d: number; clip: string; a: number; b: number; in: string};
const SHOTS = SH.shots as Shot[]; const H = SH.handle as number; const DUR = SH.dur as number;
const FONT = `@font-face{font-family:Fr;src:url(${staticFile('fredoka-700.woff2')})}@font-face{font-family:MM;src:url(${staticFile('mm-900.woff2')})}@font-face{font-family:Ku;src:url(${staticFile('kuttar.ttf')})}@font-face{font-family:Ti;src:url(${staticFile('titan.woff2')})}`;
// Type: display = Titan One (Latin) + Myanmar Kuttar (Burmese), both chunky and rounded like the shop's own logo; small UI lines = Fredoka + Noto Sans Myanmar.
const GY = 'linear-gradient(180deg,#fff6b0 8%,#ffd23a 46%,#ff9a14 96%)', GW = 'linear-gradient(180deg,#ffffff 30%,#d9cfff 100%)';
const TAU = Math.PI * 2;
const cl = (v: number, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
const sp = (t: number, t0: number, f = 3.4, z = 0.5) => {
  const x = t - t0; if (x <= 0) return 0;
  const w = TAU * f, wd = w * Math.sqrt(1 - z * z);
  return 1 - Math.exp(-z * w * x) * (Math.cos(wd * x) + (z * w / wd) * Math.sin(wd * x));
};
const easeIn = (k: number) => cl(k) ** 3;
const easeOut = (k: number) => 1 - (1 - cl(k)) ** 3;
const seg = (t: number, a: number, b: number) => cl((t - a) / (b - a));
const smooth = (k: number) => { const c = cl(k); return c * c * (3 - 2 * c); };
const hit = (t: number, t0: number, d = 0.12) => (t >= t0 ? Math.exp(-(t - t0) / d) : 0);
const rnd = (s: number) => { let a = s * 2654435761 >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let x = Math.imul(a ^ a >>> 15, 1 | a); x = x + Math.imul(x ^ x >>> 7, 61 | x) ^ x; return ((x ^ x >>> 14) >>> 0) / 4294967296; }; };
const YEL = '#ffd23a', WHITE = '#ffffff', INKP = '#2a1262';   // the shop's own colours: purple + yellow (read off its sign card)
const WHIP = 0.1;                                              // half-length of a whip transition
const DIR: Record<string, [number, number]> = {whipL: [-1, 0], whipR: [1, 0], whipU: [0, -1], whipD: [0, 1]};
const BIG: [number, number, number][] = [[0, 24, 0.14], [6.10, 46, 0.2], [13.92, 30, 0.18], [15.29, 16, 0.14]];
const HITS = SH.hits as number[]; const DROP = 6.10, END = 13.92, CTA = 15.29;

const Ring: React.FC<{t: number; t0: number; x: number; y: number; size: number; color?: string; dur?: number; wd?: number}> = ({t, t0, x, y, size, color = '#fff', dur = 0.45, wd = 16}) => {
  const k = (t - t0) / dur; if (k <= 0 || k >= 1) return null; const d = size * (1 - (1 - k) ** 3);
  return <div style={{position: 'absolute', left: x - d / 2, top: y - d / 2, width: d, height: d, borderRadius: '50%', boxSizing: 'border-box', border: `${wd * (1 - k) + 1}px solid ${color}`, opacity: (1 - k) * 0.9}} />;
};
const Sparks: React.FC<{t: number; t0: number; x: number; y: number; n: number; seed: number; r0: number; color?: string; power?: number}> = ({t, t0, x, y, n, seed, r0, color = YEL, power = 1}) => {
  const k = (t - t0) / 0.42; if (k <= 0 || k >= 1) return null; const r = rnd(seed), e = 1 - (1 - k) ** 2.5;
  return <>{Array.from({length: n}, (_, i) => {
    const ang = (i + r() * 0.8) / n * TAU, dist = r0 + (240 + r() * 340) * power * e, len = (60 + r() * 90) * (1 - k) + 8, th = 6 + r() * 6;
    return <div key={i} style={{position: 'absolute', left: x + Math.cos(ang) * dist - len / 2, top: y + Math.sin(ang) * dist - th / 2, width: len, height: th, borderRadius: th, background: color, opacity: 1 - k * k, transform: `rotate(${ang}rad)`}} />;
  })}</>;
};
const Streaks: React.FC<{t: number; t0: number; dir: [number, number]; seed: number; n?: number; len?: number}> = ({t, t0, dir, seed, n = 18, len: L = 0.42}) => {
  const x = t - t0; if (x < -0.1 || x > L) return null; const env = Math.sin(Math.PI * cl((x + 0.1) / (L + 0.1))), r = rnd(seed), horiz = dir[0] !== 0, sgn = horiz ? dir[0] : dir[1];
  const span = horiz ? 1080 : 1920;
  return <>{Array.from({length: n}, (_, i) => {
    const perp = r(), len = 280 + r() * 560, th = 3 + r() * 7, ph = r(), op = env * (0.25 + 0.45 * r());
    const tr = ((x + 0.1) * 5600 + ph * (span + 900)) % (span + 900) - 700, pos = sgn > 0 ? tr : span - tr - len;
    const grad = `linear-gradient(${horiz ? 90 : 180}deg, transparent, rgba(255,255,255,.95), transparent)`;
    return horiz ? <div key={i} style={{position: 'absolute', left: pos, top: perp * 1920, width: len, height: th, borderRadius: th, background: grad, opacity: op}} />
      : <div key={i} style={{position: 'absolute', top: pos, left: perp * 1080, width: th, height: len, borderRadius: th, background: grad, opacity: op}} />;
  })}</>;
};
const Radial: React.FC<{t: number; t0: number; dur: number; inward?: boolean; cx: number; cy: number; seed: number; n?: number; color?: string; loop?: boolean; gain?: number}> = ({t, t0, dur, inward = false, cx, cy, seed, n = 24, color = '#fff', loop = false, gain = 1}) => {
  const k = (t - t0) / dur; if (k <= 0 || k >= 1) return null; const r = rnd(seed);
  return <>{Array.from({length: n}, (_, i) => {
    const ang = (i + r()) / n * TAU, ph = r(), len = 160 + r() * 320, th = 4 + r() * 6;
    const kk = loop ? ((t - t0) * 2.6 + ph) % 1 : cl((k - ph * 0.25) / (1 - ph * 0.25));
    const R = inward ? lerp(1300, 170, kk ** 1.7) : lerp(loop ? 420 : 240, 1400, loop ? kk ** 1.5 : 1 - (1 - kk) ** 2.2), op = Math.sin(Math.PI * kk) * (0.3 + 0.45 * r()) * gain * (loop ? Math.sin(Math.PI * k) ** 0.5 : 1);
    return <div key={i} style={{position: 'absolute', left: cx + Math.cos(ang) * R - len / 2, top: cy + Math.sin(ang) * R - th / 2, width: len * (inward ? 0.5 + kk : 1.2 - 0.6 * kk), height: th, borderRadius: th, background: `linear-gradient(90deg, transparent, ${color}, transparent)`, opacity: op, transform: `rotate(${ang}rad)`}} />;
  })}</>;
};

// one word: thick outline underneath, fill on top (works for Burmese stacks too)
const Word: React.FC<{s: string; color: string; size: number; sw: number; flat?: boolean}> = ({s, color, size, sw, flat}) => {
  // display words: gradient fill + purple outline + a short solid extrusion (toy / sticker depth). flat = small UI lines.
  const ex = flat ? 0 : Math.round(size * 0.09), w = flat ? sw : Math.round(size * 0.11);
  const sh = flat ? `0 ${Math.round(w * 0.55)}px 0 ${INKP}, 0 ${Math.round(w * 1.1)}px ${Math.round(size * 0.14)}px rgba(0,0,0,.45)` : Array.from({length: ex}, (_, i) => `0 ${i + 1}px 0 ${INKP}`).join(',') + `,0 ${ex + 6}px ${Math.round(size * 0.12)}px rgba(0,0,0,.45)`;
  return <span style={{position: 'relative', display: 'inline-block', whiteSpace: 'nowrap', lineHeight: 1.6}}>
    <span style={{color: INKP, WebkitTextStroke: `${w}px ${INKP}`, textShadow: sh}}>{s}</span>
    <span style={{position: 'absolute', left: '-0.12em', top: '-0.2em', padding: '0.2em 0.12em', ...(flat ? {color} : {backgroundImage: color === YEL ? GY : GW, WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent'})}}>{s}</span>
  </span>;
};
type Part = [string, string];
type CapP = {t: number; t0: number; t1: number; y: number; size: number; rot?: number; parts: Part[]; slam?: boolean; stagger?: number; beat?: boolean; maxW?: number; hold?: boolean; slamAmt?: number; times?: number[]; ui?: boolean};
// a caption: words pop in one by one ON t0, throw off an echo, bounce on the beat, and snap out before the cut
const Cap: React.FC<CapP> = ({t, t0, t1, y, size, rot = -3, parts, slam = false, stagger = 0.07, beat = true, maxW = 920, hold = false, slamAmt = 0.9, times, ui = false}) => {
  if (t < t0 - 0.05 || t >= t1) return null;
  const out = hold ? 0 : easeIn(seg(t, t1 - 0.1, t1)), sw = Math.round(size * 0.13);
  const pulse = beat ? 0.035 * Math.exp(-((t + 1e-6) % 0.5) / 0.09) : 0, ek = (t - t0) / 0.3;
  const wob = 1.1 * Math.sin(TAU * (t - t0) / 1.7);
  const row = (echo: boolean) => <div style={{display: 'flex', flexWrap: 'wrap', justifyContent: 'center', columnGap: size * 0.26, rowGap: 0, maxWidth: maxW, margin: '0 auto', fontFamily: ui ? 'Fr, MM' : 'Ti, Ku', fontSize: size}}>
    {parts.map(([s, c], i) => {
      const ti = times ? times[i] : t0 + i * stagger, k = slam && i === 0 ? 1 : sp(t, ti - 0.035, 3.8, 0.45), sl = slam && i === 0 ? 1 + slamAmt * Math.exp(-Math.max(0, t - t0) / 0.07) : 1;
      return <span key={i} style={{display: 'inline-block', transform: `translateY(${lerp(110, 0, k)}px) scale(${k * sl * (1 + 0.1 * hit(t, ti, 0.1))}) rotate(${lerp(i % 2 ? 16 : -16, 0, k)}deg)`, opacity: echo ? 1 : cl(k * 4)}}>
        {echo ? <span style={{whiteSpace: 'nowrap', lineHeight: 1.6, color: 'transparent', WebkitTextStroke: `4px ${c}`}}>{s}</span> : <Word s={s} color={c} size={size} sw={sw} flat={ui} />}
      </span>;
    })}
  </div>;
  return <>
    {ek > 0 && ek < 1 && <div style={{position: 'absolute', left: 40, width: 1000, top: y, transform: `translateY(-50%) rotate(${rot}deg) scale(${1 + 0.4 * ek})`, opacity: 0.55 * (1 - ek)}}>{row(true)}</div>}
    <div style={{position: 'absolute', left: 40, width: 1000, top: y, transform: `translateY(-50%) rotate(${rot + wob}deg) scale(${(1 + pulse) * (1 - out)})`}}>{row(false)}</div>
  </>;
};

export const Ad2: React.FC = () => {
  const f = useCurrentFrame(); const {fps} = useVideoConfig(); const t = f / fps;
  const shakeAmt = BIG.reduce((a, [t0, amt, d]) => a + amt * hit(t, t0, d), 0);
  const r = rnd(Math.floor(t * 30 + 1e-6) + 3);
  const shx = (r() - 0.5) * 2 * shakeAmt, shy = (r() - 0.5) * 2 * shakeAmt;
  const flash = 0.3 * cl(1 - t / 0.12) + [[DROP, 0.8, 0.16], [END, 0.45, 0.14], [CTA, 0.25, 0.12]].reduce((a, [t0, amt, d]) => a + (t >= t0 ? amt * cl(1 - (t - t0) / d) : 0), 0);
  const stop = seg(t, 5.83, 6.06) * (t < DROP ? 1 : 0);                       // stop-down on the sound's pickup, right before its drop
  const split = 16 * hit(t, DROP, 0.09) + 10 * hit(t, END, 0.08);
  const endDim = smooth(seg(t, END, END + 0.22));
  // every measured hit of the sound gives the picture a small punch; the triple hits become a stutter
  const hp = HITS.reduce((a, h) => a + (h > 4.0 && h !== DROP && h !== END ? 0.055 * hit(t, h, 0.065) : 0), 0);
  const step = 0.075 * ((t >= 4.13 ? 1 : 0) + (t >= 4.35 ? 1 : 0) + (t >= 4.44 ? 1 : 0));   // three jump-zooms on the pre-drop fill

  const shotEl = (s: Shot, i: number) => {
    const nx = SHOTS[i + 1], tc = s.t, te = nx ? nx.t : DUR, dIn = DIR[s.in], dOut = nx ? DIR[nx.in] : undefined;
    const vis0 = tc - (dIn ? WHIP : 0), vis1 = te + (dOut ? WHIP : 0);
    const from = Math.round((tc - H) * fps), n = Math.round((s.d + 2 * H) * fps);
    if (t < vis0 || t >= vis1) return null;
    const u = cl((t - tc) / s.d);
    let sc = 1.03 + 0.05 * u + hp + (s.in === 'drop' ? 0.14 : s.in === 'hit' ? 0.1 : s.in === 'start' ? 0.08 : s.in === 'punch' ? 0.08 : 0.04) * hit(t, tc, 0.14);
    let tx = 0, ty = 0, bx = 0, by = 0, blur = 0, rot = (i % 2 ? 1 : -1) * 0.8 * (1 - smooth(u * 2.5));
    if (dIn && t < tc + WHIP) { const k = seg(t, tc - WHIP, tc + WHIP), p = smooth(k), v = 6 * k * (1 - k) / 1.5; tx += dIn[0] * (p - 1) * 1080; ty += dIn[1] * (p - 1) * 1920; bx += Math.abs(dIn[0]) * 110 * v; by += Math.abs(dIn[1]) * 150 * v; }
    if (dOut && t >= te - WHIP) { const k = seg(t, te - WHIP, te + WHIP), p = smooth(k), v = 6 * k * (1 - k) / 1.5; tx += dOut[0] * p * 1080; ty += dOut[1] * p * 1920; bx += Math.abs(dOut[0]) * 110 * v; by += Math.abs(dOut[1]) * 150 * v; }
    if (nx && nx.in === 'zoom') { const k = easeIn(seg(t, te - 0.16, te)); sc *= 1 + 1.7 * k; blur += 16 * k; }
    if (s.in === 'zoom') { const k = 1 - easeOut(seg(t, tc, tc + 0.22)); sc *= 1 + 0.6 * k; blur += 12 * k; }
    if (s.id === 'd') sc = (sc + step) * (1 - 0.08 * stop);
    if (s.id === 'l') blur += 7 * endDim;
    if (s.id === 'd') blur += 5 * stop;
    const fid = `bl${i}`, useF = bx > 0.6 || by > 0.6;
    const st: React.CSSProperties = {position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, transform: `translate(${tx}px,${ty}px) rotate(${rot}deg) scale(${sc})`, filter: useF ? `url(#${fid})` : blur > 0.3 ? `blur(${blur}px)` : undefined};
    const ghost = split > 0.6 && (s.id === 'f' || s.id === 'l');
    return <Sequence key={s.id} from={from} durationInFrames={n} layout="none">
      {useF && <svg width="0" height="0" style={{position: 'absolute'}}><filter id={fid} x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation={`${bx.toFixed(1)} ${by.toFixed(1)}`} /></filter></svg>}
      <OffthreadVideo muted src={staticFile(`shots2/${s.id}.mp4`)} style={st} />
      {ghost && [-1, 1].map(d => <OffthreadVideo key={d} muted src={staticFile(`shots2/${s.id}.mp4`)} style={{...st, transform: `translate(${tx + d * split}px,${ty}px) rotate(${rot}deg) scale(${sc})`, opacity: 0.45, filter: `hue-rotate(${d * 110}deg) saturate(2)`, mixBlendMode: 'screen'}} />)}
    </Sequence>;
  };

  const nameK = sp(t, END - 0.03, 2.8, 0.45), pill = sp(t, 14.47 - 0.04, 3.2, 0.5), tik = sp(t, 14.75 - 0.04, 3.2, 0.5);
  const Brand: React.FC<{size: number}> = ({size}) => <span style={{fontFamily: 'Fr', fontSize: size, letterSpacing: -2, whiteSpace: 'nowrap'}}><Word s="Flexi" color={WHITE} size={size} sw={Math.round(size * 0.12)} /><Word s="Toys" color={YEL} size={size} sw={Math.round(size * 0.12)} /></span>;
  const dropK = sp(t, DROP - 0.03, 2.8, 0.42);
  return <AbsoluteFill style={{background: '#000', overflow: 'hidden'}}>
    <style>{FONT}</style>
    <AbsoluteFill style={{transform: `translate(${shx}px,${shy}px)`}}>
      {SHOTS.map(shotEl)}
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(10,4,30,.5), rgba(10,4,30,0) 34%)'}} />
      <AbsoluteFill style={{background: '#000', opacity: 0.6 * stop}} />
      <AbsoluteFill style={{background: `linear-gradient(180deg, rgba(42,18,98,.78), rgba(20,8,50,.4) 55%, rgba(20,8,50,.72))`, opacity: endDim}} />
    </AbsoluteFill>

    {SHOTS.map((s, i) => DIR[s.in] && <Streaks key={s.id} t={t} t0={s.t - 0.16} dir={DIR[s.in]} seed={50 + i} len={0.34} />)}
    <Radial t={t} t0={5.45} dur={0.6} inward cx={540} cy={900} seed={21} />
    <Radial t={t} t0={0} dur={0.32} cx={540} cy={1150} seed={22} color={YEL} />
    <Radial t={t} t0={DROP} dur={0.38} cx={540} cy={860} seed={23} n={30} />
    <Radial t={t} t0={11.66} dur={1.2} cx={540} cy={900} seed={24} n={26} loop gain={0.7} />
    <Radial t={t} t0={END} dur={0.36} cx={540} cy={700} seed={25} n={30} color={YEL} />
    <Ring t={t} t0={0} x={540} y={1150} size={2200} color={YEL} dur={0.45} wd={24} />
    <Ring t={t} t0={DROP} x={540} y={860} size={2600} color={YEL} dur={0.55} wd={34} /><Ring t={t} t0={DROP + 0.08} x={540} y={860} size={2000} dur={0.5} wd={12} />
    <Ring t={t} t0={END} x={540} y={600} size={2400} color={YEL} dur={0.5} wd={24} />
    <Ring t={t} t0={CTA} x={540} y={1345} size={1900} color={YEL} dur={0.45} wd={20} />
    <Sparks t={t} t0={DROP} x={540} y={860} n={20} seed={31} r0={380} power={1.9} /><Sparks t={t} t0={CTA} x={540} y={1345} n={14} seed={32} r0={330} power={1.4} />
    <Ring t={t} t0={1.36} x={540} y={330} size={1500} color={YEL} dur={0.4} wd={18} /><Sparks t={t} t0={1.36} x={540} y={330} n={12} seed={33} r0={330} />

    {/* Burmese captions: every word lands on a measured hit of the sound */}
    <Cap t={t} t0={0.0} t1={1.36} y={320} size={116} rot={-4} parts={[['ဘာထွက်မလဲ?', YEL]]} slam slamAmt={0.1} beat={false} />
    <Cap t={t} t0={0.54} t1={1.36} y={505} size={74} rot={-4} parts={[['Blox Fruits', WHITE], ['Blind Box', WHITE]]} stagger={0.06} beat={false} ui />
    <Cap t={t} t0={1.36} t1={2.5} y={335} size={158} rot={-5} parts={[['29,500', YEL], ['Ks', WHITE]]} slam stagger={0.1} beat={false} maxW={1000} />
    <Cap t={t} t0={2.5} t1={3.6} y={365} size={88} rot={3} parts={[['Minecraft', WHITE], ['+', YEL], ['Roblox', WHITE], ['လည်း ရှိတယ်', YEL]]} stagger={0.05} beat={false} />
    <Cap t={t} t0={3.6} t1={5.8} y={335} size={118} rot={-3} parts={[['Blind Box', YEL], ['အစုံ', WHITE]]} times={[3.6, 4.13]} beat={false} />
    {t >= DROP - 0.03 && t < 7.22 && <>
      {[1, 2, 3].map(i => { const k = (t - DROP - 0.02 * i) / 0.34; return k > 0 && k < 1 && <div key={i} style={{position: 'absolute', left: 0, right: 0, top: 760, textAlign: 'center', transform: `translateY(-50%) scale(${1 + 0.24 * i * k}) rotate(-4deg)`, opacity: 0.3 * (1 - k)}}><Brand size={210} /></div>; })}
      <div style={{position: 'absolute', left: 0, right: 0, top: 760, textAlign: 'center', transform: `translateY(-50%) scale(${lerp(3.2, 1, dropK) * (1 - easeIn(seg(t, 7.12, 7.22))) * (1 + hp)}) rotate(${lerp(-12, -4, dropK)}deg)`}}><Brand size={210} /></div>
    </>}
    <Cap t={t} t0={6.38} t1={7.22} y={1010} size={128} rot={-4} parts={[['အရုပ်ဆိုင်', YEL]]} beat={false} />
    <Cap t={t} t0={7.24} t1={8.33} y={345} size={112} rot={3} parts={[['အသစ်တွေ', YEL], ['ရောက်ပြီ!', WHITE]]} stagger={0.1} beat={false} />
    <Cap t={t} t0={8.33} t1={9.45} y={345} size={108} rot={-3} parts={[['ကိုယ်တိုင်', WHITE], ['ဆက်ကြမယ်', YEL]]} times={[8.33, 8.62]} beat={false} />
    <Cap t={t} t0={10.57} t1={11.69} y={345} size={100} rot={3} parts={[['Keychain', YEL], ['တွေလည်း ရှိတယ်', WHITE]]} times={[10.57, 10.84]} beat={false} />
    <Cap t={t} t0={11.7} t1={12.76} y={640} size={150} rot={-4} parts={[['ဘယ်မှာလဲ?', WHITE]]} beat={false} />
    <Cap t={t} t0={12.8} t1={END} y={500} size={98} rot={-3} parts={[['Junction', YEL], ['Centre', YEL], ['နေပြည်တော်', WHITE]]} times={[12.8, 12.92, 13.09]} beat={false} maxW={860} />

    {t >= END - 0.03 && <>
      {[1, 2, 3].map(i => { const k = (t - END - 0.02 * i) / 0.34; return k > 0 && k < 1 && <div key={i} style={{position: 'absolute', left: 0, right: 0, top: 560, textAlign: 'center', transform: `translateY(-50%) scale(${1 + 0.22 * i * k}) rotate(-3deg)`, opacity: 0.3 * (1 - k)}}><Brand size={200} /></div>; })}
      <div style={{position: 'absolute', left: 0, right: 0, top: 560, textAlign: 'center', transform: `translateY(-50%) scale(${lerp(2.6, 1, nameK) * (1 + 0.06 * hit(t, CTA, 0.18) + hp * 0.5)}) rotate(${lerp(-10, -3, nameK) + 0.8 * Math.sin(TAU * t / 2.6)}deg)`}}><Brand size={200} /></div>
      <Cap t={t} t0={14.2} t1={DUR + 1} y={775} size={110} rot={-3} parts={[['အရုပ်ဆိုင်', YEL]]} beat={false} hold />
      {t >= 14.42 && <div style={{position: 'absolute', left: 0, right: 0, top: 985, display: 'flex', justifyContent: 'center'}}>
        <div style={{fontFamily: 'Fr, MM', fontSize: 68, lineHeight: 1.6, color: INKP, background: '#fff', borderRadius: 60, padding: '10px 50px 12px', whiteSpace: 'nowrap', boxShadow: `0 12px 0 ${INKP}`, transform: `perspective(1400px) rotateX(${lerp(-75, 0, pill)}deg) scale(${pill * (1 + 0.08 * hit(t, 14.47, 0.1) + 0.05 * hit(t, CTA, 0.18))})`}}>Junction Centre · နေပြည်တော်</div>
      </div>}
      {t >= 14.7 && <div style={{position: 'absolute', left: 0, right: 0, top: 1140, textAlign: 'center', fontFamily: 'Fr', fontSize: 62, color: '#fff', transform: `translateY(${lerp(80, 0, tik)}px) scale(${tik * (1 + 0.08 * hit(t, 14.75, 0.1))})`, textShadow: `0 6px 0 ${INKP}`}}>TikTok <span style={{color: YEL}}>@flexitoysmm</span></div>}
      <Cap t={t} t0={CTA} t1={DUR + 1} y={1350} size={96} rot={-3} parts={[['ဒီနေ့ပဲ', WHITE], ['လာခဲ့နော်!', YEL]]} slam times={[15.29, 15.63]} beat={false} hold maxW={1000} />
    </>}

    <AbsoluteFill style={{background: 'radial-gradient(ellipse at center,transparent 62%,rgba(0,0,0,.38) 100%)'}} />
    <AbsoluteFill style={{background: '#fff', opacity: cl(flash)}} />
    <AbsoluteFill style={{background: '#000', opacity: seg(t, DUR - 0.3, DUR - 0.03)}} />
  </AbsoluteFill>;
};
