"""Sound for the collage-style GYM ARC ad (same grid as score_dg.py)
(shop version docstring follows) Sound for the collage-style FlexiToys ad, on the measured grid of the trending sound it is cut to (beat 0.5825 s, first hit 0.086 s, DROP on beat 8).
Writes public/sfx_gy.wav (effects only, NO pitched sounds: sits under the trending sound), out/mix_gy_raw.wav (our own music + effects), src/events_gy.json."""
import json, numpy as np, scipy.signal as sg, soundfile as sf
import synth as S
B, B0, DUR = 0.5825, 0.086, 12.6
bt = lambda n: B0 + n * B
DROP, END, CTA, PICK = bt(8), bt(17), bt(19), bt(8) - 0.26
S.init(DUR); SR = S.SR; N = S.N; rng = S.rng
EV = []
def ev(t, kind, **kw): EV.append(dict(t=round(t, 3), kind=kind, **kw))
def whip(t, pan, lab, g=0.34, lead=0.085): ev(t - lead, 'whoosh', pan=pan, dur=0.34, peak=0.5, g=g, label=lab)

ev(0.0, 'impact', size=0.8, label='hook: the lifter on paper'); ev(0.03, 'sparkle', dur=0.5)
ev(bt(1), 'thud', label='logo slams'); ev(bt(1), 'pop', f=784, label='logo')
for i, lab in enumerate(['LIFT', 'GROW', 'EVOLVE', 'COMPETE']):
    ev(bt(2 + i / 2), 'thud', soft=i % 2 == 1, label='cut-out: ' + lab); ev(bt(2 + i / 2), 'pop', f=[880, 988, 1046, 1175][i], label=lab)
ev(bt(4), 'thud', label='logo again'); ev(bt(4) + 0.02, 'click', big=True, label='glitch')
whip(bt(5), (0.8, -0.8), 'whip to the type scene', 0.4)
for k in range(5): ev(bt(5) + 0.06 + k * 0.055, 'click', label='syllables land')
ev(bt(5) + 0.4, 'click', big=True, label='underline'); ev(bt(6), 'thud', label='second line'); ev(bt(6), 'pop', f=988, label='BLIND BOX')
ev(bt(7) - 0.09, 'whoosh', pan=(-0.8, 0), dur=0.3, peak=0.5, g=0.3, label='panel 1 slides in')
for i in range(3): ev(bt(7) + i * 0.1, 'thud', label='marker letter ' + 'REP'[i]); ev(bt(7) + i * 0.1, 'click', big=True, label='marker tick')
ev(bt(7.5) - 0.09, 'whoosh', pan=(0, 0), dur=0.3, peak=0.5, g=0.3, label='panel 2 drops in'); ev(bt(7.5), 'thud', label='455 LB panel lands'); ev(bt(7.5), 'bell', f=1568, label='455 LB')
ev(DROP - 1.25, 'riser', dur=0.86, g=0.5); ev(DROP - 0.5, 'suckback', dur=0.24)
ev(DROP, 'impact', size=1.25, label='DROP: ribbon collage'); ev(DROP + 0.03, 'sparkle', dur=0.7)
labs = {9: 'poster: flat bench 455 LB', 10: 'gameplay cards', 11: 'alters: VOLTA legendary', 12: 'ribbon: strongman showdown', 13: 'poster: growth spurt', 14: 'gameplay cards 2', 15: 'how big can you get?', 16: 'Hall of Fame'}
pans = {9: (0, 0), 10: (0.8, -0.8), 11: (0, 0), 12: (-0.8, 0.8), 13: (0, 0), 14: (-0.8, 0.8), 15: (0.8, -0.8), 16: (0.8, -0.8)}
for n in range(9, 17):
    whip(bt(n), pans[n], 'whip: ' + labs[n], 0.24 if pans[n] == (0, 0) else 0.34); ev(bt(n), 'thud', label=labs[n])
    if n in (9, 13): ev(bt(n) + B / 2, 'bell', f=1568, label='price lands')
    if n in (10, 14): ev(bt(n) + 0.15, 'click', big=True, label='cards land')
ev(bt(12) + 0.06, 'pop', f=1046, label='SHOWDOWN'); ev(bt(16) + 0.12, 'pop', f=880, label='will you make it?')
ev(bt(16) + 0.2, 'riser', dur=B - 0.26, g=0.6)
ev(END, 'impact', size=1.1, label='END CARD: logo in light'); ev(END + 0.03, 'sparkle', dur=0.7)
ev(bt(18), 'pop', f=988, label='search line')
for k in range(12): ev(bt(18) + 0.03 + k * 0.06, 'click', label='typing: search line')
ev(CTA, 'impact', size=0.9, label='CTA'); ev(CTA + 0.09, 'pop', f=1318, label='NOW')

def render(neutral):
    for e in EV:
        k, t = e['kind'], e['t']
        if k == 'impact': S.put_st(S.impact(e['size']), t, 0, 0.95)
        elif k == 'sparkle':
            if not neutral: S.put_st(S.sparkle(e['dur']), t, (-0.6, 0.6), 0.8)
        elif k == 'pop':
            if neutral: S.put_st(S.click() * 1.9, t, 0, 0.6); S.put_st(S.impact(0.4)[:int(0.16 * SR)] * 0.35, t, 0, 0.8)
            else: S.put_st(S.pop(e['f']), t, 0, 0.75)
        elif k == 'whoosh': S.put_st(S.whoosh(e['dur'], e.get('peak', 0.55)), t - e['dur'] * e.get('peak', 0.55), tuple(e['pan']), e['g'])
        elif k == 'thud': S.put_st(S.impact(0.55)[:int(0.35 * SR)] * (0.5 if e.get('soft') else 0.75), t, 0, 0.8)
        elif k == 'riser':
            if neutral: S.put_st(S.whoosh(e['dur'], 0.96, 1.3), t, 0, 0.45 * e.get('g', 1))
            else: S.put_st(S.riser(e['dur']), t, 0, 0.5 * e.get('g', 1))
        elif k == 'suckback': S.put_st(S.suckback(e['dur']), t, 0, 0.5)
        elif k == 'click': S.put_st(S.click() * (2.2 if e.get('big') else 1.5), t, rng.uniform(-0.25, 0.25), 0.6)
        elif k == 'bell':
            if neutral: S.put_st(S.click() * 2.4, t, 0, 0.6)
            else: S.put_st(S.bell(e['f']), t, 0, 0.5)

hp = sg.butter(2, 30 / (SR / 2), 'high', output='sos'); tail = int(0.35 * SR); fade = np.linspace(1, 0, tail)[:, None] ** 1.5
render(True)
sfx = sg.sosfilt(hp, np.stack([S.L, S.R], 1), axis=0); sfx[-tail:] *= fade
sf.write('public/sfx_gy.wav', sfx / np.abs(sfx).max() * 0.5, SR)
S.init(DUR); rng = S.rng; render(False)

# ---------- our own music on the same grid: plucked intro, half-time build, a kick on every beat after the drop ----------
M = S.M; put = S.put
st = lambda s: 261.63 * 2 ** (s / 12)
CH = [('Am', st(-27), [st(-3), st(0), st(4)]), ('F', st(-31), [st(-7), st(-3), st(0)]), ('C', st(-24), [st(0), st(4), st(7)]), ('G', st(-29), [st(-5), st(-1), st(2)])]
PENT = [st(s) for s in (12, 14, 16, 19, 21, 24)]
kicks = []
def pad(tri, dur, g):
    n = int(dur * SR); t = np.arange(n) / SR
    x = sum(np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 2 * f * t) for f in tri)
    return x * np.minimum(1, t / 0.25) * np.minimum(1, (dur - t) / 0.4) * g
for k in range(8):                                   # intro: beats 0-7
    t = bt(k); name, root, tri = CH[(k // 4) % 4]
    if t > PICK - 0.05: continue
    if k % 4 == 0: put(M, pad(tri, 4 * B + 0.3, 0.06), t)
    put(M, S.pluck(tri[k % 3] * 2, 0.3, 2200) * 0.7, t); put(M, S.hat() * 0.7, t + B / 2)
    if k in (0, 1, 4): put(M, S.kick() * 0.5, t); kicks.append(t)
    if 2 <= k < 4:                                    # the four half-beat cut-outs
        for e in range(2): put(M, S.kick() * 0.5, t + e * B / 2); put(M, S.pluck(PENT[(2 * k + e) % 6], 0.25, 4200) * 0.6, t + e * B / 2); kicks.append(t + e * B / 2)
    if k >= 5: put(M, S.bass(root * 2, B * 0.9) * 0.7, t); put(M, S.clap() * 0.45, t)
k = 8
while bt(k) < DUR - 0.8:
    t = bt(k); name, root, tri = CH[((k - 8) // 4 + 2) % 4]
    put(M, S.kick() * 0.7, t); kicks.append(t)
    if k % 2 == 1: put(M, S.clap() * 0.8, t)
    for e in range(2):
        te = t + e * B / 2
        put(M, S.hat(e == 1) * 1.4, te); put(M, S.bass(root * 2, B / 2 * 0.95) * (1.0 if e else 0.8), te)
        put(M, S.pluck(tri[(2 * k + e) % 3] * (2 if e else 1), bright=3400), te)
        put(M, S.pluck(PENT[(3 * k + 2 * e) % 6], 0.2, 5200) * 0.45, te)
    k += 1
fin = sum(S.pluck(f, 1.0, 3000) for f in CH[2][2]) + S.bass(CH[2][1] * 2, 1.0)
put(M, S.reverb(fin * 1.1, wet=0.45)[:int(1.0 * SR)], CTA)
side = np.ones(N)
for tk in kicks:
    i = int(tk * SR); n = int(0.2 * SR); j = min(N, i + n)
    if 0 <= i < N: side[i:j] = np.minimum(side[i:j], 1 - 0.28 * np.exp(-np.arange(j - i) / SR / 0.07))
M *= side
j = int(PICK * SR); M[:j] = S.filt(M[:j], 'high', 180) * 0.8
sd = np.ones(N); i, j = int((PICK + 0.02) * SR), int(DROP * SR); sd[i:j] = 0; sd[i - 960:i] = np.linspace(1, 0, 960); M *= sd
duck = np.ones(N)
for e in EV:
    if e['kind'] == 'impact':
        i = int(e['t'] * SR); n = int(0.45 * SR); j = min(N, i + n)
        duck[i:j] = np.minimum(duck[i:j], 1 - 0.37 * np.exp(-np.arange(j - i) / SR / 0.16))
M *= duck
Mh = S.filt(M, 'high', 2500); d = int(0.011 * SR)
ML = M + 0.35 * Mh; MR = M + 0.35 * np.concatenate([np.zeros(d), Mh[:-d]])
mix = sg.sosfilt(hp, np.stack([ML * 0.62 + S.L * 0.9, MR * 0.62 + S.R * 0.9], 1), axis=0); mix[-tail:] *= fade
mix = np.tanh(mix / np.abs(mix).max() * 1.6) / np.tanh(1.6) * 0.89
sf.write('out/mix_gy_raw.wav', mix, SR)
json.dump(dict(bpm=round(60 / B, 2), beat=B, dur=DUR, events=EV), open('src/events_gy.json', 'w'), indent=0)
print('events', len(EV), 'kicks', len(kicks))
