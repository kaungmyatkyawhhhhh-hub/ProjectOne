import React from 'react';
import {AbsoluteFill, OffthreadVideo, Sequence, staticFile, useCurrentFrame, useVideoConfig, Audio} from 'remotion';

// FlexiToys shop ad. Real footage only (the owner's 28 clips), speed-ramped in build_shots.py. This file = cuts, camera, transitions, Burmese text, motion VFX.
// Every pixel is a function of t. Every effect is caused by a cut, a hit or a word landing (src/events.json drives the sound on the same times).
type Shot = {id: string; t: number; d: number; clip: string; a: number; b: number; in: string};
const FONT = `@font-face{font-family:Fr;src:url(${staticFile('fredoka-700.woff2')})}@font-face{font-family:MM;src:url(${staticFile('mm-900.woff2')})}@font-face{font-family:Ku;src:url(${staticFile('kuttar.ttf')})}@font-face{font-family:Ti;src:url(${staticFile('titan.woff2')})}@font-face{font-family:An;src:url(${staticFile('anton.woff2')})}`;
// Type: display = Titan One (Latin) + Myanmar Kuttar (Burmese), both chunky and rounded like the shop's own logo; small UI lines = Fredoka + Noto Sans Myanmar.
const GY = 'linear-gradient(180deg,#fff6b0 8%,#ffd23a 46%,#ff9a14 96%)', GW = 'linear-gradient(180deg,#ffffff 30%,#d9cfff 100%)';
const TAU = Math.PI * 2;
const cl = (v: number, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
const sp = (t: number, t0: number, f = 3.4, z = 0.5) => {
  const x = t - t0; if (x <= 0) return 0;
  const w = TAU * f, wd = w * Math.sqrt(1 - z * z);
  return 1 - Math.exp(-z * w * x) * (Math.cos(wd * x) + (z * w / wd) * Math.sin(wd * x));
};
const easeIn = (k: number) => cl(k) ** 3;
const easeOut = (k: number) => 1 - (1 - cl(k)) ** 3;
const seg = (t: number, a: number, b: number) => cl((t - a) / (b - a));
const smooth = (k: number) => { const c = cl(k); return c * c * (3 - 2 * c); };
const hit = (t: number, t0: number, d = 0.12) => (t >= t0 ? Math.exp(-(t - t0) / d) : 0);
const rnd = (s: number) => { let a = s * 2654435761 >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let x = Math.imul(a ^ a >>> 15, 1 | a); x = x + Math.imul(x ^ x >>> 7, 61 | x) ^ x; return ((x ^ x >>> 14) >>> 0) / 4294967296; }; };
const YEL = '#ffd23a', WHITE = '#ffffff', INKP = '#2a1262';   // the shop's own colours: purple + yellow (read off its sign card)
const WHIP = 0.1;                                              // half-length of a whip transition
const DIR: Record<string, [number, number]> = {whipL: [-1, 0], whipR: [1, 0], whipU: [0, -1], whipD: [0, 1]};

const Ring: React.FC<{t: number; t0: number; x: number; y: number; size: number; color?: string; dur?: number; wd?: number}> = ({t, t0, x, y, size, color = '#fff', dur = 0.45, wd = 16}) => {
  const k = (t - t0) / dur; if (k <= 0 || k >= 1) return null; const d = size * (1 - (1 - k) ** 3);
  return <div style={{position: 'absolute', left: x - d / 2, top: y - d / 2, width: d, height: d, borderRadius: '50%', boxSizing: 'border-box', border: `${wd * (1 - k) + 1}px solid ${color}`, opacity: (1 - k) * 0.9}} />;
};
const Sparks: React.FC<{t: number; t0: number; x: number; y: number; n: number; seed: number; r0: number; color?: string; power?: number}> = ({t, t0, x, y, n, seed, r0, color = YEL, power = 1}) => {
  const k = (t - t0) / 0.42; if (k <= 0 || k >= 1) return null; const r = rnd(seed), e = 1 - (1 - k) ** 2.5;
  return <>{Array.from({length: n}, (_, i) => {
    const ang = (i + r() * 0.8) / n * TAU, dist = r0 + (240 + r() * 340) * power * e, len = (60 + r() * 90) * (1 - k) + 8, th = 6 + r() * 6;
    return <div key={i} style={{position: 'absolute', left: x + Math.cos(ang) * dist - len / 2, top: y + Math.sin(ang) * dist - th / 2, width: len, height: th, borderRadius: th, background: color, opacity: 1 - k * k, transform: `rotate(${ang}rad)`}} />;
  })}</>;
};
const Streaks: React.FC<{t: number; t0: number; dir: [number, number]; seed: number; n?: number; len?: number}> = ({t, t0, dir, seed, n = 18, len: L = 0.42}) => {
  const x = t - t0; if (x < -0.1 || x > L) return null; const env = Math.sin(Math.PI * cl((x + 0.1) / (L + 0.1))), r = rnd(seed), horiz = dir[0] !== 0, sgn = horiz ? dir[0] : dir[1];
  const span = horiz ? 1080 : 1920;
  return <>{Array.from({length: n}, (_, i) => {
    const perp = r(), len = 280 + r() * 560, th = 3 + r() * 7, ph = r(), op = env * (0.25 + 0.45 * r());
    const tr = ((x + 0.1) * 5600 + ph * (span + 900)) % (span + 900) - 700, pos = sgn > 0 ? tr : span - tr - len;
    const grad = `linear-gradient(${horiz ? 90 : 180}deg, transparent, rgba(255,255,255,.95), transparent)`;
    return horiz ? <div key={i} style={{position: 'absolute', left: pos, top: perp * 1920, width: len, height: th, borderRadius: th, background: grad, opacity: op}} />
      : <div key={i} style={{position: 'absolute', top: pos, left: perp * 1080, width: th, height: len, borderRadius: th, background: grad, opacity: op}} />;
  })}</>;
};
const Radial: React.FC<{t: number; t0: number; dur: number; inward?: boolean; cx: number; cy: number; seed: number; n?: number; color?: string; loop?: boolean; gain?: number}> = ({t, t0, dur, inward = false, cx, cy, seed, n = 24, color = '#fff', loop = false, gain = 1}) => {
  const k = (t - t0) / dur; if (k <= 0 || k >= 1) return null; const r = rnd(seed);
  return <>{Array.from({length: n}, (_, i) => {
    const ang = (i + r()) / n * TAU, ph = r(), len = 160 + r() * 320, th = 4 + r() * 6;
    const kk = loop ? ((t - t0) * 2.6 + ph) % 1 : cl((k - ph * 0.25) / (1 - ph * 0.25));
    const R = inward ? lerp(1300, 170, kk ** 1.7) : lerp(loop ? 420 : 240, 1400, loop ? kk ** 1.5 : 1 - (1 - kk) ** 2.2), op = Math.sin(Math.PI * kk) * (0.3 + 0.45 * r()) * gain * (loop ? Math.sin(Math.PI * k) ** 0.5 : 1);
    return <div key={i} style={{position: 'absolute', left: cx + Math.cos(ang) * R - len / 2, top: cy + Math.sin(ang) * R - th / 2, width: len * (inward ? 0.5 + kk : 1.2 - 0.6 * kk), height: th, borderRadius: th, background: `linear-gradient(90deg, transparent, ${color}, transparent)`, opacity: op, transform: `rotate(${ang}rad)`}} />;
  })}</>;
};

// one word: thick outline underneath, fill on top (works for Burmese stacks too)
const Word: React.FC<{s: string; color: string; size: number; sw: number; flat?: boolean}> = ({s, color, size, sw, flat}) => {
  // display words: gradient fill + purple outline + a short solid extrusion (toy / sticker depth). flat = small UI lines.
  const ex = flat ? 0 : Math.round(size * 0.09), w = flat ? sw : Math.round(size * 0.11);
  const sh = flat ? `0 ${Math.round(w * 0.55)}px 0 ${INKP}, 0 ${Math.round(w * 1.1)}px ${Math.round(size * 0.14)}px rgba(0,0,0,.45)` : Array.from({length: ex}, (_, i) => `0 ${i + 1}px 0 ${INKP}`).join(',') + `,0 ${ex + 6}px ${Math.round(size * 0.12)}px rgba(0,0,0,.45)`;
  return <span style={{position: 'relative', display: 'inline-block', whiteSpace: 'nowrap', lineHeight: 1.6}}>
    <span style={{color: INKP, WebkitTextStroke: `${w}px ${INKP}`, textShadow: sh}}>{s}</span>
    <span style={{position: 'absolute', left: '-0.12em', top: '-0.2em', padding: '0.2em 0.12em', ...(flat ? {color} : {backgroundImage: color === YEL ? GY : GW, WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent'})}}>{s}</span>
  </span>;
};
type Part = [string, string];
type CapP = {t: number; t0: number; t1: number; y: number; size: number; rot?: number; parts: Part[]; slam?: boolean; stagger?: number; beat?: boolean; maxW?: number; hold?: boolean; slamAmt?: number; times?: number[]; ui?: boolean};
// a caption: words pop in one by one ON t0, throw off an echo, bounce on the beat, and snap out before the cut
const Cap: React.FC<CapP> = ({t, t0, t1, y, size, rot = -3, parts, slam = false, stagger = 0.07, beat = true, maxW = 920, hold = false, slamAmt = 0.9, times, ui = false}) => {
  if (t < t0 - 0.05 || t >= t1) return null;
  const out = hold ? 0 : easeIn(seg(t, t1 - 0.1, t1)), sw = Math.round(size * 0.13);
  const pulse = beat ? 0.035 * Math.exp(-((t + 1e-6) % 0.5) / 0.09) : 0, ek = (t - t0) / 0.3;
  const wob = 1.1 * Math.sin(TAU * (t - t0) / 1.7);
  const row = (echo: boolean) => <div style={{display: 'flex', flexWrap: 'wrap', justifyContent: 'center', columnGap: size * 0.26, rowGap: 0, maxWidth: maxW, margin: '0 auto', fontFamily: ui ? 'Fr, MM' : 'Ti, Ku', fontSize: size}}>
    {parts.map(([s, c], i) => {
      const ti = times ? times[i] : t0 + i * stagger, k = slam && i === 0 ? 1 : sp(t, ti - 0.035, 3.8, 0.45), sl = slam && i === 0 ? 1 + slamAmt * Math.exp(-Math.max(0, t - t0) / 0.07) : 1;
      return <span key={i} style={{display: 'inline-block', transform: `translateY(${lerp(110, 0, k)}px) scale(${k * sl * (1 + 0.1 * hit(t, ti, 0.1))}) rotate(${lerp(i % 2 ? 16 : -16, 0, k)}deg)`, opacity: echo ? 1 : cl(k * 4)}}>
        {echo ? <span style={{whiteSpace: 'nowrap', lineHeight: 1.6, color: 'transparent', WebkitTextStroke: `4px ${c}`}}>{s}</span> : <Word s={s} color={c} size={size} sw={sw} flat={ui} />}
      </span>;
    })}
  </div>;
  return <>
    {ek > 0 && ek < 1 && <div style={{position: 'absolute', left: 40, width: 1000, top: y, transform: `translateY(-50%) rotate(${rot}deg) scale(${1 + 0.4 * ek})`, opacity: 0.55 * (1 - ek)}}>{row(true)}</div>}
    <div style={{position: 'absolute', left: 40, width: 1000, top: y, transform: `translateY(-50%) rotate(${rot + wob}deg) scale(${(1 + pulse) * (1 - out)})`}}>{row(false)}</div>
  </>;
};


// ================= kinetic type (taken from the owner's reference videos) =================
// size contrast (small label plate + one BIG keyword) | word by word, the newest word in the accent colour | letters cascading in |
// a counting number | a hand-drawn scribble | typed text with a cursor | a light sweep + a glow on the keyword
// split text into animation units: one Latin letter, or one whole Burmese SYLLABLE (never split a Burmese cluster: the font needs
// the whole syllable to shape it; Intl.Segmenter even splits the AA vowel off and the lone mark renders with a dotted circle)
const clusters = (s: string): string[] => {
  const ch = Array.from(s), out: string[] = [], cp = (i: number) => (i >= 0 && i < ch.length ? ch[i].codePointAt(0)! : 0);
  const isCons = (c: number) => (c >= 0x1000 && c <= 0x102a) || c === 0x103f || (c >= 0x104c && c <= 0x104f), isMy = (c: number) => c >= 0x1000 && c <= 0x109f;
  ch.forEach((c, i) => {
    const k = cp(i), n1 = cp(i + 1), n2 = cp(i + 2);
    const killed = n1 === 0x103a || n1 === 0x1039 || (n1 === 0x1037 && n2 === 0x103a);          // a final consonant belongs to the syllable before it
    const startsNew = !isMy(k) || (isCons(k) && !killed && cp(i - 1) !== 0x1039);
    if (startsNew || out.length === 0 || !isMy(cp(i - 1))) out.push(c); else out[out.length - 1] += c;
  });
  return out;
};
const BAND = 'linear-gradient(105deg, rgba(255,255,255,0) 36%, rgba(255,255,255,.95) 50%, rgba(255,255,255,0) 64%)';
// one letter (or one Burmese cluster) in the display style: gradient fill, purple outline, short extrusion, optional light sweep + glow
const Glyph: React.FC<{s: string; size: number; accent: boolean; shine?: number; glow?: number}> = ({s, size, accent, shine = -1, glow = 0}) => {
  const w = Math.round(size * 0.11), ex = Math.round(size * 0.09), base = accent ? GY : GW, on = shine > 0 && shine < 1;
  const sh = Array.from({length: ex}, (_, i) => `0 ${i + 1}px 0 ${INKP}`).join(',') + `,0 ${ex + 6}px ${Math.round(size * 0.12)}px rgba(0,0,0,.45)` + (glow > 0.02 ? `,0 0 ${Math.round(size * 0.45)}px rgba(255,205,60,${(0.85 * glow).toFixed(3)})` : '');
  return <span style={{position: 'relative', display: 'inline-block', whiteSpace: 'pre', lineHeight: 1.6}}>
    <span style={{color: INKP, WebkitTextStroke: `${w}px ${INKP}`, textShadow: sh}}>{s}</span>
    <span style={{position: 'absolute', left: '-0.12em', top: '-0.2em', padding: '0.2em 0.12em', backgroundImage: on ? `${BAND}, ${base}` : base, backgroundSize: on ? '300% 100%, 100% 100%' : undefined, backgroundPosition: on ? `${lerp(100, 0, shine)}% 0, 0 0` : undefined, backgroundRepeat: 'no-repeat', WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent'}}>{s}</span>
  </span>;
};
type KW = [string, number, 'key' | 'now' | 'w', number?];      // word, the time it lands (a measured hit), colour rule: always accent | accent while it is the newest | white
type KinP = {t: number; y: number; size: number; rot?: number; words: KW[]; t1: number; anim?: 'cascade' | 'slam'; maxW?: number; font?: string; gap?: number};
const Kin: React.FC<KinP> = ({t, y, size, rot = -3, words, t1, anim = 'cascade', maxW = 940, font = 'Ti, Ku', gap = 0.24}) => {
  const tFirst = words[0][1]; if (t < tFirst - 0.14 || t >= t1) return null;
  let ci = 0;
  return <div style={{position: 'absolute', left: 20, width: 1040, top: y, transform: `translateY(-50%) rotate(${rot + 0.9 * Math.sin(TAU * (t - tFirst) / 1.9)}deg)`}}>
    <div style={{display: 'flex', flexWrap: 'wrap', justifyContent: 'center', columnGap: size * gap, maxWidth: maxW, margin: '0 auto', fontFamily: font, fontSize: size}}>
      {words.map(([txt, tj, rule, big], j) => {
        const next = words[j + 1], accent = rule === 'key' || (rule === 'now' && (!next || t < next[1])), sz = Math.round(size * (big || 1));
        return <span key={j} style={{display: 'inline-block', whiteSpace: 'nowrap', fontSize: sz}}>
          {clusters(txt).map((c, i) => {
            const idx = ci++, ti = anim === 'slam' ? tj : tj - 0.05 + i * 0.02, k = anim === 'slam' ? 1 : sp(t, ti, 3.7, 0.5);
            const e = easeIn(seg(t, t1 - 0.15 + idx * 0.005, t1 - 0.01)), slam = anim === 'slam' ? 1 + 0.1 * Math.exp(-Math.max(0, t - tj) / 0.07) : 1;
            const tr = `translate(${lerp(40, 0, k)}px, ${lerp(-150, 0, k) + 80 * e}px) rotate(${lerp(i % 2 ? 26 : 18, 0, k)}deg) scale(${lerp(0.35, 1, k) * slam * (1 + 0.07 * hit(t, tj, 0.09))})`;
            const shn = accent ? seg(t, tj + 0.14 + i * 0.028, tj + 0.46 + i * 0.028) : -1;
            return <span key={i} style={{display: 'inline-block', transform: tr, opacity: cl(k * 6) * (1 - e) * (t >= ti ? 1 : 0)}}><Glyph s={c} size={sz} accent={accent} shine={shn} glow={accent ? hit(t, tj, 0.3) : 0} /></span>;
          })}
        </span>;
      })}
    </div>
  </div>;
};
// small label on a plain plate (the TikTok-native caption look of the reference videos); wipes open from its centre
const Plate: React.FC<{t: number; t0: number; t1: number; y: number; text: string; size?: number; rot?: number}> = ({t, t0, t1, y, text, size = 54, rot = -3}) => {
  if (t < t0 - 0.03 || t >= t1) return null;
  const k = sp(t, t0 - 0.03, 3.4, 0.62), e = easeIn(seg(t, t1 - 0.12, t1)), cut = cl((1 - k) * 50 + e * 50, 0, 50);
  return <div style={{position: 'absolute', left: 0, right: 0, top: y, display: 'flex', justifyContent: 'center', transform: `translateY(-50%) rotate(${rot}deg)`}}>
    <div style={{clipPath: `inset(0 ${cut}% 0 ${cut}% round 24px)`, background: '#fff', color: INKP, fontFamily: 'Fr, MM', fontSize: size, lineHeight: 1.55, padding: '4px 30px 8px', borderRadius: 24, whiteSpace: 'nowrap', transform: `scale(${1 + 0.07 * hit(t, t0, 0.1)})`, borderBottom: `8px solid ${INKP}`}}>{text}</div>
  </div>;
};
// the price: pops in on the hit, counts up fast, lands with a punch, then a hand-drawn scribble is drawn around it
const Count: React.FC<{t: number; t0: number; t1: number; y: number; to: number; roll?: number}> = ({t, t0, t1, y, to, roll = 0.34}) => {
  if (t < t0 - 0.05 || t >= t1) return null;
  const land = t0 + roll, k = easeOut(seg(t, t0 - 0.02, land)), v = k >= 1 ? to : Math.floor(to * k / 100) * 100;
  const str = v.toLocaleString('en-US').padStart(6, ' '), e = easeIn(seg(t, t1 - 0.12, t1)), draw = easeOut(seg(t, land + 0.02, land + 0.34)), size = 232, L = 2500;
  const path = 'M 95 215 C 70 95, 380 28, 610 46 C 860 68, 905 285, 660 352 C 430 408, 98 372, 82 232 C 66 108, 330 44, 575 60';
  return <div style={{position: 'absolute', left: 0, right: 0, top: y, transform: `translateY(-50%) rotate(-5deg) scale(${sp(t, t0 - 0.04, 3.4, 0.5) * (1 + 0.1 * hit(t, land, 0.1)) * (1 - e)})`}}>
    <svg width="960" height="430" viewBox="0 0 960 430" style={{position: 'absolute', left: '50%', top: '50%', marginLeft: -480, marginTop: -215}}>
      <path d={path} fill="none" stroke={INKP} strokeWidth={22} strokeLinecap="round" strokeDasharray={L} strokeDashoffset={L * (1 - draw)} />
      <path d={path} fill="none" stroke={YEL} strokeWidth={11} strokeLinecap="round" strokeDasharray={L} strokeDashoffset={L * (1 - draw)} />
    </svg>
    <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
      <span style={{fontFamily: 'An', fontSize: size, transform: 'skewX(-8deg)', display: 'inline-block', whiteSpace: 'pre'}}>
        {str.split('').map((c, i) => <span key={i} style={{display: 'inline-block', width: c === ',' ? size * 0.2 : c === ' ' ? 0 : size * 0.47, textAlign: 'center'}}>{c !== ' ' && <Glyph s={c} size={size} accent shine={seg(t, land + 0.1 + i * 0.03, land + 0.42 + i * 0.03)} glow={hit(t, land, 0.35)} />}</span>)}
      </span>
      <span style={{fontFamily: 'Ti', fontSize: 104, marginLeft: 22, transform: `translateY(-34px) scale(${sp(t, land - 0.03, 3.6, 0.45)})`, display: 'inline-block'}}><Glyph s="Ks" size={104} accent={false} /></span>
    </div>
  </div>;
};
const Typed: React.FC<{t: number; t0: number; y: number; label: string; text: string; size: number; per?: number}> = ({t, t0, y, label, text, size, per = 0.032}) => {
  if (t < t0 - 0.02) return null;
  const n = cl(Math.floor((t - t0) / per) + 1, 0, text.length), cur = n < text.length || Math.floor(t * 3) % 2 === 0;
  return <div style={{position: 'absolute', left: 0, right: 0, top: y, textAlign: 'center', fontFamily: 'Fr', fontSize: size, color: '#fff', textShadow: `0 5px 0 ${INKP}`, whiteSpace: 'pre', transform: `scale(${sp(t, t0 - 0.03, 3.4, 0.6)})`}}>{label}<span style={{color: YEL}}>{text.slice(0, n)}</span><span style={{color: YEL, opacity: cur ? 1 : 0}}>|</span></div>;
};
// the shop's wordmark, letter by letter: 'slam' for the drop, 'arc' (letters falling in along a curve) for the end card
const BrandWord: React.FC<{t: number; t0: number; size: number; mode: 'slam' | 'arc'; pulse?: number}> = ({t, t0, size, mode, pulse = 0}) => <span style={{fontFamily: 'Fr', fontSize: size, letterSpacing: -2, whiteSpace: 'nowrap'}}>
  {'FlexiToys'.split('').map((c, i) => {
    const ti = t0 - 0.03 + i * (mode === 'slam' ? 0.013 : 0.034), k = sp(t, ti, mode === 'slam' ? 3.0 : 3.3, 0.48), m = i - 4;
    const big = k <= 1 ? lerp(3.4, 1, k) : 1 - 0.45 * (k - 1);
    const tr = mode === 'slam' ? `translateY(${lerp(i % 2 ? -70 : 70, 0, Math.min(k, 1))}px) scale(${big * (1 + pulse)})` : `translate(${lerp(m * -34, 0, k)}px, ${lerp(-300 - 36 * Math.abs(m), 0, k)}px) rotate(${lerp(m * -13, 0, k)}deg) scale(${lerp(0.5, 1, k) * (1 + pulse)})`;
    return <span key={i} style={{display: 'inline-block', transform: tr, opacity: cl(k * 6) * (t >= ti ? 1 : 0)}}><Glyph s={c} size={size} accent={i >= 5} shine={seg(t, t0 + 0.24 + i * 0.03, t0 + 0.58 + i * 0.03)} glow={i >= 5 ? hit(t, t0, 0.35) : 0} /></span>;
  })}
</span>;

// One composition for ANY sound: all times come from the cut-list JSON (cfg.T = the named moments, placed on the sound's measured hits).
export const AdT: React.FC<{cfg: any}> = ({cfg}) => {
  const f = useCurrentFrame(); const {fps} = useVideoConfig(); const t = f / fps;
  const SHOTS = cfg.shots as Shot[], H = cfg.handle as number, DUR = cfg.dur as number, T = cfg.T as Record<string, number>, HITS = cfg.hits as number[];
  const DROP = T.DROP, END = T.END, CTA = T.CTA;
  const BIG: [number, number, number][] = [[0, 24, 0.14], [DROP, 46, 0.2], [END, 30, 0.18], [CTA, 16, 0.14]];
  const shakeAmt = BIG.reduce((a, [t0, amt, d]) => a + amt * hit(t, t0, d), 0);
  const r = rnd(Math.floor(t * 30 + 1e-6) + 3);
  const shx = (r() - 0.5) * 2 * shakeAmt, shy = (r() - 0.5) * 2 * shakeAmt;
  const flash = 0.3 * cl(1 - t / 0.12) + [[DROP, 0.8, 0.16], [END, 0.45, 0.14], [CTA, 0.25, 0.12]].reduce((a, [t0, amt, d]) => a + (t >= t0 ? amt * cl(1 - (t - t0) / d) : 0), 0);
  const stop = seg(t, T.pick, DROP - 0.04) * (t < DROP ? 1 : 0);                       // stop-down on the sound's pickup, right before its drop
  const split = 16 * hit(t, DROP, 0.09) + 10 * hit(t, END, 0.08);
  const endDim = smooth(seg(t, END, END + 0.22));
  // every measured hit of the sound gives the picture a small punch; the triple hits become a stutter
  const hp = HITS.reduce((a, h) => a + (h > T.cutD && h !== DROP && h !== END ? 0.055 * hit(t, h, 0.065) : 0), 0);
  const step = 0.075 * ((t >= T.z1 ? 1 : 0) + (t >= T.z2 ? 1 : 0) + (t >= T.z3 ? 1 : 0));   // three jump-zooms on the pre-drop fill

  const shotEl = (s: Shot, i: number) => {
    const nx = SHOTS[i + 1], tc = s.t, te = nx ? nx.t : DUR, dIn = DIR[s.in], dOut = nx ? DIR[nx.in] : undefined;
    const vis0 = tc - (dIn ? WHIP : 0), vis1 = te + (dOut ? WHIP : 0);
    const from = Math.round((tc - H) * fps), n = Math.round((s.d + 2 * H) * fps);
    if (t < vis0 || t >= vis1) return null;
    const u = cl((t - tc) / s.d);
    let sc = 1.03 + 0.05 * u + hp + (s.in === 'drop' ? 0.14 : s.in === 'hit' ? 0.1 : s.in === 'start' ? 0.08 : s.in === 'punch' ? 0.08 : 0.04) * hit(t, tc, 0.14);
    let tx = 0, ty = 0, bx = 0, by = 0, blur = 0, rot = (i % 2 ? 1 : -1) * 0.8 * (1 - smooth(u * 2.5));
    if (dIn && t < tc + WHIP) { const k = seg(t, tc - WHIP, tc + WHIP), p = smooth(k), v = 6 * k * (1 - k) / 1.5; tx += dIn[0] * (p - 1) * 1080; ty += dIn[1] * (p - 1) * 1920; bx += Math.abs(dIn[0]) * 110 * v; by += Math.abs(dIn[1]) * 150 * v; }
    if (dOut && t >= te - WHIP) { const k = seg(t, te - WHIP, te + WHIP), p = smooth(k), v = 6 * k * (1 - k) / 1.5; tx += dOut[0] * p * 1080; ty += dOut[1] * p * 1920; bx += Math.abs(dOut[0]) * 110 * v; by += Math.abs(dOut[1]) * 150 * v; }
    if (nx && nx.in === 'zoom') { const k = easeIn(seg(t, te - 0.16, te)); sc *= 1 + 1.7 * k; blur += 16 * k; }
    if (s.in === 'zoom') { const k = 1 - easeOut(seg(t, tc, tc + 0.22)); sc *= 1 + 0.6 * k; blur += 12 * k; }
    if (s.id === 'd') sc = (sc + step) * (1 - 0.08 * stop);
    if (s.id === 'l') blur += 7 * endDim;
    if (s.id === 'd') blur += 5 * stop;
    const fid = `bl${i}`, useF = bx > 0.6 || by > 0.6;
    const st: React.CSSProperties = {position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, transform: `translate(${tx}px,${ty}px) rotate(${rot}deg) scale(${sc})`, filter: useF ? `url(#${fid})` : blur > 0.3 ? `blur(${blur}px)` : undefined};
    const ghost = split > 0.6 && (s.id === 'f' || s.id === 'l');
    return <Sequence key={s.id} from={from} durationInFrames={n} layout="none">
      {useF && <svg width="0" height="0" style={{position: 'absolute'}}><filter id={fid} x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation={`${bx.toFixed(1)} ${by.toFixed(1)}`} /></filter></svg>}
      <OffthreadVideo muted src={staticFile(`${cfg.dir}/${s.id}.mp4`)} style={st} />
      {ghost && [-1, 1].map(d => <OffthreadVideo key={d} muted src={staticFile(`${cfg.dir}/${s.id}.mp4`)} style={{...st, transform: `translate(${tx + d * split}px,${ty}px) rotate(${rot}deg) scale(${sc})`, opacity: 0.45, filter: `hue-rotate(${d * 110}deg) saturate(2)`, mixBlendMode: 'screen'}} />)}
    </Sequence>;
  };

  return <AbsoluteFill style={{background: '#000', overflow: 'hidden'}}>
    <style>{FONT}</style>
    <AbsoluteFill style={{transform: `translate(${shx}px,${shy}px)`}}>
      {SHOTS.map(shotEl)}
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(10,4,30,.5), rgba(10,4,30,0) 34%)'}} />
      <AbsoluteFill style={{background: '#000', opacity: 0.6 * stop}} />
      <AbsoluteFill style={{background: `linear-gradient(180deg, rgba(42,18,98,.78), rgba(20,8,50,.4) 55%, rgba(20,8,50,.72))`, opacity: endDim}} />
    </AbsoluteFill>

    {SHOTS.map((s, i) => DIR[s.in] && <Streaks key={s.id} t={t} t0={s.t - 0.16} dir={DIR[s.in]} seed={50 + i} len={0.34} />)}
    <Radial t={t} t0={DROP - 0.65} dur={0.6} inward cx={540} cy={900} seed={21} />
    <Radial t={t} t0={0} dur={0.32} cx={540} cy={1150} seed={22} color={YEL} />
    <Radial t={t} t0={DROP} dur={0.38} cx={540} cy={860} seed={23} n={30} />
    <Radial t={t} t0={T.cutK - 0.03} dur={Math.min(1.2, END - T.cutK - 0.1)} cx={540} cy={900} seed={24} n={26} loop gain={0.7} />
    <Radial t={t} t0={END} dur={0.36} cx={540} cy={700} seed={25} n={30} color={YEL} />
    <Ring t={t} t0={0} x={540} y={1150} size={2200} color={YEL} dur={0.45} wd={24} />
    <Ring t={t} t0={DROP} x={540} y={860} size={2600} color={YEL} dur={0.55} wd={34} /><Ring t={t} t0={DROP + 0.08} x={540} y={860} size={2000} dur={0.5} wd={12} />
    <Ring t={t} t0={END} x={540} y={600} size={2400} color={YEL} dur={0.5} wd={24} />
    <Ring t={t} t0={CTA} x={540} y={1345} size={1900} color={YEL} dur={0.45} wd={20} />
    <Sparks t={t} t0={DROP} x={540} y={860} n={20} seed={31} r0={380} power={1.9} /><Sparks t={t} t0={CTA} x={540} y={1345} n={14} seed={32} r0={330} power={1.4} />
    <Sparks t={t} t0={T.cutB + 0.34} x={540} y={420} n={14} seed={33} r0={400} />

    {/* ---- text: every word lands on a measured hit of the sound ---- */}
    <Kin t={t} y={330} size={122} rot={-4} anim="slam" words={[['ဘာထွက်မလဲ?', 0, 'key']]} t1={T.cutB} />
    <Plate t={t} t0={T.plateA} t1={T.cutB} y={530} text="Blox Fruits Blind Box" rot={-4} />
    <Plate t={t} t0={T.cutB} t1={T.cutC} y={196} text="Blox Fruits Blind Box" rot={-5} size={50} />
    <Count t={t} t0={T.cutB} t1={T.cutC} y={420} to={29500} />
    <Kin t={t} y={350} size={104} rot={3} words={[['Minecraft', T.cutC, 'now'], ['+', T.roblox, 'w'], ['Roblox', T.roblox, 'now']]} t1={T.cutD} />
    <Plate t={t} t0={T.plateC} t1={T.cutD} y={612} text="လည်း ရှိတယ်" rot={3} size={62} />
    <Kin t={t} y={340} size={120} rot={-3} words={[['Blind Box', T.cutD, 'now'], ['အစုံ', T.z1, 'key', 1.45]]} t1={T.pick - 0.03} />
    {t >= DROP - 0.05 && t < T.cutG && <div style={{position: 'absolute', left: 0, right: 0, top: 760, textAlign: 'center', transform: `translateY(-50%) rotate(-4deg) scale(${1 - easeIn(seg(t, T.cutG - 0.12, T.cutG))})`}}><BrandWord t={t} t0={DROP} size={210} mode="slam" pulse={hp} /></div>}
    <Kin t={t} y={1010} size={128} rot={-4} words={[['အရုပ်ဆိုင်', T.toy, 'key']]} t1={T.cutG} />
    <Kin t={t} y={345} size={114} rot={3} words={[['အသစ်တွေ', T.g1, 'now'], ['ရောက်ပြီ!', T.g2, 'now', 1.25]]} t1={T.cutH} />
    <Kin t={t} y={345} size={110} rot={-3} words={[['ကိုယ်တိုင်', T.cutH, 'now'], ['ဆက်ကြမယ်', T.h2, 'now', 1.25]]} t1={T.cutI} />
    <Kin t={t} y={320} size={128} rot={3} words={[['Keychain', T.cutJ, 'key']]} t1={T.cutK} />
    <Plate t={t} t0={T.j2} t1={T.cutK} y={482} text="တွေလည်း ရှိတယ်" rot={3} size={62} />
    <Kin t={t} y={640} size={150} rot={-4} words={[['ဘယ်မှာလဲ?', T.k0, 'w']]} t1={T.k1 - 0.04} />
    <Kin t={t} y={450} size={106} rot={-3} words={[['Junction', T.k1, 'key'], ['Centre', T.k2, 'key']]} t1={END} maxW={1000} />
    <Kin t={t} y={630} size={118} rot={-3} words={[['နေပြည်တော်', T.k3, 'w']]} t1={END} />

    {/* end card: the wordmark falls in along an arc, the address on a plate, the handle typed out, then the call to action */}
    {t >= END - 0.05 && <>
      <div style={{position: 'absolute', left: 0, right: 0, top: 560, textAlign: 'center', transform: `translateY(-50%) rotate(${-3 + 0.8 * Math.sin(TAU * t / 2.6)}deg)`}}><BrandWord t={t} t0={END} size={200} mode="arc" pulse={0.06 * hit(t, CTA, 0.18) + hp * 0.5} /></div>
      <Kin t={t} y={775} size={110} rot={-3} words={[['အရုပ်ဆိုင်', T.e1, 'key']]} t1={DUR + 1} />
      <Plate t={t} t0={T.e2} t1={DUR + 1} y={985} text="Junction Centre · နေပြည်တော်" size={62} rot={-3} />
      <Typed t={t} t0={T.e3} y={1108} label="TikTok  " text="@flexitoysmm" size={62} />
      <Kin t={t} y={1350} size={98} rot={-3} words={[['ဒီနေ့ပဲ', CTA, 'w'], ['လာခဲ့နော်!', T.c2, 'key', 1.2]]} t1={DUR + 1} maxW={1000} />
    </>}

    <AbsoluteFill style={{background: 'radial-gradient(ellipse at center,transparent 62%,rgba(0,0,0,.38) 100%)'}} />
    <AbsoluteFill style={{background: '#fff', opacity: cl(flash)}} />
    <AbsoluteFill style={{background: '#000', opacity: seg(t, DUR - 0.3, DUR - 0.03)}} />
  </AbsoluteFill>;
};
