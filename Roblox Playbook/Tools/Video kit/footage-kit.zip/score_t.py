"""Sound for the FlexiToys ad, for ANY trending sound: all times come from the cut-list JSON (cfg['T'] = named moments on the sound's measured hits).
usage: python3 score_t.py src/shots3.json sfx3 mix3 events3
Writes public/<sfx>.wav (effects only, NO pitched sounds, quiet: sits under the trending sound), out/<mix>_raw.wav (our own music on the same grid + effects), src/<events>.json."""
import json, sys, numpy as np, scipy.signal as sg, soundfile as sf
import synth as S
cfgp, sfxn, mixn, evn = sys.argv[1:5]
J = json.load(open(cfgp)); DUR = J['dur']; B = J['beat']; T = J['T']; DROP = T['DROP']; END = T['END']; CTA = T['CTA']
S.init(DUR); SR = S.SR; N = S.N; rng = S.rng
EV = []
def ev(t, kind, **kw): EV.append(dict(t=round(t, 3), kind=kind, **kw))
def whip(t, pan, lab, g=0.45, lead=0.09): ev(t - lead, 'whoosh', pan=pan, dur=0.36, peak=0.5, g=g, label=lab)

ev(0.0, 'impact', size=0.9, label='hook: box in hand'); ev(0.02, 'sparkle', dur=0.6)
ev(T['plateA'], 'pop', f=784, label='product name plate')
whip(T['cutB'], (0.8, -0.8), 'whip to price', 0.35); ev(T['cutB'], 'thud', label='price pops in')
for k in range(5): ev(T['cutB'] + 0.06 + k * 0.055, 'click', label='typing: price counts up')
ev(T['cutB'] + 0.34, 'thud', label='price lands'); ev(T['cutB'] + 0.34, 'bell', f=1568, label='price lands (bell)')
ev(T['cutC'], 'thud', label='cut Minecraft / Roblox'); ev(T['cutC'], 'pop', f=988); ev(T['roblox'], 'pop', f=1175, label='Roblox'); ev(T['plateC'], 'click', big=True, label='label plate')
whip(T['cutD'], (0, 0), 'whip to the counter', 0.35); ev(T['cutD'], 'pop', f=880, label='Blind Box')
ev(T['z1'], 'thud', soft=True, label='jump zoom 1'); ev(T['z1'], 'pop', f=1046, label='all kinds')
ev(T['z2'], 'click', big=True, label='jump zoom 2'); ev(T['z3'], 'thud', soft=True, label='jump zoom 3')
ev(DROP - 1.5, 'riser', dur=1.2); ev(DROP - 0.7, 'suckback', dur=0.42)
ev(DROP, 'impact', size=1.25, label='DROP: shop name'); ev(DROP + 0.03, 'sparkle', dur=0.7)
ev(T['toy'], 'pop', f=1046, label='toy shop')
whip(T['cutG'], (-0.8, 0.8), 'whip to sets'); ev(T['g1'], 'pop', f=880, label='new arrivals'); ev(T['g2'], 'pop', f=1046, label='arrived')
ev(T['cutH'], 'thud', label='cut build'); ev(T['h2'], 'pop', f=988, label='build word 2')
whip(T['cutI'], (0.8, -0.8), 'whip to mini cars', 0.4, 0.1); ev(T['cutI'], 'thud', label='cut mini cars')
ev(T['cutJ'], 'thud', label='cut keychains'); ev(T['j2'], 'pop', f=1175, label='keychain plate')
ev(T['cutK'] - 0.11, 'whoosh', pan=(0, 0), dur=0.6, peak=0.45, g=0.6, label='zoom into the mall'); ev(T['k0'], 'pop', f=660, label='where?')
ev(T['cutK'] + 0.1, 'riser', dur=max(0.6, END - T['cutK'] - 0.25))
ev(T['k1'], 'pop', f=784, label='Junction'); ev(T['k2'], 'pop', f=880, label='Centre'); ev(T['k3'], 'pop', f=1046, label='Nay Pyi Taw')
ev(END, 'impact', size=1.05, label='END CARD: shop name'); ev(END + 0.03, 'sparkle', dur=0.6)
ev(T['e1'], 'pop', f=880, label='toy shop (end)'); ev(T['e2'], 'pop', f=988, label='address plate')
for k in range(12): ev(T['e3'] + k * 0.032, 'click', label='typing: handle')
ev(CTA, 'impact', size=0.9, label='CTA'); ev(T['c2'], 'pop', f=1318, label='CTA word 2')

def render(neutral):
    """neutral=True: NO pitched sounds (no bells, no tonal pops, no tonal riser), so the effects can sit under ANY song without clashing with its key."""
    for e in EV:
        k, t = e['kind'], e['t']
        if k == 'impact': S.put_st(S.impact(e['size']), t, 0, 0.95)
        elif k == 'sparkle':
            if not neutral: S.put_st(S.sparkle(e['dur']), t, (-0.6, 0.6), 0.8)
        elif k == 'pop':
            if neutral: S.put_st(S.click() * 1.9, t, 0, 0.6); S.put_st(S.impact(0.4)[:int(0.16 * SR)] * 0.35, t, 0, 0.8)
            else: S.put_st(S.pop(e['f']), t, 0, 0.75)
        elif k == 'whoosh': S.put_st(S.whoosh(e['dur'], e.get('peak', 0.55)), t - e['dur'] * e.get('peak', 0.55), tuple(e['pan']), e['g'])
        elif k == 'thud': S.put_st(S.impact(0.55)[:int(0.35 * SR)] * (0.5 if e.get('soft') else 0.75), t, 0, 0.8)
        elif k == 'riser':
            if neutral: S.put_st(S.whoosh(e['dur'], 0.96, 1.3), t, 0, 0.45)
            else: S.put_st(S.riser(e['dur']), t, 0, 0.5)
        elif k == 'suckback': S.put_st(S.suckback(e['dur']), t, 0, 0.9)
        elif k == 'click': S.put_st(S.click() * (2.2 if e.get('big') else 1.5), t, rng.uniform(-0.25, 0.25), 0.6)
        elif k == 'bell':
            if neutral: S.put_st(S.click() * 2.4, t, 0, 0.6)
            else: S.put_st(S.bell(e['f']), t, 0, 0.5)

hp = sg.butter(2, 30 / (SR / 2), 'high', output='sos'); tail = int(0.35 * SR); fade = np.linspace(1, 0, tail)[:, None] ** 1.5
render(True)
sfx = sg.sosfilt(hp, np.stack([S.L, S.R], 1), axis=0); sfx[-tail:] *= fade
sf.write(f'public/{sfxn}.wav', sfx / np.abs(sfx).max() * 0.5, SR)
S.init(DUR); render(False)

# ---------- our own music on the same grid: soft intro, a kick on every beat after the drop ----------
M = S.M; put = S.put
st = lambda s: 261.63 * 2 ** (s / 12)
CH = [('Am', st(-27), [st(-3), st(0), st(4)]), ('F', st(-31), [st(-7), st(-3), st(0)]), ('C', st(-24), [st(0), st(4), st(7)]), ('G', st(-29), [st(-5), st(-1), st(2)])]
PENT = [st(s) for s in (12, 14, 16, 19, 21, 24)]
kicks = []
def pad(tri, dur, g):
    n = int(dur * SR); t = np.arange(n) / SR
    x = sum(np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 2 * f * t) for f in tri)
    return x * np.minimum(1, t / 0.25) * np.minimum(1, (dur - t) / 0.4) * g
nb = int(np.floor(DROP / B)); t_first = DROP - nb * B          # beats before the drop, counted back from it
for k in range(nb):
    t = t_first + k * B
    if t < 0 or t > T['pick'] - 0.05: continue
    name, root, tri = CH[(k // 4) % 4]
    if k % 4 == 0: put(M, pad(tri, 4 * B + 0.3, 0.06), t)
    put(M, S.pluck(tri[k % 3] * 2, 0.3, 1900) * 0.6, t); put(M, S.hat() * 0.7, t + B / 2)
for h in J.get('introHits', []): put(M, S.pluck(PENT[2], 0.35, 4200) * 0.6, h); put(M, S.kick() * 0.45, h); kicks.append(h)
for h in (T['z1'], T['z2'], T['z3']): put(M, S.kick() * 0.6, h); put(M, S.clap() * 0.5, h); kicks.append(h)
k = 0
while DROP + k * B < DUR - 0.9:
    t = DROP + k * B; name, root, tri = CH[(k // 4 + 2) % 4]
    put(M, S.kick() * 0.7, t); kicks.append(t)
    if k % 2 == 1: put(M, S.clap() * 0.8, t)
    for e in range(2):
        te = t + e * B / 2
        put(M, S.hat(e == 1) * 1.4, te); put(M, S.bass(root * 2, B / 2 * 0.95) * (1.0 if e else 0.8), te)
        put(M, S.pluck(tri[(2 * k + e) % 3] * (2 if e else 1), bright=3400), te)
        put(M, S.pluck(PENT[(3 * k + 2 * e) % 6], 0.2, 5200) * 0.45, te)
    k += 1
fin = sum(S.pluck(f, 1.0, 3000) for f in CH[2][2]) + S.bass(CH[2][1] * 2, 1.0)
put(M, S.reverb(fin * 1.1, wet=0.45)[:int(1.0 * SR)], CTA)
side = np.ones(N)
for tk in kicks:
    i = int(tk * SR); n = int(0.2 * SR); j = min(N, i + n)
    if 0 <= i < N: side[i:j] = np.minimum(side[i:j], 1 - 0.28 * np.exp(-np.arange(j - i) / SR / 0.07))
M *= side
j = int(T['pick'] * SR); M[:j] = S.filt(M[:j], 'high', 180) * 0.75
sd = np.ones(N); i, j = int((T['pick'] + 0.02) * SR), int(DROP * SR); sd[i:j] = 0; sd[i - 960:i] = np.linspace(1, 0, 960); M *= sd
duck = np.ones(N)
for e in EV:
    if e['kind'] == 'impact':
        i = int(e['t'] * SR); n = int(0.45 * SR); j = min(N, i + n)
        duck[i:j] = np.minimum(duck[i:j], 1 - 0.37 * np.exp(-np.arange(j - i) / SR / 0.16))
M *= duck
Mh = S.filt(M, 'high', 2500); d = int(0.011 * SR)
ML = M + 0.35 * Mh; MR = M + 0.35 * np.concatenate([np.zeros(d), Mh[:-d]])
mix = sg.sosfilt(hp, np.stack([ML * 0.62 + S.L * 0.9, MR * 0.62 + S.R * 0.9], 1), axis=0); mix[-tail:] *= fade
mix = np.tanh(mix / np.abs(mix).max() * 1.6) / np.tanh(1.6) * 0.89
sf.write(f'out/{mixn}_raw.wav', mix, SR)
json.dump(dict(bpm=J['bpm'], beat=B, dur=DUR, events=EV), open(f'src/{evn}.json', 'w'), indent=0)
print('events', len(EV), 'kicks', len(kicks))
