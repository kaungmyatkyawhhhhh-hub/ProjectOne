"""Scan clips (or a final video) for faces with YuNet. Prints, per file, the frames with a face and the largest face height in px."""
import sys, cv2, numpy as np
det = cv2.FaceDetectorYN.create('models/yunet.onnx', '', (540, 960), 0.6, 0.3, 50)
def scan(path, step=6, save=None):
    cap = cv2.VideoCapture(path); n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)); fps = cap.get(cv2.CAP_PROP_FPS); hits = []; i = 0
    while True:
        ok, f = cap.read()
        if not ok: break
        if i % step == 0:
            s = cv2.resize(f, (540, 960)); det.setInputSize((540, 960)); _, faces = det.detect(s)
            if faces is not None:
                for fc in faces:
                    x, y, w, h = fc[:4] * 2; hits.append((round(i / fps, 2), int(h), int(x + w / 2), int(y + h / 2), round(float(fc[-1]), 2)))
        i += 1
    return n, fps, hits
for p in sys.argv[1:]:
    n, fps, hits = scan(p)
    big = [h for h in hits if h[1] >= 60]
    print(p.split('/')[-1], f'{n/fps:.1f}s', 'faces>=60px:', len(big), '| max h:', max([h[1] for h in hits], default=0), '| e.g.', big[:4] if big else hits[:2])
