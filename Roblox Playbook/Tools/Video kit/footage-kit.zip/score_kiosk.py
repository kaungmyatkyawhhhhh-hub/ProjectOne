"""FlexiToys shop ad: music + sound effects in code. One timeline (src/events.json) drives the sound AND the picture.
120 BPM, C major (bright, playful). hook -> build + stop-down -> DROP 4.0 -> product beats -> walk (breakdown + riser) -> arrive 16.0 -> end card 18.0 -> final hit 20.0."""
import json, numpy as np, scipy.signal as sg, soundfile as sf
import synth as S
DUR = 22.0; S.init(DUR); SR = S.SR; B = 0.5; N = S.N; rng = S.rng
EV = []
def ev(t, kind, **kw): EV.append(dict(t=round(t, 3), kind=kind, **kw))
def whip(t, pan, lab): ev(t - 0.04, 'whoosh', pan=pan, dur=0.36, peak=0.5, g=0.6, label=lab)      # loudest point on the fastest frame of the whip

# hook
ev(0.0, 'impact', size=1.0, label='hook: box in hand'); ev(0.02, 'sparkle', dur=0.7)
whip(1.0, (0.8, -0.8), 'whip to presenter'); ev(1.0, 'pop', f=784, label='Blind Box text')
# build
ev(2.0, 'thud', label='price shot'); ev(2.0, 'bell', f=1568, label='price stamp')
ev(2.0, 'riser', dur=1.72)
whip(3.0, (0, 0), 'whip to Minecraft / Roblox'); ev(3.0, 'pop', f=988, label='names')
ev(3.3, 'suckback', dur=0.44)
# drop
ev(4.0, 'impact', size=1.25, label='DROP: shop name'); ev(4.03, 'sparkle', dur=0.7)
ev(4.5, 'pop', f=1046, label='toy shop line')
ev(5.5, 'thud', label='cut blind boxes 1'); ev(5.5, 'pop', f=880)
whip(6.0, (-0.8, 0.8), 'whip blind boxes 2'); ev(6.0, 'thud', soft=True, label='cut')
ev(6.5, 'thud', label='cut sets 1'); ev(6.5, 'pop', f=988)
whip(7.0, (0.8, -0.8), 'whip sets 2'); ev(7.0, 'thud', soft=True, label='cut')
ev(7.5, 'thud', label='cut sets 3')
# build-it-yourself
whip(8.0, (0, 0), 'whip to car box'); ev(8.0, 'pop', f=880, label='build text')
ev(9.0, 'thud', label='cut hands building')
for k in range(4): ev(9.12 + k * 0.22, 'click', big=True, label='bricks snap')
whip(10.0, (-0.8, 0.8), 'whip to mini cars')
ev(11.0, 'thud', label='cut keychains'); ev(11.0, 'pop', f=1175, label='keychain text')
# staff
whip(12.0, (0.8, -0.8), 'whip to staff')
ev(13.0, 'thud', label='cut three staff'); ev(13.0, 'pop', f=1046, label='welcome text')
# walk to the shop
ev(13.96, 'whoosh', pan=(0, 0), dur=0.6, peak=0.45, g=0.8, label='zoom into the mall'); ev(14.0, 'pop', f=660, label='where? text')
ev(14.1, 'riser', dur=1.9)
ev(16.0, 'impact', size=1.05, label='ARRIVE: Junction Centre'); ev(16.03, 'sparkle', dur=0.6)
ev(16.5, 'pop', f=880, label='Nay Pyi Taw')
# end card
ev(18.0, 'impact', size=0.9, label='end card: shop name')
ev(19.0, 'pop', f=988, label='address'); ev(19.5, 'pop', f=1175, label='tiktok')
ev(20.0, 'impact', size=1.1, label='final hit: CTA'); ev(20.0, 'sparkle', dur=0.6)

for e in EV:
    k, t = e['kind'], e['t']
    if k == 'impact': S.put_st(S.impact(e['size']), t, 0, 0.95)
    elif k == 'sparkle': S.put_st(S.sparkle(e['dur']), t, (-0.6, 0.6), 0.8)
    elif k == 'pop': S.put_st(S.pop(e['f']), t, 0, 0.75)
    elif k == 'whoosh': S.put_st(S.whoosh(e['dur'], e.get('peak', 0.55)), t - e['dur'] * e.get('peak', 0.55), tuple(e['pan']), e['g'])
    elif k == 'thud': S.put_st(S.impact(0.55)[:int(0.35 * SR)] * (0.5 if e.get('soft') else 0.75), t, 0, 0.8)
    elif k == 'riser': S.put_st(S.riser(e['dur']), t, 0, 0.5)
    elif k == 'suckback': S.put_st(S.suckback(e['dur']), t, 0, 0.9)
    elif k == 'click': S.put_st(S.click() * (2.2 if e.get('big') else 1.5), t, rng.uniform(-0.25, 0.25), 0.6)
    elif k == 'bell': S.put_st(S.bell(e['f']), t, 0, 0.5)

# ---------- music ----------
M = S.M; put = S.put
st = lambda s: 261.63 * 2 ** (s / 12)
CH = {'C': (st(-24), [st(0), st(4), st(7)]), 'G': (st(-29), [st(-5), st(-1), st(2)]),
      'Am': (st(-27), [st(-3), st(0), st(4)]), 'F': (st(-31), [st(-7), st(-3), st(0)])}
BARS = ['Am', 'F', 'C', 'G', 'Am', 'F', 'C', 'G', 'Am', 'F']
MODE = ['intro', 'build', 'full', 'full', 'full', 'full', 'full', 'break', 'full', 'full']
PENT = [st(s) for s in (12, 14, 16, 19, 21, 24)]
LEAD = [[0, 2, 4, 2, 5, 4, 2, 0], [1, 3, 5, 3, 4, 2, 1, 3], [0, 4, 2, 5, 3, 4, 1, 2], [5, 4, 2, 4, 3, 1, 2, 0]]
kicks = []
for bar, name in enumerate(BARS):
    root, tri = CH[name]; t0 = bar * 4 * B; mode = MODE[bar]; full = mode == 'full'
    for q in range(4):
        tb = t0 + q * B
        if (full or (mode == 'intro' and q > 0) or (mode == 'build' and q < 3)): put(M, S.kick() * (0.7 if full else 0.5), tb); kicks.append(tb)
        if full and q % 2 == 1: put(M, S.clap() * 0.8, tb)
    if mode == 'build':                                     # snare roll into the stop-down
        for s16 in range(5): put(M, S.clap() * (0.3 + 0.12 * s16), t0 + 1.5 + s16 * B / 4 * 0.9)
    if mode == 'break':                                     # walk: claps only, building
        for q in range(4): put(M, S.clap() * (0.35 + 0.1 * q), t0 + q * B + B / 2)
        for s16 in range(4): put(M, S.clap() * (0.4 + 0.12 * s16), t0 + 1.5 + s16 * B / 4)
    for e8 in range(8):
        te = t0 + e8 * B / 2
        if mode == 'build' and e8 >= 7: continue
        put(M, S.hat(e8 % 2 == 1 and full) * (1.5 if full else 0.8), te)
        if full: put(M, S.bass(root * 2, B / 2 * 0.95) * (1.0 if e8 % 2 else 0.8), te)
        put(M, S.pluck(tri[e8 % 3] * (2 if (e8 % 4 == 3) else 1), bright=3400 if full else 1700) * (1.0 if full else 0.7), te)
    if full:
        pat = LEAD[bar % 4]
        for s8 in range(8):
            put(M, S.pluck(PENT[pat[s8]], 0.2, 5200) * 0.5, t0 + s8 * B / 2)
            if s8 % 2: put(M, S.pluck(PENT[pat[s8]] * 2, 0.1, 6000) * 0.22, t0 + s8 * B / 2 + B / 4)
# final hit chord with a reverb tail
fin = sum(S.pluck(f, 1.2, 3000) for f in CH['C'][1]) + S.bass(CH['C'][0] * 2, 1.2)
put(M, S.reverb(fin * 1.2, wet=0.45)[:int(1.9 * SR)], 20.0); put(M, S.kick(), 20.0); kicks.append(20.0)

side = np.ones(N)                                           # sidechain under the kick
for tk in kicks:
    i = int(tk * SR); n = int(0.22 * SR); j = min(N, i + n)
    side[i:j] = np.minimum(side[i:j], 1 - 0.28 * np.exp(-np.arange(j - i) / SR / 0.07))
M *= side
for a, b, f, gn in [(2.0, 4.0, 260, 0.8), (14.0, 16.0, 220, 0.8)]:   # thin sections so the next hit feels bigger
    i, j = int(a * SR), int(b * SR); M[i:j] = S.filt(M[i:j], 'high', f) * gn
sd = np.ones(N)                                             # stop-downs: silence right before the drop and the arrival
for s0, s1 in [(3.74, 4.0), (15.86, 16.0)]:
    i, j = int(s0 * SR), int(s1 * SR); sd[i:j] = 0; sd[i - 960:i] = np.linspace(1, 0, 960)
M *= sd
duck = np.ones(N)
for e in EV:
    if e['kind'] == 'impact':
        i = int(e['t'] * SR); n = int(0.45 * SR); j = min(N, i + n)
        duck[i:j] = np.minimum(duck[i:j], 1 - 0.37 * np.exp(-np.arange(j - i) / SR / 0.16))
M *= duck
Mh = S.filt(M, 'high', 2500); d = int(0.011 * SR)
ML = M + 0.35 * Mh; MR = M + 0.35 * np.concatenate([np.zeros(d), Mh[:-d]])
L, R = S.L, S.R
mix = np.stack([ML * 0.62 + L * 0.9, MR * 0.62 + R * 0.9], 1)
hp = sg.butter(2, 30 / (SR / 2), 'high', output='sos')
mix = sg.sosfilt(hp, mix, axis=0)
mix[-int(0.6 * SR):] *= np.linspace(1, 0, int(0.6 * SR))[:, None] ** 1.5
mix = np.tanh(mix / np.abs(mix).max() * 1.6) / np.tanh(1.6) * 0.89
sf.write('out/mix_raw.wav', mix, SR)
sfx = sg.sosfilt(hp, np.stack([L, R], 1), axis=0); sfx[-int(0.6 * SR):] *= np.linspace(1, 0, int(0.6 * SR))[:, None] ** 1.5
sf.write('public/sfx_only.wav', sfx / np.abs(sfx).max() * 0.63, SR)
json.dump(dict(bpm=120, beat=B, dur=DUR, events=EV), open('src/events.json', 'w'), indent=0)
print('events', len(EV), 'kicks', len(kicks))
