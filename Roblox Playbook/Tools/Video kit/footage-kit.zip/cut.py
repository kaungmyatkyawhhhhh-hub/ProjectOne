"""Cut real products out of the owner's own footage: rembg on a crop -> RGBA png (tight-cropped), plus a preview sheet."""
import cv2, numpy as np, sys, json
from rembg import remove, new_session
S = new_session('u2net')
CROPS = {  # name: (source frame, x0, y0, x1, y1)
 'bloxhand': ('hand', 1000, 1650, 2160, 2850),
 'mchand':   ('hand', 420, 1600, 1180, 2500),
 'bloxstack':('price', 1380, 2050, 2160, 3500),
 'mcstack':  ('mcrob', 1250, 1500, 2160, 3200),
 'robstack': ('mcrob', 0, 1450, 760, 3450),
 'sets':     ('sets', 0, 1350, 2160, 3050),
 'sets3':    ('sets3', 0, 1150, 2160, 3500),
 'keypink':  ('keys', 60, 2700, 560, 3250),
 'keygreen': ('keys', 1000, 1750, 1420, 2200),
 'keygun':   ('keys', 950, 2050, 2160, 2950),
 'keymint':  ('keys', 780, 3000, 1700, 3500),
 'cars':     ('cars', 250, 2650, 1300, 3200),
 'tower':    ('cars', 1000, 2700, 1500, 3250),
}
only = sys.argv[1:]
for name, (src, x0, y0, x1, y1) in CROPS.items():
    if only and name not in only: continue
    im = cv2.imread(f'src/{src}.png')[y0:y1, x0:x1]
    out = remove(cv2.cvtColor(im, cv2.COLOR_BGR2RGB), session=S, alpha_matting=False)
    out = np.array(out); a = out[..., 3]
    ys, xs = np.where(a > 40)
    if len(xs) == 0: print(name, 'EMPTY'); continue
    out = out[max(0, ys.min() - 8):ys.max() + 8, max(0, xs.min() - 8):xs.max() + 8]
    cv2.imwrite(f'{name}.png', cv2.cvtColor(out, cv2.COLOR_RGBA2BGRA)); print(name, out.shape[1], 'x', out.shape[0], 'alpha cover %.0f%%' % (100 * (out[..., 3] > 128).mean()))
