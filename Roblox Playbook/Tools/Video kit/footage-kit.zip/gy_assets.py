"""GYM ARC collage ad assets: cut-outs + UI stickers (with white sticker-outline versions), gameplay clips as 30 fps image sequences, logo, backdrop.
Everything is the game's own: its recording (raw/g.mp4, game view = crop 1912x832 at 4,158; the top 76 px bar with the platform's menu button is never used) and its own storefront art."""
import cv2, numpy as np, subprocess, os, sys
OUT = 'pub/'; D = '/mnt/user-data/uploads/Downloads/'
def frame(t):
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', str(t), '-i', 'raw/g.mp4', '-frames:v', '1', '-vf', 'crop=1912:832:4:158', 'cut/_f.png'], check=True); return cv2.imread('cut/_f.png')
def rect(im, name, r=18):
    h, w = im.shape[:2]; a = np.zeros((h, w), np.uint8); cv2.rectangle(a, (r, 0), (w - r, h), 255, -1); cv2.rectangle(a, (0, r), (w, h - r), 255, -1)
    for cx, cy in [(r, r), (w - r, r), (w - r, h - r), (r, h - r)]: cv2.circle(a, (cx, cy), r, 255, -1, cv2.LINE_AA)
    cv2.imwrite(f'cut/{name}.png', np.dstack([im, a]))
def biggest(a, thr=110):
    n, lab, st, _ = cv2.connectedComponentsWithStats((a > thr).astype(np.uint8)); k = 1 + st[1:, cv2.CC_STAT_AREA].argmax(); m = (lab == k).astype(np.uint8) * 255
    return cv2.GaussianBlur(cv2.dilate(m, np.ones((5, 5), np.uint8)), (0, 0), 1.5)
if 'cut' in sys.argv:
    from rembg import remove, new_session
    SS = new_session('u2net')
    def rb(im, name, keep=True):
        o = np.array(remove(cv2.cvtColor(im, cv2.COLOR_BGR2RGB), session=SS)); a = o[..., 3]
        if keep: a = np.minimum(a, biggest(a)); o[..., 3] = a
        ys, xs = np.where(a > 40); o = o[max(0, ys.min() - 6):ys.max() + 6, max(0, xs.min() - 6):xs.max() + 6]; cv2.imwrite(f'cut/{name}.png', cv2.cvtColor(o, cv2.COLOR_RGBA2BGRA)); print(name, o.shape[1], o.shape[0])
    f = frame(67.6)[0:800, 500:1280]                       # the growth flash: mask by its own flat gold colour (rembg misses soft edges)
    hsv = cv2.cvtColor(f, cv2.COLOR_BGR2HSV); m = cv2.inRange(hsv, (18, 70, 170), (34, 190, 255)); m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    core = biggest(cv2.erode(m, np.ones((41, 41), np.uint8)), 128); m = np.minimum(m, cv2.dilate(core, np.ones((61, 61), np.uint8))); m = biggest(m, 128)   # drop the bit of barbell that touches the arm
    ys, xs = np.where(m > 40); cv2.imwrite('cut/giant.png', np.dstack([f, m])[max(0, ys.min() - 4):ys.max() + 4, max(0, xs.min() - 4):xs.max() + 4]); print('giant', xs.max() - xs.min(), ys.max() - ys.min())
    rb(frame(80.5)[0:720, 720:1200], 'goldarms'); rb(cv2.imread(D + 'GYM ARC THUMBNAIL 2 v2.png'), 'hero'); rb(cv2.imread(D + 'GYM ARC THUMBNAIL v2.png')[:, :1500], 'lifter')
    f = frame(100.9); rect(f[100:680, 405:1525], 'volta', 40)
    f = frame(59.6); rect(f[706:804, 1562:1898], 'rep', 14); rect(f[340:505, 1564:1896], 'p455', 14)
    f = frame(63.5); rect(f[182:516, 586:1326], 'growpop', 22)
MAXD = {'giant': 900, 'goldarms': 640, 'hero': 430, 'lifter': 900, 'volta': 1000, 'rep': 460, 'p455': 420, 'growpop': 780}
if 'st' in sys.argv:
    for n, md in MAXD.items():
        im = cv2.imread(f'cut/{n}.png', cv2.IMREAD_UNCHANGED); h, w = im.shape[:2]; s = md / max(h, w)
        im = cv2.resize(im, (int(w * s), int(h * s)), interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_LANCZOS4)
        a = im[..., 3]; a = cv2.erode(a, np.ones((3, 3), np.uint8)); a = cv2.GaussianBlur(a, (0, 0), 1.0); a = np.clip((a.astype(np.float32) - 40) * 255 / 190, 0, 255).astype(np.uint8); im[..., 3] = a
        P = 44; im = cv2.copyMakeBorder(im, P, P, P, P, cv2.BORDER_CONSTANT, value=(0, 0, 0, 0)); cv2.imwrite(OUT + n + '.png', im)
        r = max(8, int(md * 0.016)); k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1, 2 * r + 1)); o = cv2.GaussianBlur(cv2.dilate((a > 110).astype(np.uint8) * 255, k), (0, 0), 1.6)
        o = cv2.copyMakeBorder(o, P, P, P, P, cv2.BORDER_CONSTANT, value=0); af = im[..., 3].astype(np.float32)[..., None] / 255; st = np.zeros_like(im); st[..., :3] = (im[..., :3] * af + 255 * (1 - af)).astype(np.uint8); st[..., 3] = np.maximum(o, im[..., 3])
        cv2.imwrite(OUT + n + '_st.png', st); print(n, im.shape[1], im.shape[0])
    lg = cv2.imread(D + 'GYM ARC LOGO.png', cv2.IMREAD_UNCHANGED); ys, xs = np.where(lg[..., 3] > 20); lg = lg[ys.min():ys.max(), xs.min():xs.max()]; h, w = lg.shape[:2]
    cv2.imwrite(OUT + 'logo.png', cv2.resize(lg, (1100, int(h * 1100 / w)), interpolation=cv2.INTER_AREA)); print('logo', w, h)
    g = frame(55.5); g = cv2.resize(g[:, 500:968], (1080, 1920), interpolation=cv2.INTER_CUBIC); g = cv2.GaussianBlur(g, (0, 0), 18); cv2.imwrite(OUT + 'gym_blur.jpg', np.clip(g * 1.25 + 30, 0, 255).astype(np.uint8), [cv2.IMWRITE_JPEG_QUALITY, 90])
# gameplay clips: (start s, source seconds squeezed into 1.0 s, crop x0); crop 1058x756 from y=76, scaled to 700x500, 30 frames
CLIPS = {'bench': (55.2, 1.6, 350), 'grow': (65.3, 2.3, 408), 'dead': (74.0, 1.4, 410), 'voltar': (97.8, 1.6, 427), 'alter': (105.4, 3.2, 440), 'stone': (117.6, 1.8, 390),
         'record': (115.0, 1.3, 370), 'hall': (127.0, 2.0, 427), 'city': (22.6, 3.0, 800)}
if 'clips' in sys.argv:
    for n, (t0, d, x0) in CLIPS.items():
        os.makedirs(OUT + n, exist_ok=True)
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', str(t0), '-t', str(d), '-i', 'raw/g.mp4', '-vf', f'crop=1912:832:4:158,crop=1058:756:{x0}:76,setpts=PTS/{d},fps=30,scale=700:500:flags=lanczos,eq=contrast=1.08:saturation=1.25', '-frames:v', '30', '-q:v', '3', OUT + n + '/%02d.jpg'], check=True)
        print(n, len(os.listdir(OUT + n)))
