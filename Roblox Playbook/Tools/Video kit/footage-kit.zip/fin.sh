#!/bin/bash
# Final render with real motion blur + both sound versions + checks.
# usage: [FINISH=bloom] [KEEP="0 1"] bash fin.sh <composition at 120 fps> <prefix> <sfx wav> <music wav> <events json> <frame count at 120 fps>
# The 120 fps render runs in 3 chunks (each retried once), so one stalled frame does not cost the whole render.
set -o pipefail
cd "$(dirname "$0")"
CH=/opt/pw-browsers/chromium-1243/chrome-linux64/chrome
C=$1; P=$2; SFX=$3; MIX=$4; EVJ=$5; NF=$6
mkdir -p out/chunks
for f in out/${P}x.mp4 out/${P}_video.mp4 out/${P}_sfx.mp4 out/${P}_music.mp4; do [ -f "$f" ] && mv -f "$f" out/chunks/old_$(basename "$f"); done
STEP=$(( (NF / 3 / 4) * 4 )); : > out/chunks/${P}_list.txt; A=0; I=0
while [ $A -lt $NF ]; do
  B=$(( A + STEP - 1 )); [ $I -ge 2 ] && B=$(( NF - 1 )); O=out/chunks/${P}_$I.mp4
  # KEEP="0 1" reuses those finished chunks (when only a later part of the film changed)
  if [[ " $KEEP " == *" $I "* ]] && [ -s "$O" ]; then echo "file '$(pwd)/$O'" >> out/chunks/${P}_list.txt; A=$(( B + 1 )); I=$(( I + 1 )); continue; fi
  [ -f "$O" ] && mv -f "$O" "$O.old"
  for TRY in 1 2; do
    npx remotion render src/index.ts $C $O --frames=$A-$B --muted --timeout=120000 --browser-executable=$CH --concurrency=2 --crf=14 2>&1 | grep -iE "error|not defined|failed" | head -4
    [ -s "$O" ] && break; echo "chunk $I try $TRY failed"
  done
  [ -s "$O" ] || { echo RENDER FAILED; exit 1; }
  echo "file '$(pwd)/$O'" >> out/chunks/${P}_list.txt; A=$(( B + 1 )); I=$(( I + 1 ))
done
ffmpeg -v error -y -f concat -safe 0 -i out/chunks/${P}_list.txt -c copy out/${P}x.mp4 || exit 1
BLEND="tmix=frames=4:weights='1 1 1 1',select='not(mod(n-3\,4))',setpts=N/30/TB"
# FINISH=bloom adds the glow-and-grain finish (highlights only, so pale paper is not washed out)
if [ "$FINISH" = bloom ]; then
  ffmpeg -v error -y -i out/${P}x.mp4 -filter_complex "[0:v]$BLEND,format=gbrp,split[a][b];[b]curves=all='0/0 0.78/0 1/1',gblur=sigma=24[bl];[a][bl]blend=all_mode=screen:all_opacity=0.6,eq=contrast=1.05:saturation=1.12,unsharp=5:5:0.4,noise=alls=4:allf=t,format=yuv420p[v]" -map "[v]" -r 30 -c:v libx264 -crf 15 out/${P}_video.mp4 || exit 1
else
  ffmpeg -v error -y -i out/${P}x.mp4 -vf "$BLEND" -r 30 -c:v libx264 -crf 15 -pix_fmt yuv420p out/${P}_video.mp4 || exit 1
fi
ffmpeg -v error -y -i out/${P}_video.mp4 -i $SFX -c:v copy -c:a aac -b:a 256k -shortest -movflags +faststart out/${P}_sfx.mp4 || exit 1
# AAC encoding can overshoot the wav's peak by 2-4 dB on bright clicks: lower the limiter ceiling until the FINAL file's true peak is <= -1.5 dBFS
for L in 0.52 0.46 0.4; do
  ffmpeg -v error -y -i out/${P}_video.mp4 -i $MIX -c:v copy -af "volume=1.1dB,alimiter=limit=$L:attack=1:release=30:level=false" -c:a aac -b:a 256k -shortest -movflags +faststart out/${P}_music.mp4 || exit 1
  PK=$(ffmpeg -hide_banner -nostats -i out/${P}_music.mp4 -af ebur128=peak=true -f null - 2>&1 | grep "Peak:" | tail -1 | awk '{print $2}')
  python3 -c "import sys; sys.exit(0 if float('$PK') <= -1.5 else 1)" && break
done
rm -f out/${P}x.mp4
echo "== video check"; python3 check_video.py out/${P}_music.mp4 $EVJ 2>&1 | tail -4
echo "== audio check (music)"; python3 check_audio.py out/${P}_music.mp4 $EVJ 2>&1 | grep -E "SYNC|BANDS|LOUD"
echo "== audio check (sfx)"; python3 check_audio.py out/${P}_sfx.mp4 $EVJ 2>&1 | grep -E "SYNC|LOUD"
echo "== faces"; python3 facescan.py out/${P}_video.mp4 2>&1 | tail -1
ffprobe -v error -show_entries format=duration,size -of csv=p=0 out/${P}_music.mp4
echo DONE
