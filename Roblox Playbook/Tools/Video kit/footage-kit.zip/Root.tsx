import React from 'react';import {Composition} from 'remotion';import {AdT} from './AdT';import {Dg} from './Dg';import {Gy} from './Gy';
import wyw from './shots2.json';import tesla from './shots3.json';
// one composition, any sound: each cut-list JSON carries the shots and the named moments (T) placed on that sound's measured hits
export const Root=()=> <>
 <Composition id="Wyw" component={AdT as any} defaultProps={{cfg: wyw}} durationInFrames={489} fps={30} width={1080} height={1920}/>
 <Composition id="Tesla" component={AdT as any} defaultProps={{cfg: tesla}} durationInFrames={606} fps={30} width={1080} height={1920}/>
 <Composition id="TeslaX" component={AdT as any} defaultProps={{cfg: tesla}} durationInFrames={2424} fps={120} width={1080} height={1920}/>
 <Composition id="Dg" component={Dg} durationInFrames={378} fps={30} width={1080} height={1920}/>
 <Composition id="DgX" component={Dg} durationInFrames={1512} fps={120} width={1080} height={1920}/>
 <Composition id="Gy" component={Gy} durationInFrames={378} fps={30} width={1080} height={1920}/>
 <Composition id="GyX" component={Gy} durationInFrames={1512} fps={120} width={1080} height={1920}/>
</>;
